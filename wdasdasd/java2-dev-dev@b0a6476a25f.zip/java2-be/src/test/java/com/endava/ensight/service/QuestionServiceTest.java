package com.endava.ensight.service;

import com.endava.ensight.model.Discipline;
import com.endava.ensight.model.Question;
import com.endava.ensight.repository.QuestionRepository;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

public class QuestionServiceTest {

    @Mock
    private QuestionRepository questionRepository;

    @InjectMocks
    private QuestionService questionService;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getQuestionByIdTest() {
        Question question = new Question();
        question.setId(0);
        questionService.createQuestion(question);
        verify(questionRepository, times(1)).create(question);
    }

    @Test
    public void sortQuestionAscendingByTitle() {

        final Collection<Question> actualListSorted =
                questionService.sortQuestionsByTitle(
                        Arrays.asList(
                                new Question("C"),
                                new Question("B"),
                                new Question("A")), "asc");

        Assert.assertEquals(actualListSorted.toString(), new ArrayList<>(
                Arrays.asList(
                        new Question("A"),
                        new Question("B"),
                        new Question("C"))).toString());
    }

    @Test
    public void sortQuestionDescendingByTitle() {

        final Collection<Question> actualListSorted =
                questionService.sortQuestionsByTitle(
                        Arrays.asList(
                                new Question("A"),
                                new Question("B"),
                                new Question("C")), "desc");

        Assert.assertEquals(actualListSorted.toString(), new ArrayList<>(
                Arrays.asList(
                        new Question("C"),
                        new Question("B"),
                        new Question("A"))).toString());
    }

    @Test
    public void getQuestionsSubListWhenPageNumberIsBig() {

        int numberOfQuestionsPerPage = 3;
        int pageNumber = 1000000;
        List<Question> questions = Arrays.asList(
                new Question("A"),
                new Question("B"),
                new Question("C"));

        List<Question> questionsResult = questionService.getQuestionsSubList(numberOfQuestionsPerPage, pageNumber, questions);
        Assert.assertEquals(questions.toString(), questionsResult.toString());
    }

    @Test
    public void getQuestionsSubListWhenPageNumberIsNegative() {

        int numberOfQuestionsPerPage = 3;
        int pageNumber = -1;
        List<Question> questions = Arrays.asList(
                new Question("A"),
                new Question("B"),
                new Question("C"));

        List<Question> questionsResult = questionService.getQuestionsSubList(numberOfQuestionsPerPage, pageNumber, questions);
        Assert.assertEquals(questions.toString(), questionsResult.toString());
    }

    @Test
    public void getQuestionsSubListWhenSizeIsNegative() {

        int numberOfQuestionsPerPage = -1;
        int pageNumber = 1;
        List<Question> questions = Arrays.asList(
                new Question("A"),
                new Question("B"),
                new Question("C"));

        List<Question> questionsResult = questionService.getQuestionsSubList(numberOfQuestionsPerPage, pageNumber, questions);
        Assert.assertEquals(questions.toString(), questionsResult.toString());
    }

    @Test
    public void getQuestionsSubListWhenSizeIsBig() {

        int numberOfQuestionsPerPage = 100000;
        int pageNumber = 1;
        List<Question> questions = Arrays.asList(
                new Question("A"),
                new Question("B"),
                new Question("C"));

        List<Question> questionsResult = questionService.getQuestionsSubList(numberOfQuestionsPerPage, pageNumber, questions);
        Assert.assertEquals(questions.toString(), questionsResult.toString());
    }

    @Test
    public void getQuestionsSubListWhenSizeIsBiggerThanNoOfQuestionsOnTheLastPage() {

        int numberOfQuestionsPerPage = 2;
        int pageNumber = 2;
        List<Question> questions = Arrays.asList(
                new Question("A"),
                new Question("B"),
                new Question("C"));

        List<Question> questionsResult = questionService.getQuestionsSubList(numberOfQuestionsPerPage, pageNumber, questions);
        Assert.assertEquals(Arrays.asList(new Question("C")).toString(), questionsResult.toString());
    }

    @Test
    public void filterQuestionsByDiscipline() {
        List<Question> questions = new ArrayList<>();
        Question questionA = new Question("A");
        questionA.setDiscipline(Discipline.values()[0]);
        questions.add(questionA);

        Question questionB = new Question("B");
        questionB.setDiscipline(Discipline.values()[1]);
        questions.add(questionB);

        Question questionC = new Question("C");
        questionC.setDiscipline(Discipline.values()[2]);
        questions.add(questionC);

        int discipline[] = {1, 2};
        List<Question> filteredQuestions = questionService.filterQuestionsByDiscipline(discipline, questions);

        Assert.assertEquals(Arrays.asList(questionA, questionB).toString(), filteredQuestions.toString());
    }

    @Test
    public void filterQuestionsByDifficulty() {
        List<Question> questions = new ArrayList<>();
        Question questionA = new Question("A");
        questionA.setDifficulty(1);
        questions.add(questionA);

        Question questionB = new Question("B");
        questionB.setDifficulty(2);
        questions.add(questionB);

        Question questionC = new Question("C");
        questionC.setDifficulty(3);
        questions.add(questionC);

        int difficulty[] = {1, 2};
        List<Question> filteredQuestions = questionService.filterQuestionsByDifficulty(difficulty, questions);

        Assert.assertEquals(Arrays.asList(questionA, questionB).toString(), filteredQuestions.toString());
    }

    @Test
    public void filterQuestionsByType() {
        List<Question> questions = new ArrayList<>();
        Question questionA = new Question("A");
        questionA.setType(1);
        questions.add(questionA);

        Question questionB = new Question("B");
        questionB.setType(2);
        questions.add(questionB);

        Question questionC = new Question("C");
        questionC.setType(3);
        questions.add(questionC);

        int type[] = {1, 2};
        List<Question> filteredQuestions = questionService.filterQuestionsByType(type, questions);

        Assert.assertEquals(Arrays.asList(questionA, questionB).toString(), filteredQuestions.toString());
    }
}