//package com.endava.ensight.repository;
//
//
//import com.endava.ensight.model.Question;
//import org.junit.Assert;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.mockito.InjectMocks;
//import org.springframework.test.context.junit4.SpringRunner;
//
//@RunWith(SpringRunner.class)
//public class QuestionRepositoryTest {
//    @InjectMocks
//    QuestionRepository questionRepository;
//
//    @Test
//    public void createQuestionShouldReturnTheIDofTheCreatedQuestion() {
//        Question question = new Question();
//        question.setId(2);
//        int id = questionRepository.create(question);
//        Assert.assertEquals(2, id);
//    }
//
//    @Test
//    public void findExistingQuestionShouldReturnTheObject() {
//        Question question = new Question();
//        question.setId(2);
//        int id = questionRepository.create(question);
//        Question retrievedQuestion = questionRepository.getById(2);
//    }
//}