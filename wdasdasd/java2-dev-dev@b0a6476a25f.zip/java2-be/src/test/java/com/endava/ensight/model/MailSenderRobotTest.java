package com.endava.ensight.model;

import com.endava.ensight.config.MailSenderSettings;
import org.junit.jupiter.api.Test;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

class MailSenderRobotTest {

    @Test
    void sendSimpleEmail() {

        String to = "alexandrubodnar10@gmail.com";
        String subject ="test email robot";
        String text= "Test body";

        JavaMailSender mailSender = new MailSenderSettings().getJavaMailSender();
        SimpleMailMessage message = new SimpleMailMessage();

        message.setTo(to);
        message.setSubject(subject);
        message.setText(text);
        mailSender.send(message);
        System.out.println("------------------\n" +mailSender.toString());
    }

}