package com.endava.ensight.controller;

import com.endava.ensight.model.CandidateAndHisExam;
import com.endava.ensight.service.CandidateAndHisExamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@CrossOrigin(value = "*")
@RestController
public class CandidateAndHisExamController {
    @Autowired
    CandidateAndHisExamService candidateAndHisExamService;

    @GetMapping(value = "/candidates-and-their-exams", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<CandidateAndHisExam>> getAllCandidatesAndTheirExams(@RequestParam(value = "campaignId") Integer campaignId){
        System.out.println( campaignId);
        return new ResponseEntity<>(candidateAndHisExamService.getAllCandidatesAndTheirExams(campaignId), HttpStatus.OK);
    }

}
