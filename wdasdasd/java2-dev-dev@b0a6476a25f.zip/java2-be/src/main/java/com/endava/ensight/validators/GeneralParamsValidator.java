package com.endava.ensight.validators;

import com.endava.ensight.model.GeneralParams;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

public class GeneralParamsValidator implements Validator {
    @Override
    public boolean supports(Class<?> aClass) {
        return false;
    }

    @Override
    public void validate(Object obj, Errors errors) {
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "numberOfQuestions", "numberOfQuestions.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "discipline", "discipline.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "easyPercent", "easyPercent.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "mediumPercent", "mediumPercent.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "hardPercent", "hardPercent.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "numberOfTests", "numberOfTests.required");

        GeneralParams generalParams = (GeneralParams) obj;
        if (generalParams.getNumberOfQuestions() < 0) {
            errors.rejectValue("numberOfQuestions", "numberOfQuestions.invalid", new Object[]{}, "");
        }
    }

    //TBD if this validator is a must. The alternative is model validation.
}
