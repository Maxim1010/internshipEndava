package com.endava.ensight.model;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "questions")
public class Question {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "title")
    private String title;

    @Column(name = "type")
    private int type;

    @Column(name = "discipline")
    @Enumerated(EnumType.STRING)
    private Discipline discipline;

    @Column(name = "difficulty")
    private int difficulty;

    @Column(name = "no_of_points")
    private int noOfPoints;

    @Column(name = "correct_answer_text")
    private String correctAnswerText;

    @Column(name = "created_at")
    private LocalDate createdAt;

    @Column(name = "updated_at")
    private LocalDate updatedAt;

//    @OneToOne(fetch = FetchType.LAZY, mappedBy = "question")
//    Answer answer;

    public Question() {
        this.createdAt = LocalDate.now();
        this.updatedAt = LocalDate.now();
        this.difficulty = 2;
        this.discipline = Discipline.AM;
        this.noOfPoints = 3;
        this.title = "dev test";
        this.type = 1;
    }

    public Question(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public Discipline getDiscipline() {
        return discipline;
    }

    public void setDiscipline(Discipline discipline) {
        this.discipline = discipline;
    }

    public int getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(int difficulty) {
        this.difficulty = difficulty;
    }

    public int getNoOfPoints() {
        return noOfPoints;
    }

    public void setNoOfPoints(int noOfPoints) {
        this.noOfPoints = noOfPoints;
    }

    public String getCorrectAnswerText() {
        return correctAnswerText;
    }

    public void setCorrectAnswerText(String correctAnswerText) {
        this.correctAnswerText = correctAnswerText;
    }

    public LocalDate getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDate createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDate getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDate updatedAt) {
        this.updatedAt = updatedAt;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

//    public Answer getAnswer() {
//        return answer;
//    }
//
//    public void setAnswer(Answer answer) {
//        this.answer = answer;
//    }

    @Override
    public String toString() {
        return "Question{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", type=" + type +
                ", discipline=" + discipline +
                ", difficulty=" + difficulty +
                ", noOfPoints=" + noOfPoints +
                ", correctAnswerText=" + correctAnswerText +
                ", createdAt=" + createdAt +
                ", updatedAt=" + updatedAt +
//                ", answer=" + answer +
                '}';
    }
}