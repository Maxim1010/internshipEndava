package com.endava.ensight.service;

import com.endava.ensight.config.MailConstants;
import com.endava.ensight.model.Candidate;
import com.endava.ensight.model.Mail;
import com.endava.ensight.repository.EmailRepository;
import com.sun.org.apache.xpath.internal.operations.Bool;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class EmailService {
    @Autowired
    private JavaMailSender emailSender;

    @Autowired
    private EmailRepository emailRepository;

    public Integer sendSimpleMessage(List<Candidate> candidateList){
        Mail mail = new Mail();
        SimpleMailMessage message = new SimpleMailMessage();

        for(Candidate candidate: candidateList) {
            mail.setTo(candidate.getEmail());
            mail.setFrom(MailConstants.getUSERNAME());
            mail.setSubject("Endava aplication - Internship");
            mail.setContent("Hai la test prietene :) sa vedem ce stii, oricum pici dar haide.");

            if(setStatusToCandidateToSent(candidate)){
                System.out.println("Status updated");
            }

            message.setSubject(mail.getSubject());
            message.setText(mail.getContent());
            message.setTo(mail.getTo());
            message.setFrom(mail.getFrom());

            emailSender.send(message);
        }

        return 0;
    }

    private boolean setStatusToCandidateToSent(Candidate candidate){
        return emailRepository.setStatusToSent(candidate);
    }


}
