package com.endava.ensight.service;

import com.endava.ensight.model.Candidate;
import com.endava.ensight.model.CandidateAndHisExam;
import com.endava.ensight.model.Exam;
import com.endava.ensight.repository.CandidateRepository;
import com.endava.ensight.repository.ExamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CandidateAndHisExamService {
    @Autowired
    CandidateService candidateService;

    @Autowired
    ExamService examService;


    public List<CandidateAndHisExam> getAllCandidatesAndTheirExams(Integer campaignId) {
        List<CandidateAndHisExam> candidatesAndTheirExams = new ArrayList<>();
        List<Candidate> candidates = candidateService.getCandidatesFromCampaignWithId(campaignId);
        for (Candidate candidate : candidates) {
            Exam exam = examService.getExamByCandidateIdOnly(candidate.getId());
            if(exam!=null) {
                CandidateAndHisExam candidateAndHisExam = new CandidateAndHisExam(candidate, exam);
                candidatesAndTheirExams.add(candidateAndHisExam);
            }
            else{
                System.out.println("Candidate with ID " + candidate.getId() + " does not have an Exam record in this DB");
            }
        }
        return candidatesAndTheirExams;
    }
}
