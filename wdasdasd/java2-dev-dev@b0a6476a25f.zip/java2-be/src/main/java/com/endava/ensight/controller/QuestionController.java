package com.endava.ensight.controller;

import com.endava.ensight.model.Question;
import com.endava.ensight.service.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@CrossOrigin(origins = "*")
@RestController
public class QuestionController {
    @Autowired
    private QuestionService questionService;

    @PostMapping(value = "/question/create", consumes = APPLICATION_JSON_VALUE)
    public ResponseEntity<Number> createQuestion(@RequestBody Question question) {
        return new ResponseEntity<>(questionService.createQuestion(question), HttpStatus.OK);
    }

    @GetMapping(value = "/questions/all", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Question>> getAllQuestions() {
        return new ResponseEntity<>(questionService.getAllQuestions(), HttpStatus.OK);
    }

    @GetMapping(value = "/questions", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Question> getQuestionsSublist(@RequestParam(value = "page", defaultValue = "1") int page, @RequestParam(value = "size", defaultValue = "15") int size) {
        return questionService.getQuestionsSubList(size, page);
    }

    @GetMapping(value = "/questions/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Question> getQuestionById(@PathVariable Integer id) {
        return new ResponseEntity<>(questionService.getQuestionById(id), HttpStatus.OK);
    }

    @GetMapping(value = "/questions/filter", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Question> getQuestionsSublistByFilters(@RequestParam(value = "page", defaultValue = "1") int page,
                                                       @RequestParam(value = "size", defaultValue = "15") int size,
                                                       @RequestParam(value = "difficulty", defaultValue = "1,2,3") int difficulty[],
                                                       @RequestParam(value = "type", defaultValue = "1,2,3") int type[],
                                                       @RequestParam(value = "discipline", defaultValue = "1,2,3,4") int discipline[]) {
        return questionService.getFilteredQuestionsSubList(size, page, difficulty, type, discipline);
    }

    @GetMapping(value = "/questions/filter/sort", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Question> getQuestionsSublistByFiltersAndSorting(@RequestParam(value = "page", defaultValue = "1") int page,
                                                                 @RequestParam(value = "size", defaultValue = "15") int size,
                                                                 @RequestParam(value = "difficulty", defaultValue = "1,2,3") int difficulty[],
                                                                 @RequestParam(value = "type", defaultValue = "1,2,3") int type[],
                                                                 @RequestParam(value = "discipline", defaultValue = "1,2,3,4") int discipline[],
                                                                 @RequestParam(value = "sortField", defaultValue = "2") int sortField,
                                                                 @RequestParam(value = "order", defaultValue = "asc") String order
    ) {
        return questionService.getFilteredAndSortedQuestionsSubList(size, page, difficulty, type, discipline, sortField, order);

    }

    @GetMapping(value = "/questions/count")
    public int getNumberOfFilteredAndSortedQuestions(@RequestParam(value = "page", defaultValue = "1") int page,
                                                     @RequestParam(value = "size", defaultValue = "15") int size,
                                                     @RequestParam(value = "difficulty", defaultValue = "1,2,3") int difficulty[],
                                                     @RequestParam(value = "type", defaultValue = "1,2,3") int type[],
                                                     @RequestParam(value = "discipline", defaultValue = "1,2,3,4") int discipline[],
                                                     @RequestParam(value = "sortField", defaultValue = "1") int sortField,
                                                     @RequestParam(value = "order", defaultValue = "asc") String order
    ) {
        return questionService.getNumberOfFilteredAndSortedQuestions(difficulty, type, discipline, sortField, order);
    }

    @DeleteMapping(value = "/question/delete/{questionId}")
    public ResponseEntity<Integer> deleteQuestionById(@PathVariable int questionId) {
        return new ResponseEntity<>(questionService.deleteQuestionById(questionId), HttpStatus.OK);
    }

    @PostMapping(value = "/question/delete/multiple")
    public ResponseEntity<Integer> deleteQuestions(@RequestBody List<Integer> questionIds) {
        return new ResponseEntity<>(questionService.deleteQuestions(questionIds), HttpStatus.OK);
    }

    @PutMapping(value = "/question/edit")
    public ResponseEntity<Integer> editQuestion(@RequestBody Question question) {
        return new ResponseEntity<>(questionService.editQuestion(question), HttpStatus.OK);
    }
}