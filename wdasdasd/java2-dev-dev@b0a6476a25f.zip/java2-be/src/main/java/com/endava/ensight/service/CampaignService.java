package com.endava.ensight.service;

import com.endava.ensight.model.Campaign;
import com.endava.ensight.repository.CampaignRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CampaignService {
    @Autowired
    CampaignRepository campaignRepository;


    public Integer createCampaign(Campaign campaign) {
        return  campaignRepository.create(campaign);
    }

    public Campaign getCampaignById(Integer campaignId) {
        try {
            return campaignRepository.getById(campaignId);
        } catch (Exception e) {
            e.printStackTrace();
            //log.warning();
            //testinglog.warning();
            return null;
        }
    }

    public List<Campaign> getAllCampaigns() {
        return campaignRepository.readAll();
    }

    public Integer getLastCampaignId() {
        Integer lastId = -1;
        try {
            lastId = campaignRepository.getLastId();
        } catch (Exception e) {
            System.out.println("There are no records in Campaign DB");
            //e.printStackTrace();
            return -1;
        }
        return lastId;
    }
}
