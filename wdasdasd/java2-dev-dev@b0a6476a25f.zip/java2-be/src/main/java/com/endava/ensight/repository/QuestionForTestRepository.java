package com.endava.ensight.repository;

import com.endava.ensight.Application;
import com.endava.ensight.model.QuestionForTest;
import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.util.Collections;
import java.util.List;

@Component
public class QuestionForTestRepository implements CrudRepository<QuestionForTest> {
    @PersistenceUnit
    private EntityManagerFactory entityManagerFactory;

    public QuestionForTestRepository() {
        entityManagerFactory = Application.getEntityManagerFactory();
    }

    @Override
    public int create(QuestionForTest questionForTest) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction entityTransaction = entityManager.getTransaction();
        try {
            entityTransaction.begin();

            entityManager.persist(questionForTest);
            entityTransaction.commit();
        } catch (Exception e) {
            if (entityTransaction != null)
                entityTransaction.rollback();
        } finally {
            entityManager.close();
        }
        return questionForTest.getId();
    }

    @Override
    public List<QuestionForTest> readAll() {
        return null;
    }

    @Override
    public int update(Integer id, QuestionForTest questionForTest) {
        return 0;
    }

    @Override
    public int delete(Integer id) {
        return 0;
    }

    @Override
    public QuestionForTest getById(Integer id) {
        return null;
    }

    public List<Integer> getQuestionsIdsByTestId(Integer testId) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction entityTransaction = entityManager.getTransaction();
        List<Integer> questionIds = Collections.emptyList();
        try {
            entityTransaction.begin();
            Query query = entityManager.createQuery("select qft.questionId from QuestionForTest qft where qft.testId=" + testId);
            questionIds = query.getResultList();
            entityTransaction.commit();
        } catch (Exception ex) {
            if (entityTransaction != null)
                entityTransaction.rollback();
        } finally {
            entityManager.close();
        }
        return questionIds;

    }

    public Integer deleteByTestId(Integer id) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction entityTransaction = entityManager.getTransaction();
        try {
            entityTransaction.begin();
            Query query = entityManager.createQuery("DELETE FROM QuestionForTest qft WHERE qft.testId=:id");
            query.setParameter("id", id);
            query.executeUpdate();
            entityTransaction.commit();
        } catch (Exception e) {
            e.printStackTrace();
            if (entityTransaction != null) {
                entityTransaction.rollback();
                return -1;
            }
        } finally {
            entityManager.close();
        }
        return 0;
    }

    public Integer deleteByTestId2(Integer testId) {
        return null;
    }
}