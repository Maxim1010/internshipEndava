package com.endava.ensight.dto;

import java.time.LocalDateTime;

public class ExamDTO {

    private CandidateTestId id;

    private float grade;

    private LocalDateTime startTime;

    private LocalDateTime endTime;

    public ExamDTO() {
    }

    public ExamDTO(CandidateTestId id, float grade, LocalDateTime startTime, LocalDateTime endTime) {
        this.id = id;
        this.grade = grade;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public CandidateTestId getId() {
        return id;
    }

    public void setId(CandidateTestId id) {
        this.id = id;
    }

    public float getGrade() {
        return grade;
    }

    public void setGrade(float grade) {
        this.grade = grade;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }
}
