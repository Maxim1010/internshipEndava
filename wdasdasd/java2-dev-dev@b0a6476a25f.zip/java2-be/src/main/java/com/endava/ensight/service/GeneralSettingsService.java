package com.endava.ensight.service;

import com.endava.ensight.model.GeneralSettings;
import com.endava.ensight.repository.GeneralSettingsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class GeneralSettingsService {
    @Autowired
    private GeneralSettingsRepository generalSettingsRepository;

    public Integer createGeneralSettings(GeneralSettings generalSettings) {
        return generalSettingsRepository.create(generalSettings);
    }

    public Integer updateGeneralSettings(GeneralSettings generalSettings) {
        return generalSettingsRepository.update(generalSettings.getId(), generalSettings);
    }

    public GeneralSettings getGeneralSettings() {
        return generalSettingsRepository.read();
    }
}
