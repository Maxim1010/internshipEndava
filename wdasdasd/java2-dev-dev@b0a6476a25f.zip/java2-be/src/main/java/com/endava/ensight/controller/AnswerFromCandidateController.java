package com.endava.ensight.controller;

import com.endava.ensight.model.AnswerFromCandidate;
import com.endava.ensight.model.CandidateTestQuestionCompositeKey;
import com.endava.ensight.service.AnswerFromCandidateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
@CrossOrigin(value = "*")
public class AnswerFromCandidateController {
    @Autowired
    AnswerFromCandidateService answerFromCandidateService;

    @PostMapping(value = "/answer-from-candidate/create", consumes = APPLICATION_JSON_VALUE)
    public ResponseEntity<Integer> createAnswerFromCandidate(@RequestBody @Valid AnswerFromCandidate answerFromCandidate) {
        return new ResponseEntity<>(answerFromCandidateService.createAnswerFromCandidate(answerFromCandidate), HttpStatus.OK);
    }

    @GetMapping(value = "/answer-from-candidate/{candidateId}-{testId}-{questionId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<AnswerFromCandidate> getExamById(@PathVariable Integer candidateId,
                                                           @PathVariable Integer testId,
                                                           @PathVariable Integer questionId) {
        return new ResponseEntity<>(answerFromCandidateService.getAnswerFromCandidateById(candidateId,testId,questionId), HttpStatus.OK);
    }

    @PutMapping(value = "/answer-from-candidate")
    @ResponseBody
    public void editAnswerFromCandidate(@RequestBody @Valid AnswerFromCandidate answerFromCandidate) {
        answerFromCandidateService.updateAnswerFromCandidate(answerFromCandidate);
    }
}
