package com.endava.ensight.service;

import com.endava.ensight.model.*;
import com.endava.ensight.repository.CandidateRepository;
import com.endava.ensight.validators.CandidateExcelValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class CandidateService {
    @Autowired
    private CandidateRepository candidateRepository;

    @Autowired
    private CandidateForCampaignService candidateForCampaignService;

    @Autowired
    private CampaignService campaignService;

    @Autowired
    private QuestionService questionService;

    @Autowired
    private TestService testService;

    @Autowired
    private ExamService examService;

    public Integer createCandidate(Candidate candidate) {
        return candidateRepository.create(candidate);
    }

    public Candidate getCandidateById(Integer candidateId) {
        try {
            return candidateRepository.getById(candidateId);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void updateCandidate(Candidate candidate) {
        candidateRepository.update(candidate.getId(), candidate);
    }

    public List<Candidate> getCandidatesFromCampaignWithId(Integer campaignId) {
        List<Integer> ids = candidateForCampaignService.getCandidatesIdsByCampaignId(campaignId);
        return candidateRepository.getByListOfIds(ids)
                .stream()
                .sorted(Comparator.comparing(Candidate::getId))
                .collect(Collectors.toList());

    }


    public String importCandidates(List<Candidate> candidateList, Integer campaignId) {
        Campaign campaign = campaignService.getCampaignById(campaignId);
        if (campaign == null)
            return "This campaign does not exist";

        String errorsForEnoughDisciplines = checkIfThereAreTestsForRequestedDisciplines(candidateList);
        if(errorsForEnoughDisciplines.length()>0)
            return errorsForEnoughDisciplines;

        StringBuilder errors = new StringBuilder();
        for (int index = 0; index < candidateList.size(); index++) {
            Candidate candidate = candidateList.get(index);
            String currentErrors = CandidateExcelValidator.validate(candidate);
            appendCurrentErrorsIfExistent(errors, index, currentErrors);
        }
        if (errors.length() > 0)
            return errors.toString();
        else {
            List<CandidateForCampaign> candidateForCampaigns = new ArrayList<>();
            Set<Discipline> disciplinesRequired = getDisciplinesSet(candidateList);

            Map<Discipline,List<Test>> testsByDiscipline = new HashMap<>();
            disciplinesRequired.forEach(discipline -> {
                testsByDiscipline.put(discipline,testService.getAllFilteredTests(discipline));
            });

            candidateList.forEach(candidate -> {
                int createdCandidateId = candidateRepository.create(candidate);
                CandidateForCampaign candidateForCampaign = new CandidateForCampaign(createdCandidateId, campaignId);

                candidateForCampaignService.createCandidateForCampaign(candidateForCampaign);

                Exam examForCurrentCandidate = getExamForCurrentCandidate(testsByDiscipline, candidate);

                examService.createExam(examForCurrentCandidate);
            });
            return "Successfully imported";
        }
    }

    private Exam getExamForCurrentCandidate(Map<Discipline, List<Test>> testsByDiscipline, Candidate candidate) {
        Exam examForCurrentCandidate;
        Integer upperBound = new Random().nextInt(testsByDiscipline.get(candidate.getDiscipline()).size());
        Test testForCurrentCandidate = testsByDiscipline.get(candidate.getDiscipline()).get(upperBound);
        CandidateTestCompositeKey currentIdForExam = new CandidateTestCompositeKey(candidate.getId(), testForCurrentCandidate.getId());
        return new Exam(currentIdForExam,0f,Status.READY_TO_SEND);
    }

    private String checkIfThereAreTestsForRequestedDisciplines(List<Candidate> candidateList) {
        StringBuilder errors = new StringBuilder();
        Set<Discipline> disciplinesRequired = getDisciplinesSet(candidateList);
        disciplinesRequired.forEach(discipline -> {
            List<Test> tests = testService.getAllFilteredTests(discipline);
            if (tests.size()==0)
                errors.append("There is at least a candidate which should take a technical test in the")
                        .append(" ")
                        .append(discipline.toString())
                        .append(" ")
                        .append("discipline, but there are no generated tests for that discipline\n");
        });
        return errors.toString();
    }

    private Set<Discipline> getDisciplinesSet(List<Candidate> candidateList) {
        HashSet<Discipline> disciplinesRequired = new HashSet<>();
        candidateList.forEach(candidate -> disciplinesRequired.add(candidate.getDiscipline()));
        return disciplinesRequired;
    }

    private void appendCurrentErrorsIfExistent(StringBuilder errors, int index, String currentErrors) {
        if (currentErrors.length() > 0)
            errors.append("errors at line")
                    .append(" ")
                    .append(index)
                    .append(":")
                    .append("\n")
                    .append(currentErrors);
        if (errors.length() > 0)
            errors.append("\n");
    }

    public List<Candidate> getAllCandidates() {
        return candidateRepository.readAll();
    }
}
