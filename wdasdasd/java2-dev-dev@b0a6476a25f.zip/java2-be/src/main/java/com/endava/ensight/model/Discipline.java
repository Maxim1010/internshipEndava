package com.endava.ensight.model;

public enum Discipline {
    AM {
        @Override
        public String toString() {
            return "AM";
        }
    },
    NET {
        @Override
        public String toString() {
            return "NET";
        }
    },
    JAVA {
        @Override
        public String toString() {
            return "JAVA";
        }
    },
    TESTING {
        @Override
        public String toString() {
            return "TESTING";
        }
    }
}
