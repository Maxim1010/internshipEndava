package com.endava.ensight.repository;


import com.endava.ensight.Application;
import com.endava.ensight.model.Discipline;
import com.endava.ensight.model.Question;
import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;


@Component
public class QuestionRepository implements CrudRepository<Question> {
    @PersistenceUnit
    private EntityManagerFactory entityManagerFactory;

    public QuestionRepository() {
        entityManagerFactory = Application.getEntityManagerFactory();
    }

    @Override
    public int create(Question question) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction entityTransaction = entityManager.getTransaction();
        try {
            entityTransaction.begin();

            entityManager.persist(question);
            entityTransaction.commit();
        } catch (Exception e) {
            if (entityTransaction != null)
                entityTransaction.rollback();
        } finally {
            entityManager.close();
        }
        return question.getId();
    }

    @Override
    public List<Question> readAll() {
        EntityManager em = entityManagerFactory.createEntityManager();
        TypedQuery<Question> query = em.createQuery("select t from Question t", Question.class);
        List<Question> questionsList = query.getResultList();
        em.close();
        return questionsList;
    }

    @Override
    public int update(Integer id, Question editedQuestion) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction entityTransaction = entityManager.getTransaction();
        int status = -1;
        try {
            entityTransaction.begin();
            Question question = entityManager.find(Question.class, id);
            question.setDiscipline(editedQuestion.getDiscipline());
            question.setType(editedQuestion.getType());
            question.setTitle(editedQuestion.getTitle());
            question.setNoOfPoints(editedQuestion.getNoOfPoints());
            question.setDifficulty(editedQuestion.getDifficulty());
            question.setCorrectAnswerText(editedQuestion.getCorrectAnswerText());
            question.setUpdatedAt(LocalDate.now());
            entityTransaction.commit();
            status = 0;

        } catch (Exception e) {
            if (entityTransaction != null)
                entityTransaction.rollback();
        } finally {
            entityManager.close();
        }
        System.out.println(status);
        return status;
    }

    @Override
    public int delete(Integer id) {

        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction entityTransaction = entityManager.getTransaction();
        int status = -1;
        try {
            entityTransaction.begin();

            Query query = entityManager.createQuery("delete from Answer a where a.questionId=" + id);
            query.executeUpdate();

            Question question = entityManager.find(Question.class, id);
            entityManager.remove(question);
            entityManager.flush();
            entityTransaction.commit();

            status = 0;
        } catch (Exception e) {
            if (entityTransaction != null)
                entityTransaction.rollback();
            e.printStackTrace();
        } finally {
            entityManager.close();
        }
        return status;
    }

    @Override
    public Question getById(Integer id) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction entityTransaction = entityManager.getTransaction();
        Question question = null;
        try {
            entityTransaction.begin();

            question = entityManager.find(Question.class, id);

            entityTransaction.commit();
        } catch (Exception ex) {
            if (entityTransaction != null)
                entityTransaction.rollback();
        } finally {
            entityManager.close();
        }
        return question;
    }

    public List<Question> getFilteredQuestionsSubList(int size, int page, int difficulty[], int type[], int discipline[]) {

        EntityManager em = entityManagerFactory.createEntityManager();

        StringBuilder queryString = new StringBuilder();
        queryString = queryString.append("select t from Question t");
        queryString = queryString.append(getQueryStringFilter(difficulty, type, discipline));
        TypedQuery<Question> query = em.createQuery(queryString.toString(), Question.class);
        List<Question> questionsList = query.getResultList();
        em.close();
        return questionsList;
    }

    public int getNumberOfFilteredAndSortedQuestions(int[] difficulty,
                                                     int[] type, int[] discipline, int sortField, String order) {

        EntityManager em = entityManagerFactory.createEntityManager();
        StringBuilder queryString = new StringBuilder();
        queryString = queryString.append("select COUNT(t) from Question t");
        queryString = queryString.append(getQueryStringFilter(difficulty, type, discipline));
        int count = ((Long) em.createQuery(queryString.toString()).getSingleResult()).intValue();
        em.close();
        return count;
    }

    public List<Question> getFilteredAndSortedQuestionsSubList(int size, int page, int[] difficulty,
                                                               int[] type, int[] discipline, int sortField, String order) {

        EntityManager em = entityManagerFactory.createEntityManager();
        StringBuilder queryString = new StringBuilder();
        queryString = queryString.append("select t from Question t");
        queryString = queryString.append(getQueryStringFilter(difficulty, type, discipline));
        queryString = queryString.append(getQueryStringSort(sortField, order));
        TypedQuery<Question> query = em.createQuery(queryString.toString(), Question.class);
        if (page <= 0) {
            page = 1;
        }
        query.setFirstResult((page - 1) * size);
        query.setMaxResults(size);
        List<Question> questionsList = query.getResultList();
        em.close();
        return questionsList;
    }

    private String getQueryStringSort(int sortField, String order) {
        StringBuilder queryString = new StringBuilder();
        if (sortField == 1) {
            queryString = queryString.append(" order by t.title " + order);
        } else if (sortField == 2) {
            queryString = queryString.append(" order by t.createdAt " + order);
        } else {
            queryString = queryString.append(" order by t.updatedAt " + order);
        }

        return queryString.toString();
    }

    private String getQueryStringFilter(int[] difficulty, int[] type, int[] discipline) {
        StringBuilder queryString = new StringBuilder();

        boolean filterApplied = true;
        int noFilters = difficulty.length;

        if (noFilters == 1) {
            queryString = queryString.append(" where t.difficulty = " + difficulty[0]);
        } else if (noFilters == 2) {
            queryString = queryString.append(" where (t.difficulty = " + difficulty[0] + " or t.difficulty = " + difficulty[1] + ")");
        } else {
            filterApplied = false;
        }

        noFilters = type.length;

        if (noFilters == 1) {
            if (!filterApplied) {
                queryString = queryString.append(" where ");
            } else {
                queryString = queryString.append(" and ");
            }
            queryString = queryString.append("t.type = " + type[0]);
            filterApplied = true;
        } else if (noFilters == 2) {
            if (!filterApplied) {
                queryString = queryString.append(" where ");
            } else {
                queryString = queryString.append(" and ");
            }
            queryString = queryString.append("( t.type = " + type[0] + " or t.type = " + type[1] + ")");
            filterApplied = true;
        }

        noFilters = discipline.length;
        if (noFilters >= Discipline.values().length)
            noFilters = 4;
        if (noFilters == 1) {
            if (!filterApplied) {
                queryString = queryString.append(" where ");
            } else {
                queryString = queryString.append(" and ");
            }
            queryString = queryString.append("t.discipline = com.endava.ensight.model.Discipline." + Discipline.values()[discipline[0] - 1]);
            filterApplied = true;
        } else if (noFilters == 2) {
            if (!filterApplied) {
                queryString = queryString.append(" where ");
            } else {
                queryString = queryString.append(" and ");
            }
            queryString = queryString.append("( t.discipline = com.endava.ensight.model.Discipline." + Discipline.values()[discipline[0] - 1]
                    + " or t.discipline = com.endava.ensight.model.Discipline." + Discipline.values()[discipline[1] - 1] + ")");
            filterApplied = true;
        } else if (noFilters == 3) {
            if (!filterApplied) {
                queryString = queryString.append(" where ");
            } else {
                queryString = queryString.append(" and ");
            }
            queryString = queryString.append("(t.discipline = com.endava.ensight.model.Discipline." + Discipline.values()[discipline[0] - 1]
                    + " or t.discipline = com.endava.ensight.model.Discipline." + Discipline.values()[discipline[1] - 1]
                    + " or t.discipline = com.endava.ensight.model.Discipline." + Discipline.values()[discipline[2] - 1] + ")");
            filterApplied = true;
        }

        return queryString.toString();
    }

    public int delete(List<Integer> questionIds) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        try {

            Query query = entityManager.createQuery("Delete q from Question WHERE q.id IN (:questionIds)");
            query.setParameter("questionIds", questionIds);
            query.executeUpdate();
        } catch (Exception e) {
            return -1;
        } finally {
            entityManager.close();
        }
        return 0;
    }

    public List<Question> getByDisciplineFilter(Discipline discipline) {
        EntityManager em = entityManagerFactory.createEntityManager();
        String disciplineString = discipline.toString();
        TypedQuery<Question> query = em.createQuery("select t from Question t where t.discipline = com.endava.ensight.model.Discipline." + disciplineString, Question.class);
        List<Question> questionsList = query.getResultList();
        em.close();
        return questionsList;
    }

    public List<Question> getByListOfIds(List<Integer> questionIds) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction entityTransaction = entityManager.getTransaction();
        List<Question> questions = Collections.emptyList();
        try {
            entityTransaction.begin();

            TypedQuery<Question> query = entityManager.createQuery("select q from Question q where q.id in :questionIds", Question.class);
            query.setParameter("questionIds", questionIds);
            questions = query.getResultList();
            entityTransaction.commit();
        } catch (Exception ex) {
            if (entityTransaction != null)
                entityTransaction.rollback();
        } finally {
            entityManager.close();
        }
        return questions;
    }
}
