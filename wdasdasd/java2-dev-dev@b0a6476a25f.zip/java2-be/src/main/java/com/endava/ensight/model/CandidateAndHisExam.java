package com.endava.ensight.model;

import javax.validation.constraints.NotNull;

public class CandidateAndHisExam {
    @NotNull
    private Candidate candidate;

    @NotNull
    private Exam exam;

    public CandidateAndHisExam() {
    }

    public CandidateAndHisExam(Candidate candidate, Exam exam) {
        this.candidate = candidate;
        this.exam = exam;
    }

    public Candidate getCandidate() {
        return candidate;
    }

    public void setCandidate(Candidate candidate) {
        this.candidate = candidate;
    }

    public Exam getExam() {
        return exam;
    }

    public void setExam(Exam exam) {
        this.exam = exam;
    }
}
