package com.endava.ensight.controller;

import com.endava.ensight.model.Campaign;
import com.endava.ensight.service.CampaignService;
import com.endava.ensight.validators.CampaignValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import java.util.List;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@CrossOrigin(value = "*")
@RestController
public class CampaignController {
    @Autowired
    CampaignService campaignService;

    @Autowired
    private CampaignValidator campaignValidator;

    @InitBinder
    public void initBinder(WebDataBinder binder, HttpServletRequest request) {
        binder.setValidator(campaignValidator);
    }

    @PostMapping(value = "/campaign", consumes = APPLICATION_JSON_VALUE)
    public ResponseEntity<Integer> createCampaign(@RequestBody @Valid Campaign campaign) {
        return new ResponseEntity<>(campaignService.createCampaign(campaign), HttpStatus.CREATED);
    }

    @GetMapping(value = "/campaign/{campaignId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Campaign> getCampaignById(@PathVariable Integer campaignId) {
        return new ResponseEntity<>(campaignService.getCampaignById(campaignId), HttpStatus.OK);
    }

    @GetMapping(value = "/campaigns", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Campaign>> getAllCampaigns() {
        return new ResponseEntity<>(campaignService.getAllCampaigns(), HttpStatus.OK);
    }

    @GetMapping(value = "/campaigns/last", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Integer> getLastCampaignId() {
        return new ResponseEntity<>(campaignService.getLastCampaignId(), HttpStatus.OK);
    }
}
