package com.endava.ensight.repository;

import java.util.List;


public interface CrudRepository<T> {

    int create(T obj);

    List<T> readAll();

    int update(Integer id, T obj);

    int delete(Integer id);

    T getById(Integer id);
}
