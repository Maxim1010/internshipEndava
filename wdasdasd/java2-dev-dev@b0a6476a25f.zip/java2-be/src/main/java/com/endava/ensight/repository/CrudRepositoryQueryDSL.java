package com.endava.ensight.repository;

import java.util.List;

public interface CrudRepositoryQueryDSL<T, U> {

    int create(T obj);

    List<T> readAll();

    void update(U id, T obj);

    void delete(U id);

    T getById(U id) throws Exception;


}
