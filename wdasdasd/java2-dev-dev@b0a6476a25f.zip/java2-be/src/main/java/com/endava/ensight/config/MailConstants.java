package com.endava.ensight.config;

public abstract class MailConstants {
    static String USERNAME = "EndavaRobotMailSender@gmail.com";
    static String PASS = "EndavaRobotSender";

    public static String getPASS() {
        return PASS;
    }

    public static String getUSERNAME() {
        return USERNAME;
    }
}
