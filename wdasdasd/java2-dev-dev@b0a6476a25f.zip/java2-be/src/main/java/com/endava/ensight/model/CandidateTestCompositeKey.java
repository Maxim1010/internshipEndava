package com.endava.ensight.model;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class CandidateTestCompositeKey implements Serializable {
    @Column(name = "candidate_id")
    private int candidateId;

    @Column(name = "test_id")
    private int testId;

    public CandidateTestCompositeKey() {
    }

    public CandidateTestCompositeKey(int candidateId, int testId) {
        this.candidateId = candidateId;
        this.testId = testId;
    }

    public int getCandidateId() {
        return candidateId;
    }

    public void setCandidateId(int candidateId) {
        this.candidateId = candidateId;
    }

    public int getTestId() {
        return testId;
    }

    public void setTestId(int testId) {
        this.testId = testId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CandidateTestCompositeKey that = (CandidateTestCompositeKey) o;
        return candidateId == that.candidateId &&
                testId == that.testId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(candidateId, testId);
    }

    public int getCompositeId() {
        return Integer.parseInt(new StringBuilder(String.valueOf(candidateId) + String.valueOf(testId)).toString());
    }
}
