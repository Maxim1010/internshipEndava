package com.endava.ensight.controller;

import com.endava.ensight.model.Answer;
import com.endava.ensight.service.AnswerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
public class AnswerController {
    @Autowired
    private AnswerService answerService;

    @GetMapping(value = "/answers", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Answer>> getAnswersByQuestionId(@RequestParam(value = "questionId") int questionId) {
        return new ResponseEntity<>(answerService.getAnswersByQuestionId(questionId), HttpStatus.OK);
    }

    @GetMapping(value = "/answer/{answerId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Answer> getAnswerById(@PathVariable int answerId) {
        return new ResponseEntity<>(answerService.getAnswerById(answerId), HttpStatus.OK);
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @PostMapping(value = "/answer/create", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Number> createAnswer(@RequestBody Answer answer) {
        return new ResponseEntity<>(answerService.createAnswer(answer), HttpStatus.OK);
    }

    @PostMapping(value = "answer/create/multiple", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Integer> createAnswer(@RequestBody List<Answer> answers) {
        return new ResponseEntity<>(answerService.createAnswerMultiple(answers), HttpStatus.OK);
    }

    @PutMapping(value = "answer/edit/multiple", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Integer> editAnswerMultiple(@RequestBody List<Answer> answers) {
        return new ResponseEntity<>(answerService.editAnswerMultiple(answers), HttpStatus.OK);
    }

    @PutMapping(value = "answer/edit", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Integer> editAnswer(@RequestBody Answer answer) {
        return new ResponseEntity<>(answerService.editAnswer(answer), HttpStatus.OK);
    }

    @DeleteMapping(value = "/answers/delete/excepting/{answerId}")
    public ResponseEntity<Integer> deleteAllAnswersForAQuestionWithTheException(@PathVariable int answerId) {
        return new ResponseEntity<>(answerService.deleteAllAnswersForAQuestionWithTheException(answerId), HttpStatus.OK);
    }
}
