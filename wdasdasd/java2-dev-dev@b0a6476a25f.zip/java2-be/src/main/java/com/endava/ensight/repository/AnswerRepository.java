package com.endava.ensight.repository;

import com.endava.ensight.Application;
import com.endava.ensight.model.Answer;
import com.endava.ensight.model.Question;
import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class AnswerRepository implements CrudRepository<Answer> {
    @PersistenceUnit
    private EntityManagerFactory entityManagerFactory;

    public AnswerRepository() {
        this.entityManagerFactory = Application.getEntityManagerFactory();
    }

    @Override
    public int create(Answer answer) {
        Answer newAnswer = new Answer();
        newAnswer.setQuestionId(answer.getQuestionId());
        newAnswer.setAnswerText(answer.getAnswerText());
        newAnswer.setAnswerId(answer.getAnswerId());

        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction entityTransaction = entityManager.getTransaction();
        try {
            entityTransaction.begin();

            entityManager.persist(newAnswer);
            Question question = entityManager.find(Question.class, answer.getQuestionId());
            question.setCorrectAnswerText(newAnswer.getAnswerText());
            entityManager.persist(question);
            newAnswer.setQuestion(question);
            entityTransaction.commit();
        } catch (Exception e) {
            if (entityTransaction != null)
                entityTransaction.rollback();
        } finally {
            entityManager.close();
        }
        return newAnswer.getAnswerId();
    }

    @Override
    public List<Answer> readAll() {
        EntityManager em = entityManagerFactory.createEntityManager();
        TypedQuery<Answer> query = em.createQuery("select t from Question t", Answer.class);
        List<Answer> answerList = query.getResultList();
        em.close();
        return answerList;
    }

    @Override
    public int update(Integer id, Answer editedAnswer) {

        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction entityTransaction = entityManager.getTransaction();
        int status = -1;
        try {
            entityTransaction.begin();
            Answer answer = entityManager.find(Answer.class, id);
            answer.setAnswerText(editedAnswer.getAnswerText());
            entityTransaction.commit();
            status = 0;

        } catch (Exception e) {
            if (entityTransaction != null)
                entityTransaction.rollback();
        } finally {
            entityManager.close();
        }
        System.out.println(status);
        return status;
    }

    @Override
    public int delete(Integer id) {
        return 0;
    }

    @Override
    public Answer getById(Integer id) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction entityTransaction = entityManager.getTransaction();
        Answer answer = null;
        try {
            entityTransaction.begin();

            answer = entityManager.find(Answer.class, id);

            entityTransaction.commit();
        } catch (Exception ex) {
            if (entityTransaction != null)
                entityTransaction.rollback();
        } finally {
            entityManager.close();
        }
        return answer;
    }

    public List<Answer> getAllAnswersByQuestionId(Integer questionId) {
        EntityManager em = entityManagerFactory.createEntityManager();
        TypedQuery<Answer> query = em.createQuery("select a from Answer a WHERE a.questionId=:questionId order by a.answerId", Answer.class);
        query.setParameter("questionId", questionId);
        List<Answer> answerList = query.getResultList();
        em.close();
        return answerList;

    }


    public Integer createMultipleAnswer(List<Answer> answers) {
        EntityManager em = entityManagerFactory.createEntityManager();
        int status = -1;
        try {
            em.getTransaction().begin();

            for (Answer a : answers) {
                em.persist(a);
                em.flush();
            }
            status = 0;
            em.getTransaction().commit();

        } catch (Exception e) {
            if (em.getTransaction() != null) {
                em.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
        }
        return status;
    }

    public int updateMultiple(List<Answer> answers) {

        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction entityTransaction = entityManager.getTransaction();
        int status = -1;
        try {
            entityTransaction.begin();
            List<Integer> answerIds = new ArrayList<>();

            for (Answer a : answers) {
                answerIds.add(a.getAnswerId());
            }
            answerIds = answerIds.stream().sorted(Integer::compareTo).collect(Collectors.toList());

            for (int i = 0; i < answerIds.size(); i++) {
                System.out.println(answerIds.get(i));
            }
            for (int i = 0; i < answerIds.size(); i++) {
                Answer answer = entityManager.find(Answer.class, answerIds.get(i));
                answer.setAnswerText(answers.get(i).getAnswerText());
                System.out.println(answer.getAnswerId() + " --> " + answer.getAnswerText());
            }
            entityTransaction.commit();
            status = 0;

        } catch (Exception e) {
            if (entityTransaction != null)
                entityTransaction.rollback();
        } finally {
            entityManager.close();
        }
        return status;
    }

    public int deleteAllAnswersForAQuestionWithTheException(int answerId) {

        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction entityTransaction = entityManager.getTransaction();
        int status = -1;
        Answer answer = null;
        try {
            entityTransaction.begin();
            answer = entityManager.find(Answer.class, answerId);
            Query query = entityManager.createQuery("delete from Answer a where a.questionId="
                    + answer.getQuestionId() + " and " + "a.answerId <> " + answerId);
            query.executeUpdate();
            entityTransaction.commit();

            status = 0;
        } catch (Exception e) {
            if (entityTransaction != null)
                entityTransaction.rollback();
            e.printStackTrace();
        } finally {
            entityManager.close();
        }
        return status;
    }
}
