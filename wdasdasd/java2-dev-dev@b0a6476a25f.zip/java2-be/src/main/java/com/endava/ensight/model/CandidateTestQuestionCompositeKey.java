package com.endava.ensight.model;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class CandidateTestQuestionCompositeKey implements Serializable {
    @Column(name = "candidate_id")
    private int candidateId;

    @Column(name = "test_id")
    private int testId;

    @Column(name = "question_id")
    private int questionId;

    public int getCandidateId() {
        return candidateId;
    }

    public void setCandidateId(int candidateId) {
        this.candidateId = candidateId;
    }

    public int getTestId() {
        return testId;
    }

    public void setTestId(int testId) {
        this.testId = testId;
    }

    public int getQuestionId() {
        return questionId;
    }

    public void setQuestionId(int questionId) {
        this.questionId = questionId;
    }

    public CandidateTestQuestionCompositeKey() {
    }

    public CandidateTestQuestionCompositeKey(int candidateId, int testId, int questionId) {
        this.candidateId = candidateId;
        this.testId = testId;
        this.questionId = questionId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CandidateTestQuestionCompositeKey that = (CandidateTestQuestionCompositeKey) o;
        return candidateId == that.candidateId &&
                testId == that.testId &&
                questionId == that.questionId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(candidateId, testId, questionId);
    }

    public int getCompositeId() {
        return Integer.parseInt(""+candidateId + testId + questionId);
    }
}
