package com.endava.ensight.model;

public enum Status {
    READY_TO_SEND,
    READY_TO_GRADE,
    SENT,
    GRADED
}
