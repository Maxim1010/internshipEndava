package com.endava.ensight.repository;

import com.endava.ensight.Application;
import com.endava.ensight.model.AnswerFromCandidate;
import com.endava.ensight.model.CandidateTestQuestionCompositeKey;
import com.endava.ensight.model.QAnswerFromCandidate;
import com.endava.ensight.model.QExam;
import com.querydsl.jpa.impl.JPAQueryFactory;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import java.util.List;

@Component
public class AnswerFromCandidateRepository implements CrudRepositoryQueryDSL<AnswerFromCandidate, CandidateTestQuestionCompositeKey> {
    @PersistenceUnit
    private EntityManagerFactory entityManagerFactory;

    public AnswerFromCandidateRepository() {
        this.entityManagerFactory = Application.getEntityManagerFactory();
    }

    @Override
    public int create(AnswerFromCandidate answerFromCandidate) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction entityTransaction = entityManager.getTransaction();
        try {
            entityTransaction.begin();

            entityManager.persist(answerFromCandidate);
            entityTransaction.commit();
        } catch (Exception e) {
            if (entityTransaction != null)
                entityTransaction.rollback();
        } finally {
            entityManager.close();
        }
        return answerFromCandidate.getId().getCompositeId();
    }

    @Override
    public List<AnswerFromCandidate> readAll() {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        QAnswerFromCandidate qAnswerFromCandidate = QAnswerFromCandidate.answerFromCandidate;
        JPAQueryFactory queryFactory = new JPAQueryFactory(entityManager);
        List<AnswerFromCandidate> result = queryFactory.selectFrom(qAnswerFromCandidate).fetch();
        entityManager.close();
        return result;
    }

    @Override
    public void update(CandidateTestQuestionCompositeKey id, AnswerFromCandidate answerFromCandidate) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        QAnswerFromCandidate qAnswerFromCandidate = QAnswerFromCandidate.answerFromCandidate;
        JPAQueryFactory queryFactory = new JPAQueryFactory(entityManager);
        EntityTransaction entityTransaction = entityManager.getTransaction();

        try {
            entityTransaction.begin();

            queryFactory.update(qAnswerFromCandidate)
                    .where(qAnswerFromCandidate.id.eq(id))
                    .set(qAnswerFromCandidate.answerText, answerFromCandidate.getAnswerText())
                    .set(qAnswerFromCandidate.isCorrect, answerFromCandidate.isCorrect())
                    .execute();
            entityManager.close();

            entityTransaction.commit();
        } catch (Exception e) {
            if (entityTransaction != null)
                entityTransaction.rollback();
        } finally {
            entityManager.close();
        }
    }

    @Override
    public void delete(CandidateTestQuestionCompositeKey id) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        QAnswerFromCandidate qAnswerFromCandidate = QAnswerFromCandidate.answerFromCandidate;
        JPAQueryFactory queryFactory = new JPAQueryFactory(entityManager);
        queryFactory.delete(qAnswerFromCandidate)
                .where(qAnswerFromCandidate.id.eq(id))
                .execute();
        entityManager.close();
    }

    @Override
    public AnswerFromCandidate getById(CandidateTestQuestionCompositeKey id) throws Exception{
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        QAnswerFromCandidate qAnswerFromCandidate = QAnswerFromCandidate.answerFromCandidate;
        JPAQueryFactory queryFactory = new JPAQueryFactory(entityManager);
        try {

            return queryFactory.selectFrom(qAnswerFromCandidate)
                    .where(qAnswerFromCandidate.id.eq(id))
                    .fetchOne();
        } catch (Exception e) {
            throw new Exception("Not found");
        }
        finally {
            entityManager.close();
        }


    }
}
