package com.endava.ensight.model;

import javax.persistence.*;

@Entity
@Table(name = "candidates_campaign")
public class CandidateForCampaign {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "candidate_id")
    private int candidateId;

    @Column(name = "campaign_id")
    private int campaignId;


    public CandidateForCampaign() {
    }

    public CandidateForCampaign( int candidateId, int campaignId) {
        this.candidateId = candidateId;
        this.campaignId = campaignId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCandidateId() {
        return candidateId;
    }

    public void setCandidateId(int candidateId) {
        this.candidateId = candidateId;
    }

    public int getCampaignId() {
        return campaignId;
    }

    public void setCampaignId(int campaignId) {
        this.campaignId = campaignId;
    }
}
