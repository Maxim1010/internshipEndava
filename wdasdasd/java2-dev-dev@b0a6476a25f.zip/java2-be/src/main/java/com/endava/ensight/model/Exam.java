package com.endava.ensight.model;

import javax.persistence.*;
import java.sql.Timestamp;
import java.time.LocalDateTime;

@Entity(name = "Exam")
@Table(name = "exams")
public class Exam {

    @EmbeddedId
    private CandidateTestCompositeKey id;

    @Column(name = "grade")
    private Float grade;

    @Column(name = "status")
    @Enumerated(EnumType.STRING)
    private Status status;

    @Column(name = "start_time")
    private LocalDateTime startTime;

    @Column(name = "end_time")
    private LocalDateTime endTime;

    public Exam() {
    }

    public Exam(CandidateTestCompositeKey id, Status status) {
        this.id = id;
        this.status = status;
    }

    public Exam(CandidateTestCompositeKey id, Float grade, Status status) {
        this.id = id;
        this.grade = grade;
        this.status = status;
    }

    public Exam(Status status) {
        this.status = status;
    }

    public Exam(CandidateTestCompositeKey id, float grade, LocalDateTime startTime, LocalDateTime endTime) {
        this.id = id;
        this.grade = grade;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public CandidateTestCompositeKey getId() {
        return id;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public void setId(CandidateTestCompositeKey id) {
        this.id = id;
    }

    public Float getGrade() {
        return grade;
    }

    public void setGrade(Float grade) {
        this.grade = grade;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }


}
