package com.endava.ensight.validators;

import com.endava.ensight.model.Candidate;
import com.endava.ensight.model.Discipline;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CandidateExcelValidator {
    private static Pattern letter = Pattern.compile("[a-zA-z]");
    private static Pattern digit = Pattern.compile("[0-9]");
    private static Pattern special = Pattern.compile ("[!@#$%&*()_+=|<>?{}\\[\\]~-]");
    private static Pattern email = Pattern.compile("^[a-zA-Z0-9_!#$%&’*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$", Pattern.CASE_INSENSITIVE);
    private static Pattern specialForPhone = Pattern.compile ("[!@#$%&*()_=|<>?{}\\[\\]~-]");

    public static String validate(Candidate candidate){
        StringBuilder errors = new StringBuilder();
        errors.append(validateContainsOnlyLetters(candidate.getForename()));
        errors.append(validateContainsOnlyLetters(candidate.getSurname()));
        errors.append(validateContainsOnlyLetters(candidate.getUniversity()));
        errors.append(validateContainsOnlyLetters(candidate.getFaculty()));
        errors.append(validateIsNumber(candidate.getStudyYear()));
        errors.append(validateDiscipline(candidate.getDiscipline()));
        errors.append(validateEmail(candidate.getEmail()));
        errors.append(validateContainsOnlyDigits(candidate.getPhone()));
        errors.append(validatePhoneNumberLength(candidate.getPhone()));
        return errors.toString();
    }

    private static String validatePhoneNumberLength(String phone) {
        StringBuilder errors = new StringBuilder();
        if(phone.length() < 10)
            errors.append("phone number has too few digits (less than 10)\n");
        if(phone.length() > 13)
            errors.append("phone number has too many digits (over 13)\n");
        return errors.toString();
    }

    private static String validateContainsOnlyDigits(String phone) {
        StringBuilder errors = new StringBuilder();

        Matcher letterMatcher = letter.matcher(phone);
        Matcher specialCharacterMatcher = specialForPhone.matcher(phone);

        if(letterMatcher.find())
            errors.append("phone number contains letters");
        if(specialCharacterMatcher.find()) {
            errors.append("phone number contains special characters (other than \"+\"\n");
        }
        return errors.toString();
    }

    private static String validateEmail(String inputEmail) {
        Matcher emailMatcher = email.matcher(inputEmail);
        System.out.println(emailMatcher.matches());
        if(emailMatcher.matches())
            return "";
        else {
            return "email is not valid";
        }

    }

    private static String validateDiscipline(Discipline discipline) {
        if (discipline == null) {
            return "discipline should have one of the following values: AM, NET, JAVA, TESTING\n";
        }
        else return "";
    }

    private static String validateIsNumber(Integer studyYear) {
        if(studyYear < 1)
            return "study year should not be a negative integer\n";
        else
            return "";
    }

    private static String validateContainsOnlyLetters(String forename) {
        StringBuilder errors = new StringBuilder();

        Matcher digitMatcher = digit.matcher(forename);
        Matcher specialCharMatcher = special.matcher(forename);

        if(digitMatcher.find())
            errors.append("forename").append(" ").append("should not contain digits.\n");
        if(specialCharMatcher.find())
            errors.append("forename").append(" ").append(" should not contain special characters\n");

        return errors.toString();
    }
}
