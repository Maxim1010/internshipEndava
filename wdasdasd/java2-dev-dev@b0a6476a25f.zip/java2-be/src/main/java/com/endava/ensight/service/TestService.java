package com.endava.ensight.service;

import com.endava.ensight.model.*;
import com.endava.ensight.repository.TestRepository;
import com.endava.ensight.utils.Pagination;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static java.lang.Math.min;

@Service
public class TestService {
    @Autowired
    private TestRepository testRepository;

    @Autowired
    private QuestionService questionService;

    @Autowired
    private QuestionForTestService questionForTestService;

    public Number createTest(Test test) {
        test.setCreatedAt(LocalDate.now());
        test.setUpdatedAt(LocalDate.now());
        test.setName(test.getDiscipline() + " - " + test.getCreatedAt());
        return testRepository.create(test);
    }

    public List<Test> getAllTests() {
        return testRepository.readAll();
    }

    public Test getTestById(Integer testId) {
        return testRepository.getById(testId);
    }

    public List<Test> getTestsSublist(int size, int page) {
        List<Test> tests = testRepository.readAll();
        Pagination pagination = new Pagination();
        tests = pagination.getSubList(size, page, tests);
        return tests;
    }

    public Integer deleteTestById(Integer testId) {
        Integer statusDeleteLinks = questionForTestService.deleteByTestId(testId);
        Integer statusDeleteTest = 0;
        if (statusDeleteLinks == 0)
            statusDeleteTest = testRepository.delete(testId);
        return min(statusDeleteLinks, statusDeleteTest);
    }

    public Integer deleteTests(List<Integer> testIds) {
        for (Integer testId : testIds) {
            if (deleteTestById(testId).equals(-1))
                return -1;
        }
        return 0;
    }

    public List<Test> getFilteredAndSortedQuestionsSubList(int size, int page, int[] discipline, int sortField, String order) {
        return testRepository.getFilteredAndSortedQuestionsSubList(size, page, discipline, sortField, order);
    }

    public List<Question> getQuestionsByTestId(Integer testId) {
        List<Integer> questionIds = questionForTestService.getQuestionsIdsByTestId(testId);
        return questionService.getByListOfIds(questionIds);
    }

    public Integer generateTests(GeneralParams generalParams) {
        try {
            List<Question> questions = questionService.getFilteredQuestions(generalParams.getDiscipline());

            if (questions.size() < generalParams.getNumberOfQuestions())
                return -1;

            List<Question> easyQuestions = getSublistByDifficulty(questions, "easy");
            List<Question> mediumQuestions = getSublistByDifficulty(questions, "medium");
            List<Question> hardQuestions = getSublistByDifficulty(questions, "hard");

            Integer numberOfHardQuestions = generalParams.getHardPercent() / generalParams.getNumberOfQuestions();
            Integer numberOfMediumQuestions = generalParams.getMediumPercent() / generalParams.getNumberOfQuestions();
            Integer numberOfEasyQuestions = generalParams.getNumberOfQuestions() - (numberOfHardQuestions + numberOfMediumQuestions);

            if (numberOfEasyQuestions > easyQuestions.size() ||
                    numberOfMediumQuestions > mediumQuestions.size() ||
                    numberOfHardQuestions > hardQuestions.size())
                return -1;


            String testName = generateTestName(generalParams);

            for (Integer i = 0; i < generalParams.getNumberOfTests(); i++) {
                Test test = new Test(testName, generalParams.getDiscipline(), generalParams.getNumberOfQuestions());
                testRepository.create(test);

                shuffleQuestions(easyQuestions, mediumQuestions, hardQuestions);

                List<Question> questionsForCurrentTest = new ArrayList<>();
                populateQuestionsForCurrentTest(easyQuestions, mediumQuestions, hardQuestions, numberOfHardQuestions, numberOfMediumQuestions, numberOfEasyQuestions, questionsForCurrentTest);

                for (Question question : questionsForCurrentTest) {
                    QuestionForTest questionForTest = new QuestionForTest(question.getId(), test.getId());
                    questionForTestService.create(questionForTest);
                }
            }
        } catch (Exception e) {
            return -1;
        }
        return 0;
    }

    private void populateQuestionsForCurrentTest(List<Question> easyQuestions, List<Question> mediumQuestions, List<Question> hardQuestions, Integer numberOfHardQuestions, Integer numberOfMediumQuestions, Integer numberOfEasyQuestions, List<Question> questionsForCurrentTest) {
        questionsForCurrentTest.addAll(easyQuestions.subList(0, numberOfEasyQuestions));
        questionsForCurrentTest.addAll(mediumQuestions.subList(0, numberOfMediumQuestions));
        questionsForCurrentTest.addAll(hardQuestions.subList(0, numberOfHardQuestions));
    }

    private void shuffleQuestions(List<Question> easyQuestions, List<Question> mediumQuestions, List<Question> hardQuestions) {
        Collections.shuffle(easyQuestions);
        Collections.shuffle(mediumQuestions);
        Collections.shuffle(hardQuestions);
    }

    private String generateTestName(GeneralParams generalParams) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
        return new StringBuilder(
                generalParams.getDiscipline().toString() + " - " +
                        LocalDate.now() + " - " +
                        LocalTime.now().getHour() + ":" +
                        LocalTime.now().format(DateTimeFormatter.ofPattern("mm")))
                .toString();
    }

    public List<Question> getSublistByDifficulty(List<Question> questions, String difficulty) {
        Integer difficultyNumber = parseDifficulty(difficulty);
        return questions.stream()
                .filter(question -> question.getDifficulty() == difficultyNumber).collect(Collectors.toList());
    }

    private Integer parseDifficulty(String difficulty) {
        Integer difficultyNumber;
        switch (difficulty) {
            case "easy":
                difficultyNumber = 1;
                break;
            case "medium":
                difficultyNumber = 2;
                break;
            case "hard":
                difficultyNumber = 3;
                break;
            default:
                difficultyNumber = 1;
                break;
        }
        return difficultyNumber;
    }


    public Integer updateTest(Test test) {
        return testRepository.update(test.getId(), test);
    }

    public Long countTests(int[] discipline) {
        return testRepository.countTests(discipline);
    }

    public List<Test> getAllFilteredTests(Discipline discipline) {
        try {
            return testRepository.getAllFilteredTests(discipline);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
