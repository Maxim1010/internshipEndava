package com.endava.ensight.model;


import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;


@Entity(name = "Campaign")
@Table(name = "campaigns")
public class Campaign {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @NotNull
    @Column(name = "name")
    private String name;

    @NotNull
    @Column(name = "accounted_person")
    private String accountedPerson;

    @NotNull
    @Column(name = "net_candidates")
    private int netCandidates;

    @NotNull
    @Column(name = "java_candidates")
    private int javaCandidates;

    @NotNull
    @Column(name = "am_candidates")
    private int amCandidates;

    @NotNull
    @Column(name = "testing_candidates")
    private int testingCandidates;

    @NotNull
    @Column(name = "start_campaign")
    private LocalDate startCampaign;


    @NotNull
    @Column(name = "start_promoting")
    private LocalDate startPromoting;

    @NotNull
    @Column(name = "start_tests")
    private LocalDate startTests;

    @NotNull
    @Column(name = "start_internship")
    private LocalDate startInternship;

    @NotNull
    @Column(name = "end_internship")
    private LocalDate endInternship;

    public Campaign() {
    }

    public Campaign(int id, @NotNull String name, @NotNull String accountedPerson, @NotNull int netCandidates, @NotNull int javaCandidates, @NotNull int amCandidates, @NotNull int testingCandidates, LocalDate startCampaign, LocalDate startPromoting, LocalDate startTests, LocalDate startInternship, LocalDate endInternship) {
        this.id = id;
        this.name = name;
        this.accountedPerson = accountedPerson;
        this.netCandidates = netCandidates;
        this.javaCandidates = javaCandidates;
        this.amCandidates = amCandidates;
        this.testingCandidates = testingCandidates;
        this.startCampaign = startCampaign;
        this.startPromoting = startPromoting;
        this.startTests = startTests;
        this.startInternship = startInternship;
        this.endInternship = endInternship;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAccountedPerson() {
        return accountedPerson;
    }

    public void setAccountedPerson(String accountedPerson) {
        this.accountedPerson = accountedPerson;
    }

    public int getNetCandidates() {
        return netCandidates;
    }

    public void setNetCandidates(int netCandidates) {
        this.netCandidates = netCandidates;
    }

    public int getJavaCandidates() {
        return javaCandidates;
    }

    public void setJavaCandidates(int javaCandidates) {
        this.javaCandidates = javaCandidates;
    }

    public int getAmCandidates() {
        return amCandidates;
    }

    public void setAmCandidates(int amCandidates) {
        this.amCandidates = amCandidates;
    }

    public int getTestingCandidates() {
        return testingCandidates;
    }

    public void setTestingCandidates(int testingCandidates) {
        this.testingCandidates = testingCandidates;
    }

    public LocalDate getStartCampaign() {
        return startCampaign;
    }

    public void setStartCampaign(LocalDate startCampaign) {
        this.startCampaign = startCampaign;
    }

    public LocalDate getStartPromoting() {
        return startPromoting;
    }

    public void setStartPromoting(LocalDate startPromoting) {
        this.startPromoting = startPromoting;
    }

    public LocalDate getStartTests() {
        return startTests;
    }

    public void setStartTests(LocalDate startTests) {
        this.startTests = startTests;
    }

    public LocalDate getStartInternship() {
        return startInternship;
    }

    public void setStartInternship(LocalDate startInternship) {
        this.startInternship = startInternship;
    }

    public LocalDate getEndInternship() {
        return endInternship;
    }

    public void setEndInternship(LocalDate endInternship) {
        this.endInternship = endInternship;
    }
}
