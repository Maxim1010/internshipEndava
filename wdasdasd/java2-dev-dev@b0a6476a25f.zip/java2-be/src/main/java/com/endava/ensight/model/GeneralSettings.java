package com.endava.ensight.model;

import javax.persistence.*;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

@Entity
@Table(name = "global_settings")
public class GeneralSettings {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @NotNull
    @Min(value = 0)
    @Column(name = "duration")
    private int duration;

    @NotNull
    @Min(value = 0)
    @Column(name = "link_availability")
    private int linkAvailability;

    @NotNull
    @Column(name = "instructions")
    private String instructions;

    @NotNull
    @Column(name = "summary")
    private String summary;

    @Column(name = "created_at")
    private LocalDate createdAt;

    @Column(name = "updated_at")
    private LocalDate updatedAt;

    public GeneralSettings() {
    }

    public GeneralSettings(int duration, int linkAvailability, String instructions, String summary) {
        this.duration = duration;
        this.linkAvailability = linkAvailability;
        this.instructions = instructions;
        this.summary = summary;
        this.createdAt = LocalDate.now();
        this.updatedAt = LocalDate.now();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public int getLinkAvailability() {
        return linkAvailability;
    }

    public void setLinkAvailability(int linkAvailability) {
        this.linkAvailability = linkAvailability;
    }

    public String getInstructions() {
        return instructions;
    }

    public void setInstructions(String instructions) {
        this.instructions = instructions;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public LocalDate getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDate createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDate getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDate updatedAt) {
        this.updatedAt = updatedAt;
    }
}
