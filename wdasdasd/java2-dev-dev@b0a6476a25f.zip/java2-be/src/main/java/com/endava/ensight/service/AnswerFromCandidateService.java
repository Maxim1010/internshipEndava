package com.endava.ensight.service;

import com.endava.ensight.model.Answer;
import com.endava.ensight.model.AnswerFromCandidate;
import com.endava.ensight.model.CandidateTestQuestionCompositeKey;
import com.endava.ensight.repository.AnswerFromCandidateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AnswerFromCandidateService {
    @Autowired
    AnswerFromCandidateRepository answerFromCandidateRepository;

    public Integer createAnswerFromCandidate(AnswerFromCandidate answerFromCandidate) {
        return answerFromCandidateRepository.create(answerFromCandidate);
    }

    public AnswerFromCandidate getAnswerFromCandidateById(CandidateTestQuestionCompositeKey id) {
        try {
            return answerFromCandidateRepository.getById(id);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void updateAnswerFromCandidate(AnswerFromCandidate answerFromCandidate) {
        answerFromCandidateRepository.update(answerFromCandidate.getId(), answerFromCandidate);
    }

    public AnswerFromCandidate getAnswerFromCandidateById(Integer candidateId, Integer testId, Integer questionId) {
        try {
            return answerFromCandidateRepository.getById(new CandidateTestQuestionCompositeKey(candidateId,testId,questionId));
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
