package com.endava.ensight.controller;

import com.endava.ensight.model.Exam;
import com.endava.ensight.service.ExamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@CrossOrigin(value = "*")
@RestController
public class ExamController {
    @Autowired
    ExamService examService;

    @PostMapping(value = "/exam", consumes = APPLICATION_JSON_VALUE)
    public ResponseEntity<Integer> createExam(@RequestBody @Valid Exam exam) {
        return new ResponseEntity<>(examService.createExam(exam), HttpStatus.CREATED);
    }

    @GetMapping(value = "/exams/{candidateId}-{testId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Exam> getExamById(@PathVariable Integer candidateId,@PathVariable Integer testId) {
        return new ResponseEntity<>(examService.getExamById(candidateId, testId), HttpStatus.OK);
    }

    @GetMapping(value = "/exams/is-started/{candidateId}-{testId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Boolean> isStarted(@PathVariable Integer candidateId, @PathVariable Integer testId) {
        return new ResponseEntity<>(examService.isStarted(candidateId, testId), HttpStatus.OK);
    }

    @PutMapping(value = "/exam/edit")
    @ResponseBody
    public void editExam(@RequestBody @Valid Exam exam) {
        examService.updateExam(exam);
    }

    @GetMapping(value = "/exam/end/{candidateId}-{testId}",  produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> endExam(@PathVariable Integer candidateId, @PathVariable Integer testId) {
        return new ResponseEntity<>(examService.endExam(candidateId,testId),HttpStatus.OK);
    }


    @GetMapping(value = "/exam/start/{candidateId}-{testId}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus
    public ResponseEntity<String> startExam(@PathVariable Integer candidateId, @PathVariable Integer testId) {
        return new ResponseEntity<>(examService.startExam(candidateId,testId),HttpStatus.OK);
    }
}
