package com.endava.ensight.repository;

import com.endava.ensight.Application;
import com.endava.ensight.model.Candidate;
import com.endava.ensight.model.QCandidate;
import com.endava.ensight.model.Question;
import com.querydsl.jpa.impl.JPAQueryFactory;
import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Component
public class CandidateRepository implements CrudRepositoryQueryDSL<Candidate, Integer> {
    @PersistenceUnit
    private EntityManagerFactory entityManagerFactory;

    public CandidateRepository() {
        this.entityManagerFactory = Application.getEntityManagerFactory();
    }

    public int create(Candidate candidate) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction entityTransaction = entityManager.getTransaction();
        try {
            entityTransaction.begin();

            entityManager.persist(candidate);
            entityManager.close();
            entityTransaction.commit();
        } catch (Exception e) {
            if (entityTransaction != null)
                entityTransaction.rollback();
        } finally {
            entityManager.close();
        }
        return candidate.getId();
    }

    public List<Candidate> readAll() {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        QCandidate qCandidate = QCandidate.candidate;
        JPAQueryFactory queryFactory = new JPAQueryFactory(entityManager);
        List<Candidate> result = queryFactory.selectFrom(qCandidate).fetch();
        entityManager.close();
        return result;
    }

    public void update(Integer id, Candidate candidate) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        QCandidate qCandidate = QCandidate.candidate;
        JPAQueryFactory queryFactory = new JPAQueryFactory(entityManager);
        EntityTransaction entityTransaction = entityManager.getTransaction();

        try {
            entityTransaction.begin();

            queryFactory.update(qCandidate)
                    .where(qCandidate.id.eq(candidate.getId()))
                    .set(qCandidate, candidate)
                    .execute();

            entityTransaction.commit();
        } catch (Exception e) {
            if (entityTransaction != null)
                entityTransaction.rollback();
        } finally {
            entityManager.close();
        }
    }

    public void delete(Integer id) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        QCandidate qCandidate = QCandidate.candidate;
        JPAQueryFactory queryFactory = new JPAQueryFactory(entityManager);
        EntityTransaction entityTransaction = entityManager.getTransaction();

        try {
            entityTransaction.begin();

            queryFactory.delete(qCandidate)
                    .where(qCandidate.id.eq(id))
                    .execute();
            entityManager.persist(qCandidate);
            entityManager.flush();

            entityTransaction.commit();
        } catch (Exception e) {
            if (entityTransaction != null)
                entityTransaction.rollback();
        } finally {
            entityManager.close();
        }
    }

    public Candidate getById(Integer id) throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        QCandidate qCandidate = QCandidate.candidate;
        JPAQueryFactory queryFactory = new JPAQueryFactory(entityManager);
        try {
            return queryFactory.selectFrom(qCandidate)
                    .where(qCandidate.id.eq(id))
                    .fetchOne();
        } catch (Exception e) {
            throw new Exception("Not found");
        }
        finally {
            entityManager.close();
        }
    }

    public List<Candidate> getByListOfIds(List<Integer> ids){
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        QCandidate qCandidate = QCandidate.candidate;
        JPAQueryFactory queryFactory = new JPAQueryFactory(entityManager);

        EntityTransaction entityTransaction = entityManager.getTransaction();
        List candidates = new ArrayList<>();

        try {
            entityTransaction.begin();
            entityManager.flush();
            candidates = queryFactory.selectFrom(qCandidate).where(qCandidate.id.in(ids)).fetch();
//            candidates = entityManager.createQuery("SELECT c FROM Candidate c WHERE c.id IN :ids")
//                    .setParameter("ids", ids)
//                    .getResultList();
            entityTransaction.commit();
        } catch (Exception ex) {
            if (entityTransaction != null)
                entityTransaction.rollback();
        } finally {
            entityManager.close();
        }
        return candidates;

    }
}
