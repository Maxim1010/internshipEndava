package com.endava.ensight.model;

import org.hibernate.annotations.ColumnDefault;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;

@Entity(name = "Candidate")
@Table(name = "candidates")
public class Candidate implements Serializable {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @NotNull
    @Size(min = 3)
    @Column(name = "forename")
    private String forename;

    @NotNull
    @Size(min = 3)
    @Column(name = "surname")
    private String surname;

    @Column(name = "university")
    private String university;

    @Column(name = "faculty")
    private String faculty;

    @Column(name = "study_year")
    private Integer studyYear;

    @NotNull
    @Enumerated(value = EnumType.STRING)
    @Column(name = "discipline")
    private Discipline discipline;

    @NotNull
    @Column(name = "email")
    private String email;

    @NotNull
    @Column(name = "phone")
    private String phone;

    @Column(name = "internal_candidate")
    //@ColumnDefault("false")
    private Boolean internalCandidate;

    @Column(name = "alumni_candidate")
    //@ColumnDefault("false")
    private Boolean alumniCandidate;

    @NotNull
    @Size(min = 6, max = 30)
    @Column(name = "password")
    private String password;

    public Candidate() {
    }

    public Candidate(int id, @NotNull @Size(min = 3) String forename, @NotNull @Size(min = 3) String surname, String university, @NotNull String email, @NotNull @Size(min = 6, max = 30) String password) {
        this.id = id;
        this.forename = forename;
        this.surname = surname;
        this.university = university;
        this.email = email;
        this.password = password;
    }

    public Candidate(int id, @NotNull @Size(min = 3) String forename, @NotNull @Size(min = 3) String surname, String university, String faculty, Integer studyYear, @NotNull String email, @NotNull String phone, Boolean internalCandidate, Boolean alumniCandidate, @NotNull @Size(min = 6, max = 30) String password) {
        this.id = id;
        this.forename = forename;
        this.surname = surname;
        this.university = university;
        this.faculty = faculty;
        this.studyYear = studyYear;
        this.email = email;
        this.phone = phone;
        this.internalCandidate = internalCandidate;
        this.alumniCandidate = alumniCandidate;
        this.password = password;
    }

    public String getFaculty() {
        return faculty;
    }

    public void setFaculty(String faculty) {
        this.faculty = faculty;
    }

    public Integer getStudyYear() {
        return studyYear;
    }

    public void setStudyYear(Integer studyYear) {
        this.studyYear = studyYear;
    }

    public Discipline getDiscipline() {
        return discipline;
    }

    public void setDiscipline(Discipline discipline) {
        this.discipline = discipline;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Boolean getInternalCandidate() {
        return internalCandidate;
    }

    public void setInternalCandidate(Boolean internalCandidate) {
        this.internalCandidate = internalCandidate;
    }

    public Boolean getAlumniCandidate() {
        return alumniCandidate;
    }

    public void setAlumniCandidate(Boolean alumniCandidate) {
        this.alumniCandidate = alumniCandidate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getForename() {
        return forename;
    }

    public void setForename(String forename) {
        this.forename = forename;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getUniversity() {
        return university;
    }

    public void setUniversity(String university) {
        this.university = university;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
