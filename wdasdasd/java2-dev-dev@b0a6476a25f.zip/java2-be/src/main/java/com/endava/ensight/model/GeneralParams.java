package com.endava.ensight.model;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;


public class GeneralParams {
    @NotNull
    @Min(value = 1)
    @Max(10000)
    private Integer numberOfQuestions;

    @NotNull
    private Discipline discipline;

    @NotNull
    @Min(0)
    @Max(100)
    private Integer easyPercent;

    @NotNull
    @Min(0)
    @Max(100)
    private Integer mediumPercent;

    @NotNull
    @Min(0)
    @Max(100)
    private Integer hardPercent;

    @NotNull
    @Min(value = 1)
    @Max(10000)
    private Integer numberOfTests;


    public Integer getNumberOfQuestions() {
        return numberOfQuestions;
    }

    public void setNumberOfQuestions(Integer numberOfQuestions) {
        this.numberOfQuestions = numberOfQuestions;
    }

    public Discipline getDiscipline() {
        return discipline;
    }

    public void setDiscipline(Discipline discipline) {
        this.discipline = discipline;
    }

    public Integer getEasyPercent() {
        return easyPercent;
    }

    public void setEasyPercent(Integer easyPercent) {
        this.easyPercent = easyPercent;
    }

    public Integer getMediumPercent() {
        return mediumPercent;
    }

    public void setMediumPercent(Integer mediumPercent) {
        this.mediumPercent = mediumPercent;
    }

    public Integer getHardPercent() {
        return hardPercent;
    }

    public void setHardPercent(Integer hardPercent) {
        this.hardPercent = hardPercent;
    }

    public Integer getNumberOfTests() {
        return numberOfTests;
    }

    public void setNumberOfTests(Integer numberOfTests) {
        this.numberOfTests = numberOfTests;
    }
}
