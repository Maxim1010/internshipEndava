package com.endava.ensight.dto;

public class CandidateTestId {

    private String candidateId;

    private String testId;

    public CandidateTestId() {
    }

    public CandidateTestId(String candidateId, String testId) {
        this.candidateId = candidateId;
        this.testId = testId;
    }

    public String getCandidateId() {
        return candidateId;
    }

    public void setCandidateId(String candidateId) {
        this.candidateId = candidateId;
    }

    public String getTestId() {
        return testId;
    }

    public void setTestId(String testId) {
        this.testId = testId;
    }
}
