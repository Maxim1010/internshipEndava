package com.endava.ensight.validators;

import com.endava.ensight.model.Campaign;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

@Component
public class CampaignValidator implements Validator {

    @Override
    public boolean supports(Class<?> classz)
    {
        return Campaign.class.equals(classz);
    }

    @Override
    public void validate(Object o, Errors errors) {
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "name.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "accountedPerson", "accountedPerson.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "netCandidates", "netCandidates.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "javaCandidates", "javaCandidates.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "amCandidates", "amCandidates.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "testingCandidates", "testingCandidates.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "startCampaign", "startCampaign.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "startPromoting", "startPromoting.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "startInternship", "startCampaign.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "startTests", "startTests.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "endInternship", "endInternship.required");

        Campaign campaign = (Campaign) o;


        if (campaign.getAccountedPerson().startsWith(".*\\d+.*")) {
            errors.rejectValue("name", "name.invalid", new Object[]{}, "");
        }
        if (campaign.getAccountedPerson().contains(".*\\d+.*")) {
            errors.rejectValue("accountedPerson", "accountedPerson.invalid", new Object[]{}, "");
        }
        if(!datesAreValid(campaign)) {
            errors.rejectValue("startCampaign", "startCampaign.invalid", new Object[]{}, "");
            errors.rejectValue("startPromoting", "startPromoting.invalid", new Object[]{}, "");
            errors.rejectValue("startTests", "startTests.invalid", new Object[]{}, "");
            errors.rejectValue("startInternship", "startInternship.invalid", new Object[]{}, "");
            errors.rejectValue("endInternship", "endInternship.invalid", new Object[]{}, "");
        }
    }

    private boolean datesAreValid(Campaign campaign) {
        return campaign.getStartCampaign().isBefore(campaign.getStartPromoting()) &&
                campaign.getStartPromoting().isBefore(campaign.getStartTests()) &&
                campaign.getStartTests().isBefore(campaign.getStartInternship()) &&
                campaign.getStartInternship().isBefore(campaign.getEndInternship());
    }
}
