package com.endava.ensight.utils;


import java.util.List;

public class Pagination {

    public <T> List<T> getSubList(int numberOfObjectsPerPage, int pageNumber, List<T> objectList) {
        int noOfObjects = objectList.size();

        if (numberOfObjectsPerPage < 0) {
            numberOfObjectsPerPage = 15;
        }

        if (pageNumber <= 0) {
            pageNumber = 1;
        }

        int fromIndex = (pageNumber - 1) * numberOfObjectsPerPage;
        int toIndex = fromIndex + numberOfObjectsPerPage;

        if (fromIndex >= noOfObjects) {
            fromIndex = noOfObjects - ((noOfObjects % numberOfObjectsPerPage) != 0 ?
                    noOfObjects % numberOfObjectsPerPage : numberOfObjectsPerPage);
            if (fromIndex < 0)
                fromIndex = 0;
            toIndex = noOfObjects;
        }

        if (toIndex > noOfObjects) {
            toIndex = noOfObjects;
        }
        return objectList.subList(fromIndex, toIndex);
    }


}
