package com.endava.ensight.service;

import com.endava.ensight.model.Answer;
import com.endava.ensight.repository.AnswerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AnswerService {
    @Autowired
    private AnswerRepository answerRepository;

    public List<Answer> getAnswersByQuestionId(Integer questionId) {
        return answerRepository.getAllAnswersByQuestionId(questionId);

    }

    public Answer getAnswerById(int answerId) {
        return answerRepository.getById(answerId);
    }

    public int createAnswer(Answer answer) {
        return answerRepository.create(answer);
    }

    public Integer createAnswerMultiple(List<Answer> answers) {
        return answerRepository.createMultipleAnswer(answers);
    }

    public int editAnswerMultiple(List<Answer> answers) {
        return answerRepository.updateMultiple(answers);
    }

    public int editAnswer(Answer answer) {
        return answerRepository.update(answer.getAnswerId(), answer);
    }

    public int deleteAllAnswersForAQuestionWithTheException(int answerId) {
        return answerRepository.deleteAllAnswersForAQuestionWithTheException(answerId);
    }
}

