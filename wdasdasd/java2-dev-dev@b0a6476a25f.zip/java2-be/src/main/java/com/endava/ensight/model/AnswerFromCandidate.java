package com.endava.ensight.model;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity(name = "AnswerFromCandidate")
@Table(name = "answers_from_candidates")
public class AnswerFromCandidate {
    @EmbeddedId
    private CandidateTestQuestionCompositeKey id;

    @Column(name = "answer_text")
    private String answerText;

    @Column(name = "is_correct")
    private Boolean isCorrect;

    public AnswerFromCandidate() {
    }

    public AnswerFromCandidate(CandidateTestQuestionCompositeKey id, String answerText) {
        this.id = id;
        this.answerText = answerText;
    }

    public AnswerFromCandidate(CandidateTestQuestionCompositeKey id, String answerText, Boolean isCorrect) {
        this.id = id;
        this.answerText = answerText;
        this.isCorrect = isCorrect;
    }

    public boolean isCorrect() {
        return isCorrect;
    }

    public void setCorrect(boolean correct) {
        isCorrect = correct;
    }

    public CandidateTestQuestionCompositeKey getId() {
        return id;
    }

    public void setId(CandidateTestQuestionCompositeKey id) {
        this.id = id;
    }

    public String getAnswerText() {
        return answerText;
    }

    public void setAnswerText(String answerText) {
        this.answerText = answerText;
    }
}
