package com.endava.ensight.repository;

import com.endava.ensight.Application;
import com.endava.ensight.model.Campaign;
import com.endava.ensight.model.QCampaign;
import com.querydsl.jpa.impl.JPAQueryFactory;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import java.nio.channels.CancelledKeyException;
import java.util.List;

@Component
public class CampaignRepository implements CrudRepositoryQueryDSL<Campaign, Integer> {


    @PersistenceUnit
    private EntityManagerFactory entityManagerFactory;

    public CampaignRepository() {
        this.entityManagerFactory = Application.getEntityManagerFactory();
    }

    @Override
    public int create(Campaign campaign) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction entityTransaction = entityManager.getTransaction();
        try {
            entityTransaction.begin();

            entityManager.persist(campaign);
            entityTransaction.commit();
        } catch (Exception e) {
            if (entityTransaction != null)
                entityTransaction.rollback();
        } finally {
            entityManager.close();
        }
        return campaign.getId();
    }

    @Override
    public List<Campaign> readAll() {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        QCampaign qCampaign = QCampaign.campaign;
        JPAQueryFactory queryFactory = new JPAQueryFactory(entityManager);
        List<Campaign> result = queryFactory.selectFrom(qCampaign).fetch();
        entityManager.close();
        return  result;
    }

    @Override
    public void update(Integer id, Campaign campaign) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        QCampaign qCampaign = QCampaign.campaign;
        JPAQueryFactory queryFactory = new JPAQueryFactory(entityManager);
        EntityTransaction entityTransaction = entityManager.getTransaction();

        try {
            entityTransaction.begin();

            queryFactory.update(qCampaign)
                    .where(qCampaign.id.eq(id))
                    .set(qCampaign, campaign)
                    .execute();

            entityTransaction.commit();
        } catch (Exception e) {
            if (entityTransaction != null)
                entityTransaction.rollback();
        } finally {
            entityManager.close();
        }

    }

    @Override
    public void delete(Integer id) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        QCampaign qCampaign = QCampaign.campaign;
        JPAQueryFactory queryFactory = new JPAQueryFactory(entityManager);
        EntityTransaction entityTransaction = entityManager.getTransaction();

        try {
            entityTransaction.begin();

            queryFactory.delete(qCampaign)
                    .where(qCampaign.id.eq(id))
                    .execute();

            entityManager.persist(qCampaign);
            entityManager.flush();

            entityTransaction.commit();
        } catch (Exception e) {
            if (entityTransaction != null)
                entityTransaction.rollback();
        } finally {
            entityManager.close();
        }


    }

    @Override
    public Campaign getById(Integer id) throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        QCampaign qCampaign = QCampaign.campaign;
        JPAQueryFactory queryFactory = new JPAQueryFactory(entityManager);
        try {
            return queryFactory.selectFrom(qCampaign)
                    .where(qCampaign.id.eq(id))
                    .fetchOne();
        } catch (Exception e) {
            throw new Exception("Not found");
        }
        finally {
            entityManager.close();
        }
    }

    public Integer getLastId()throws  Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        QCampaign qCampaign = QCampaign.campaign;
        JPAQueryFactory queryFactory = new JPAQueryFactory(entityManager);
        try {
            return queryFactory.selectFrom(qCampaign)
                    .orderBy(qCampaign.id.desc())
                    .fetchFirst().getId();
        } catch (Exception e) {
            throw new Exception("Not found");
        }
        finally {
            entityManager.close();
        }
    }
}

