package com.endava.ensight.controller;

import com.endava.ensight.model.GeneralParams;
import com.endava.ensight.model.Question;
import com.endava.ensight.model.Test;
import com.endava.ensight.service.TestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@CrossOrigin(origins = "*")
@RestController
public class TestController {
    @Autowired
    private TestService testService;

    @PostMapping(value = "/test/create", consumes = APPLICATION_JSON_VALUE)
    public ResponseEntity<Number> createTest(@RequestBody Test test) {
        return new ResponseEntity<>(testService.createTest(test), HttpStatus.OK);
    }

    @GetMapping(value = "/tests/all", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Test>> getAllTests() {
        return new ResponseEntity<>(testService.getAllTests(), HttpStatus.OK);
    }

    @GetMapping(value = "/tests/{testId}")
    public ResponseEntity<Test> getTestById(@PathVariable Integer testId) {
        return new ResponseEntity<>(testService.getTestById(testId), HttpStatus.OK);
    }

    @GetMapping(value = "/tests", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Test> getTestsSublist(@RequestParam(value = "page", defaultValue = "1") int page, @RequestParam(value = "size", defaultValue = "15") int size) {
        return testService.getTestsSublist(size, page);
    }

    @DeleteMapping(value = "/test/delete/{testId}")
    public ResponseEntity<Integer> deleteTestById(@PathVariable Integer testId) {
        return new ResponseEntity<>(testService.deleteTestById(testId), HttpStatus.OK);
    }

    @PostMapping(value = "/test/delete/multiple")
    public ResponseEntity<Integer> deleteTests(@RequestBody List<Integer> testIds) {
        return new ResponseEntity<>(testService.deleteTests(testIds), HttpStatus.OK);
    }

    @GetMapping(value = "/tests/filter/sort", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Test> getQuestionsSublistByFiltersAndSorting(@RequestParam(value = "page", defaultValue = "1") int page,
                                                             @RequestParam(value = "size", defaultValue = "15") int size,
                                                             @RequestParam(value = "discipline", defaultValue = "1,2,3,4") int discipline[],
                                                             @RequestParam(value = "sortField", defaultValue = "1") int sortField,
                                                             @RequestParam(value = "order", defaultValue = "asc") String order) {
        return testService.getFilteredAndSortedQuestionsSubList(size, page, discipline, sortField, order);
    }

    @PostMapping(value = "/tests/generate", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Integer> generateTests(@RequestBody @Valid GeneralParams generalParams) {
        return new ResponseEntity<>(testService.generateTests(generalParams), HttpStatus.OK);
    }

    @GetMapping(value = "/tests/{testId}/questions")
    public ResponseEntity<List<Question>> getQuestionsByTestId(@PathVariable Integer testId) {
        return new ResponseEntity<>(testService.getQuestionsByTestId(testId), HttpStatus.OK);
    }

    @PutMapping(value = "/tests/update")
    public ResponseEntity<Number> updateTest(@RequestBody @Valid Test test) {
        return new ResponseEntity<>(testService.updateTest(test), HttpStatus.OK);
    }

    @GetMapping(value = "/count/tests")
    public Long countTests(@RequestParam(value = "discipline", defaultValue = "1,2") int discipline[]) {
        return this.testService.countTests(discipline);
    }

}
