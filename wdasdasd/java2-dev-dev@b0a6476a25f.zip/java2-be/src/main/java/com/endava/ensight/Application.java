package com.endava.ensight;

import com.endava.ensight.config.Config;
import com.endava.ensight.controller.QuestionController;
import com.endava.ensight.model.Answer;
import com.endava.ensight.model.MailSenderRobot;
import com.endava.ensight.model.Question;
import com.endava.ensight.repository.EmailRepository;
import com.endava.ensight.repository.QuestionRepository;
import com.endava.ensight.service.EmailService;
import com.endava.ensight.service.QuestionService;
import com.endava.ensight.validators.CampaignValidator;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.mail.javamail.JavaMailSender;

import javax.persistence.EntityManagerFactory;


@SpringBootApplication
@ComponentScan(basePackageClasses = {
        QuestionController.class,
        Question.class,
        Answer.class,
        QuestionRepository.class,
        QuestionService.class,
        Config.class,
        CampaignValidator.class,
        MailSenderRobot.class,
        EmailService.class,
        JavaMailSender.class,
        EmailRepository.class
})
@EnableAspectJAutoProxy(proxyTargetClass = true)

public class Application extends SpringBootServletInitializer {

    public static Config config = new Config();

    private static EntityManagerFactory ENTITY_MANAGER_FACTORY = config.entityManagerFactory().getObject();


    public static EntityManagerFactory getEntityManagerFactory() {
        return ENTITY_MANAGER_FACTORY;
    }

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);

    }

}
