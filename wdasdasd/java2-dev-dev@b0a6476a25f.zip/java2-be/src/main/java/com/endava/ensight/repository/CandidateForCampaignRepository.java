package com.endava.ensight.repository;

import com.endava.ensight.Application;
import com.endava.ensight.model.CandidateForCampaign;
import com.endava.ensight.model.QCandidateForCampaign;
import com.querydsl.jpa.impl.JPAQueryFactory;
import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.util.Collections;
import java.util.List;

@Component
public class CandidateForCampaignRepository implements CrudRepositoryQueryDSL<CandidateForCampaign, Integer> {
    @PersistenceUnit
    private EntityManagerFactory entityManagerFactory;

    public CandidateForCampaignRepository() {
        entityManagerFactory = Application.getEntityManagerFactory();
    }


    @Override
    public int create(CandidateForCampaign candidateForCampaign) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction entityTransaction = entityManager.getTransaction();
        try {
            entityTransaction.begin();

            entityManager.persist(candidateForCampaign);
            entityTransaction.commit();
        } catch (Exception e) {
            if (entityTransaction != null)
                entityTransaction.rollback();
        } finally {
            entityManager.close();
        }
        return candidateForCampaign.getId();
    }

    @Override
    public List<CandidateForCampaign> readAll() {
        return null;
    }

    @Override
    public void update(Integer id, CandidateForCampaign candidateForCampaign) {

    }

    @Override
    public void delete(Integer id) {

    }

    @Override
    public CandidateForCampaign getById(Integer id) throws Exception {
        return null;
    }

    public List<Integer> getCandidatesIdsByCampaignId(Integer campaignId) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        QCandidateForCampaign qCandidateForCampaign = QCandidateForCampaign.candidateForCampaign;
        JPAQueryFactory queryFactory = new JPAQueryFactory(entityManager);
        EntityTransaction entityTransaction = entityManager.getTransaction();
        List<Integer> candidateIds = Collections.emptyList();
        try {
            entityTransaction.begin();
            Query query = entityManager.createQuery("select cfc.candidateId from CandidateForCampaign cfc where cfc.campaignId=" + campaignId);
            candidateIds = query.getResultList();
            entityTransaction.commit();
        } catch (Exception ex) {
            if (entityTransaction != null)
                entityTransaction.rollback();
        } finally {
            entityManager.close();
        }
        return candidateIds;
    }
}
