package com.endava.ensight.controller;

import com.endava.ensight.model.GeneralSettings;
import com.endava.ensight.service.GeneralSettingsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@CrossOrigin(value = "*")
@RestController
public class GeneralSettingsController {
    @Autowired
    private GeneralSettingsService generalSettingsService;

    @PostMapping(value = "/general-settings/create", consumes = APPLICATION_JSON_VALUE)
    public ResponseEntity<Number> createGeneralSettings(@RequestBody GeneralSettings generalSettings) {
        return new ResponseEntity<>(generalSettingsService.createGeneralSettings(generalSettings), HttpStatus.OK);
    }

    @PutMapping(value = "/general-settings/update", consumes = APPLICATION_JSON_VALUE)
    public ResponseEntity<Number> updateGeneralSettings(@RequestBody GeneralSettings generalSettings) {
        return new ResponseEntity<>(generalSettingsService.updateGeneralSettings(generalSettings), HttpStatus.OK);
    }

    @GetMapping(value = "/general-settings", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GeneralSettings> getGeneralSettings() {
        return new ResponseEntity<>(generalSettingsService.getGeneralSettings(), HttpStatus.OK);
    }
}
