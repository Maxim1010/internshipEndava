package com.endava.ensight.repository;

import com.endava.ensight.Application;
import com.endava.ensight.model.Candidate;
import com.endava.ensight.model.Mail;
import com.endava.ensight.model.Status;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

@Component
public class EmailRepository {

    @PersistenceUnit
    private EntityManagerFactory entityManagerFactory;

    public EmailRepository() {
        this.entityManagerFactory = Application.getEntityManagerFactory();
    }

    public boolean setStatusToSent(Candidate candidate) {
        EntityManager em = entityManagerFactory.createEntityManager();
        Candidate candidate1;
        int status = 0;
        try {

            em.getTransaction().begin();
            candidate1 = em.find(Candidate.class, candidate.getId());
            System.out.println(candidate1);

            int queryResult = em.createQuery("update Exam e set e.status =:status where e.id.candidateId =:candidateId")
                    .setParameter("status", Status.SENT)
                    .setParameter("candidateId", candidate1.getId())
                    .executeUpdate();

            System.out.println(queryResult);
            em.getTransaction().commit();
            em.close();
            return true;

        } catch (Exception e) {
            System.out.println(e);
            return false;

        } finally {
            if (em.getTransaction() != null) {
                em.getTransaction().rollback();
                em.close();

            }

        }

    }

}
