package com.endava.ensight.service;

import com.endava.ensight.model.Discipline;
import com.endava.ensight.model.Question;
import com.endava.ensight.repository.QuestionRepository;
import com.endava.ensight.utils.Pagination;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class QuestionService {
    @Autowired
    private QuestionRepository questionRepository;
    @Autowired
    private AnswerService answerService;

    public int createQuestion(Question question) {
        return questionRepository.create(question);
    }

    public List<Question> getAllQuestions() {
        return questionRepository.readAll();
    }

    /**
     * @param numberOfQuestionsPerPage
     * @param pageNumber
     * @return
     */
    public List<Question> getQuestionsSubList(int numberOfQuestionsPerPage, int pageNumber) {

        List<Question> questions = questionRepository.readAll();
        Pagination pagination = new Pagination();
        questions = pagination.getSubList(numberOfQuestionsPerPage, pageNumber, questions);
        return questions;
    }

    /**
     * @param numberOfQuestionsPerPage
     * @param pageNumber
     * @param questions
     * @return
     */
    public List<Question> getQuestionsSubList(int numberOfQuestionsPerPage, int pageNumber, List<Question> questions) {
        int noOfQuestions = questions.size();
        if (numberOfQuestionsPerPage < 0) {
            numberOfQuestionsPerPage = 15;
        }

        if (pageNumber <= 0) {
            pageNumber = 1;
        }

        int fromIndex = (pageNumber - 1) * numberOfQuestionsPerPage;
        int toIndex = fromIndex + numberOfQuestionsPerPage;

        if (fromIndex >= noOfQuestions) {
            fromIndex = noOfQuestions - ((noOfQuestions % numberOfQuestionsPerPage) != 0 ?
                    noOfQuestions % numberOfQuestionsPerPage : numberOfQuestionsPerPage);
            if (fromIndex < 0)
                fromIndex = 0;
            toIndex = noOfQuestions;
        }

        if (toIndex > noOfQuestions) {
            toIndex = noOfQuestions;
        }
        return questions.subList(fromIndex, toIndex);
    }

    public Question getQuestionById(int id) {
        return questionRepository.getById(id);
    }

    public List<Question> sortQuestionsByTitle(List<Question> questionsToSort, String order) {
        if (order.equals("asc")) {
            return questionsToSort
                    .stream()
                    .sorted(Comparator.comparing(Question::getTitle))
                    .collect(Collectors.toList());
        } else if (order.equals("desc")) {
            return questionsToSort
                    .stream()
                    .sorted(Comparator.comparing(Question::getTitle).reversed())
                    .collect(Collectors.toList());
        } else return new ArrayList<>();
    }

    public List<Question> sortQuestionsByCreatedAt(List<Question> questionsToSort, String order) {
        if (order.equals("asc")) {
            return questionsToSort
                    .stream()
                    .sorted(Comparator.comparing(Question::getCreatedAt))
                    .collect(Collectors.toList());
        } else if (order.equals("desc")) {
            return questionsToSort
                    .stream()
                    .sorted(Comparator.comparing(Question::getCreatedAt).reversed())
                    .collect(Collectors.toList());
        } else return new ArrayList<>();
    }

    public List<Question> sortQuestionByUpdatedAt(List<Question> questionToSort, String order) {
        if (order.equals("asc")) {
            return questionToSort
                    .stream()
                    .sorted(Comparator.comparing(Question::getUpdatedAt))
                    .collect(Collectors.toList());
        } else if (order.equals("desc")) {
            return questionToSort
                    .stream()
                    .sorted(Comparator.comparing(Question::getUpdatedAt).reversed())
                    .collect(Collectors.toList());
        } else return new ArrayList<>();
    }

    public List<Question> getFilteredQuestionsSubList(int size, int page, int difficulty[], int type[], int discipline[]) {
        List<Question> questions;
        questions = questionRepository.getFilteredQuestionsSubList(size, page, difficulty, type, discipline);
        questions = getQuestionsSubList(size, page, questions);
        return questions;
    }

    public List<Question> filterQuestionsByDiscipline(int discipline[], List<Question> questions) {

        int noFilters = discipline.length;
        if (noFilters >= Discipline.values().length)
            noFilters = 4;
        if (noFilters == 1) {
            questions = questions.stream()
                    .filter(q -> q.getDiscipline() == Discipline.values()[discipline[0] - 1])
                    .collect(Collectors.toList());
        } else if (noFilters == 2) {
            questions = questions.stream()
                    .filter(q -> q.getDiscipline() == Discipline.values()[discipline[0] - 1]
                            || q.getDiscipline() == Discipline.values()[discipline[1] - 1])
                    .collect(Collectors.toList());
        } else if (noFilters == 3) {
            questions = questions.stream()
                    .filter(q -> q.getDiscipline() == Discipline.values()[discipline[0] - 1]
                            || q.getDiscipline() == Discipline.values()[discipline[1] - 1]
                            || q.getDiscipline() == Discipline.values()[discipline[2] - 1])
                    .collect(Collectors.toList());
        }
        return questions;
    }

    public List<Question> filterQuestionsByType(int type[], List<Question> questions) {
        int noFilters = type.length;

        if (noFilters == 1) {
            questions = questions.stream().filter(q -> q.getType() == type[0]).collect(Collectors.toList());
        } else if (noFilters == 2) {
            questions = questions.stream().filter(q -> q.getType() == type[0] || q.getType() == type[1]).collect(Collectors.toList());
        }
        return questions;
    }

    public List<Question> filterQuestionsByDifficulty(int difficulty[], List<Question> questions) {

        int noFilters = difficulty.length;

        if (noFilters == 1) {
            questions = questions
                    .stream()
                    .filter(q -> q.getDifficulty() == difficulty[0])
                    .collect(Collectors.toList());
        } else if (noFilters == 2) {
            questions = questions.stream()
                    .filter(q -> q.getDifficulty() == difficulty[0] || q.getDifficulty() == difficulty[1])
                    .collect(Collectors.toList());
        }

        return questions;
    }

    public int getNumberOfFilteredAndSortedQuestions(int[] difficulty, int[] type, int[] discipline, int sortField, String order) {
        return this.questionRepository.getNumberOfFilteredAndSortedQuestions(difficulty, type, discipline, sortField, order);
    }

    public List<Question> getFilteredAndSortedQuestionsSubList(int size, int page, int[] difficulty,
                                                               int[] type, int[] discipline, int sortField, String order) {
        return this.questionRepository.getFilteredAndSortedQuestionsSubList(size, page, difficulty, type, discipline, sortField, order);
    }

    public int deleteQuestionById(int questionId) {
        return questionRepository.delete(questionId);
    }

    public int deleteQuestions(List<Integer> questionIds) {
        // return questionRepository.delete(questionIds);
        for (Integer id : questionIds) {
            //answerService.deleteAllAnswersForAQuestionWithTheException(id);
            this.questionRepository.delete(id);
        }
        return 0;
    }

    public Integer editQuestion(Question question) {
        return questionRepository.update(question.getId(), question);
    }

    public List<Question> getFilteredQuestions(Discipline discipline) {
        return questionRepository.getByDisciplineFilter(discipline);
    }

    public List<Question> getByListOfIds(List<Integer> questionIds) {
        return questionRepository.getByListOfIds(questionIds);
    }
}