package com.endava.ensight.repository;

import com.endava.ensight.Application;
import com.endava.ensight.model.CandidateTestCompositeKey;
import com.endava.ensight.model.Exam;
import com.endava.ensight.model.QExam;
import com.querydsl.jpa.impl.JPAQueryFactory;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import java.util.List;

@Component
public class ExamRepository implements CrudRepositoryQueryDSL<Exam, CandidateTestCompositeKey> {

    @PersistenceUnit
    private EntityManagerFactory entityManagerFactory;

    public ExamRepository() {
        this.entityManagerFactory = Application.getEntityManagerFactory();
    }

    @Override
    public int create(Exam exam) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction entityTransaction = entityManager.getTransaction();
        try {
            entityTransaction.begin();

            entityManager.persist(exam);
            entityTransaction.commit();
        } catch (Exception e) {
            if (entityTransaction != null)
                entityTransaction.rollback();
        } finally {
            entityManager.close();
        }
        return exam.getId().getCompositeId();
    }

    @Override
    public List<Exam> readAll() {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        QExam qExam = QExam.exam;
        JPAQueryFactory queryFactory = new JPAQueryFactory(entityManager);
        List<Exam> result = queryFactory.selectFrom(qExam).fetch();
        entityManager.close();
        return result;
    }

    @Override
    public void update(CandidateTestCompositeKey id, Exam exam) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        QExam qExam = QExam.exam;
        JPAQueryFactory queryFactory = new JPAQueryFactory(entityManager);
        EntityTransaction entityTransaction = entityManager.getTransaction();

        try {
            entityTransaction.begin();

            queryFactory.update(qExam)
                    .where(qExam.id.candidateId.eq(id.getCandidateId()))
                    .where(qExam.id.testId.eq(id.getTestId()))
                    .set(qExam.startTime,exam.getStartTime())
                    .set(qExam.status, exam.getStatus())
                    .set(qExam.endTime, exam.getEndTime())
                    .set(qExam.grade, exam.getGrade())
                    .execute();

            entityTransaction.commit();
        } catch (Exception e) {
            if (entityTransaction != null)
                entityTransaction.rollback();
        } finally {
            entityManager.close();
        }

    }

    @Override
    public void delete(CandidateTestCompositeKey id) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        QExam qExam = QExam.exam;
        JPAQueryFactory queryFactory = new JPAQueryFactory(entityManager);
        EntityTransaction entityTransaction = entityManager.getTransaction();

        try {
            entityTransaction.begin();

            queryFactory.delete(qExam)
                    .where(qExam.id.candidateId.eq(id.getCandidateId()))
                    .where(qExam.id.testId.eq(id.getTestId()))
                    .execute();
            entityManager.persist(qExam);
            entityManager.flush();

            entityTransaction.commit();
        } catch (Exception e) {
            if (entityTransaction != null)
                entityTransaction.rollback();
        } finally {
            entityManager.close();
        }


    }

    @Override
    public Exam getById(CandidateTestCompositeKey id) throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        QExam qExam = QExam.exam;
        JPAQueryFactory queryFactory = new JPAQueryFactory(entityManager);
        try {
            return queryFactory.selectFrom(qExam)
                    .where(qExam.id.candidateId.eq(id.getCandidateId()))
                    .where(qExam.id.testId.eq(id.getTestId()))
                    .fetchOne();
        } catch (Exception e) {
            throw new Exception("Not found");
        }
        finally {
            entityManager.close();
        }
    }

    public Exam getByCandidateIdOnly(int id)throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        QExam qExam = QExam.exam;
        JPAQueryFactory queryFactory = new JPAQueryFactory(entityManager);
        try {
            return queryFactory.selectFrom(qExam)
                    .where(qExam.id.candidateId.eq(id))
                    .fetchFirst();
        } catch (Exception e) {
            throw new Exception("Not found");
        }
        finally {
            entityManager.close();
        }
    }
}
