package com.endava.ensight.repository;

import com.endava.ensight.Application;
import com.endava.ensight.model.Discipline;
import com.endava.ensight.model.QCandidate;
import com.endava.ensight.model.QTest;
import com.endava.ensight.model.Test;
import com.querydsl.jpa.impl.JPAQueryFactory;
import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.List;

@Component
public class TestRepository implements CrudRepository<Test> {
    @PersistenceUnit
    private EntityManagerFactory entityManagerFactory;

    public TestRepository() {
        entityManagerFactory = Application.getEntityManagerFactory();
    }

    @Override
    public int create(Test test) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction entityTransaction = entityManager.getTransaction();
        try {
            entityTransaction.begin();
            entityManager.persist(test);
            entityTransaction.commit();
        } catch (Exception e) {
            if (entityTransaction != null)
                entityTransaction.rollback();
        } finally {
            entityManager.close();
        }
        return test.getId();
    }

    @Override
    public List<Test> readAll() {
        EntityManager em = entityManagerFactory.createEntityManager();
        TypedQuery<Test> query = em.createQuery("select t from Test t", Test.class);
        List<Test> testList = query.getResultList();
        em.close();
        return testList;
    }

    @Override
    public int update(Integer id, Test editedTest) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction entityTransaction = entityManager.getTransaction();
        int status = -1;
        try {
            entityTransaction.begin();
            Test test = entityManager.find(Test.class, id);

            test.setDiscipline(editedTest.getDiscipline());
            test.setName(editedTest.getName());
            test.setUpdatedAt(LocalDate.now());

            entityManager.persist(test);

            entityTransaction.commit();
            status = 0;
        } catch (Exception e) {
            if (entityTransaction != null)
                entityTransaction.rollback();
        } finally {
            entityManager.close();
        }
        return status;
    }

    @Override
    public int delete(Integer id) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction entityTransaction = entityManager.getTransaction();
        int status = -1;
        try {
            entityTransaction.begin();
            Test test = entityManager.find(Test.class, id);
            entityManager.remove(test);
            entityTransaction.commit();
            status = 0;
        } catch (Exception e) {
            if (entityTransaction != null)
                entityTransaction.rollback();
        } finally {
            entityManager.close();
        }
        return status;
    }

    @Override
    public Test getById(Integer id) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction entityTransaction = entityManager.getTransaction();
        Test test = null;
        try {
            entityTransaction.begin();

            test = entityManager.find(Test.class, id);

            entityTransaction.commit();
        } catch (Exception ex) {
            if (entityTransaction != null)
                entityTransaction.rollback();
        } finally {
            entityManager.close();
        }
        return test;
    }

    public int delete(List<Integer> testIds) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        try {

            Query query = entityManager.createQuery("delete t from Test where t.id in :testIds");
            query.setParameter("testIds", testIds);
            query.executeUpdate();
        } catch (Exception e) {
            return -1;
        }
        finally {
            entityManager.close();
        }
        return 0;
    }

    public List<Test> getFilteredAndSortedQuestionsSubList(int size, int page, int[] discipline, int sortField, String order) {
        EntityManager em = entityManagerFactory.createEntityManager();
        StringBuilder queryString = new StringBuilder();
        queryString = queryString.append("select t from Test t");
        queryString = queryString.append(getQueryStringFilter(discipline));
        queryString = queryString.append(getQueryStringSort(sortField, order));
        TypedQuery<Test> query = em.createQuery(queryString.toString(), Test.class);
        if (page <= 0) {
            page = 1;
        }
        query.setFirstResult((page - 1) * size);
        query.setMaxResults(size);
        List<Test> testList = query.getResultList();
        em.close();
        return testList;
    }

    private String getQueryStringSort(int sortField, String order) {
        StringBuilder queryString = new StringBuilder();
        if (sortField == 1) {
            queryString = queryString.append(" order by t.name " + order);
        } else {
            queryString = queryString.append(" order by t.updatedAt " + order);
        }

        return queryString.toString();
    }

    private String getQueryStringFilter(int[] discipline) {
        StringBuilder queryString = new StringBuilder();

        int noFilters;

        noFilters = discipline.length;
        if (noFilters >= Discipline.values().length) {
            noFilters = 4;
        }
        if (noFilters != 4)
            queryString = queryString.append(" where ");
        if (noFilters == 1) {
            queryString = queryString.append("t.discipline = com.endava.ensight.model.Discipline." + Discipline.values()[discipline[0] - 1]);
        } else if (noFilters == 2) {
            queryString = queryString.append("( t.discipline = com.endava.ensight.model.Discipline." + Discipline.values()[discipline[0] - 1]
                    + " or t.discipline = com.endava.ensight.model.Discipline." + Discipline.values()[discipline[1] - 1] + ")");
        } else if (noFilters == 3) {
            queryString = queryString.append("( t.discipline = com.endava.ensight.model.Discipline." + Discipline.values()[discipline[0] - 1]
                    + " or t.discipline = com.endava.ensight.model.Discipline." + Discipline.values()[discipline[1] - 1]
                    + " or t.discipline = com.endava.ensight.model.Discipline." + Discipline.values()[discipline[2] - 1] + ")");
        }

        return queryString.toString();
    }

    public Long countTests(int discipline[]) {
        EntityManager em = entityManagerFactory.createEntityManager();
        StringBuilder myQuery = new StringBuilder("select count (t) from Test t ");

        long count = 0;

        em.getTransaction().begin();

        if (discipline.length > 0 && discipline.length < 5) {
            myQuery.append(" where ");

            if (discipline.length == 1) {
                myQuery.append("t.discipline = com.endava.ensight.model.Discipline.").append(Discipline.values()[discipline[0] - 1]);
            }

            if (discipline.length == 2) {
                myQuery.append("t.discipline = com.endava.ensight.model.Discipline.").append(Discipline.values()[discipline[0] - 1]);
                myQuery.append(" or t.discipline = com.endava.ensight.model.Discipline.").append(Discipline.values()[discipline[1] - 1]);
            }
            if (discipline.length == 3) {
                myQuery.append("t.discipline = com.endava.ensight.model.Discipline.").append(Discipline.values()[discipline[0] - 1]);
                myQuery.append(" or t.discipline = com.endava.ensight.model.Discipline.").append(Discipline.values()[discipline[1] - 1]);
                myQuery.append(" or t.discipline = com.endava.ensight.model.Discipline.").append(Discipline.values()[discipline[2] - 1]);
            }
            if (discipline.length == 4) {
                myQuery.append("t.discipline = com.endava.ensight.model.Discipline.").append(Discipline.values()[discipline[0] - 1]);
                myQuery.append(" or t.discipline = com.endava.ensight.model.Discipline.").append(Discipline.values()[discipline[1] - 1]);
                myQuery.append(" or t.discipline = com.endava.ensight.model.Discipline.").append(Discipline.values()[discipline[2] - 1]);
                myQuery.append(" or t.discipline = com.endava.ensight.model.Discipline.").append(Discipline.values()[discipline[3] - 1]);
            }
        }

        try {
            Query query = em.createQuery(myQuery.toString());
            count = (long) query.getSingleResult();

        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            em.close();
        }

        return count;

    }


    public List<Test> getAllFilteredTests(Discipline discipline) throws Exception {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        QTest qTest = QTest.test;
        JPAQueryFactory queryFactory = new JPAQueryFactory(entityManager);
        try {
            return queryFactory.selectFrom(qTest)
                    .where(qTest.discipline.eq(discipline))
                    .fetch();
        } catch (Exception e) {
            throw new Exception("Not found");
        }
        finally {
            entityManager.close();
        }
    }
}
