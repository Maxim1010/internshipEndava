package com.endava.ensight.service;

import com.endava.ensight.model.Candidate;
import com.endava.ensight.model.CandidateForCampaign;
import com.endava.ensight.repository.CandidateForCampaignRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CandidateForCampaignService {
    @Autowired
    private CandidateForCampaignRepository candidateForCampaignRepository;


    public List<Integer> getCandidatesIdsByCampaignId(Integer campaignId) {
        return candidateForCampaignRepository.getCandidatesIdsByCampaignId(campaignId);
    }

    public Integer createCandidateForCampaign(CandidateForCampaign candidateForCampaign){
        return candidateForCampaignRepository.create(candidateForCampaign);
    }
}
