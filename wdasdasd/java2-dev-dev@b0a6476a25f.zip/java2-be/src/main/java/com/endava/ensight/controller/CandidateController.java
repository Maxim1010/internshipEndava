package com.endava.ensight.controller;

import com.endava.ensight.model.Candidate;
import com.endava.ensight.model.CandidateList;
import com.endava.ensight.service.CandidateService;
import javassist.tools.reflect.CannotInvokeException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.print.attribute.standard.Media;
import javax.validation.Valid;
import java.util.List;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
@CrossOrigin(value = "*")
public class CandidateController {
    @Autowired
    CandidateService candidateService;

    @PostMapping(value = "/candidate/create", consumes = APPLICATION_JSON_VALUE)
    public ResponseEntity<Integer> createCandidate(@RequestBody @Valid Candidate candidate) {
        return new ResponseEntity<>(candidateService.createCandidate(candidate), HttpStatus.OK);
    }

    @GetMapping(value= "/candidates/all", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Candidate>> getAllCandidates(){
        return new ResponseEntity<>(candidateService.getAllCandidates(),HttpStatus.OK);
    }
    @GetMapping(value = "/candidate/{candidateId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Candidate> getCandidateById(@PathVariable Integer candidateId) {
        return new ResponseEntity<>(candidateService.getCandidateById(candidateId), HttpStatus.OK);
    }

    @PutMapping(value = "/candidate")
    @ResponseBody
    public void editCandidate(@RequestBody @Valid Candidate candidate) {
        candidateService.updateCandidate(candidate);
    }
    @GetMapping(value ="/candidates", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Candidate>> getCandidatesFromCampaignWithId(@RequestParam Integer campaignId ){
        return new ResponseEntity<>(candidateService.getCandidatesFromCampaignWithId(campaignId), HttpStatus.OK);
    }

    @PostMapping(value = "candidates/import/{campaignId}", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> importCandidates(@RequestBody @Valid CandidateList candidateList, @PathVariable Integer campaignId) {
        return new ResponseEntity<>(candidateService.importCandidates(candidateList.getCandidates(), campaignId), HttpStatus.OK);
    }
}
