package com.endava.ensight.service;

import com.endava.ensight.model.QuestionForTest;
import com.endava.ensight.repository.QuestionForTestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QuestionForTestService {
    @Autowired
    private QuestionForTestRepository questionsForTestsRepository;

    public Integer create(QuestionForTest questionForTest) {
        return questionsForTestsRepository.create(questionForTest);
    }

    public List<Integer> getQuestionsIdsByTestId(Integer testId) {
        return questionsForTestsRepository.getQuestionsIdsByTestId(testId);
    }

    public Integer deleteByTestId(Integer testId) {
        return questionsForTestsRepository.deleteByTestId(testId);
    }
}
