package com.endava.ensight.model;

import javax.validation.Valid;
import java.util.List;

public class CandidateList {
    @Valid
    List<Candidate> candidates;

    public CandidateList() {

    }

    public CandidateList(@Valid List<Candidate> candidates) {
        this.candidates = candidates;
    }

    public List<Candidate> getCandidates() {
        return candidates;
    }

    public void setCandidates(List<Candidate> candidates) {
        this.candidates = candidates;
    }
}
