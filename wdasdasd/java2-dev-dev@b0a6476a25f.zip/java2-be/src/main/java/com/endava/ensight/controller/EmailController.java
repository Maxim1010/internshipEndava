package com.endava.ensight.controller;

import com.endava.ensight.model.Candidate;
import com.endava.ensight.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@CrossOrigin(value = "*")
public class EmailController {

    @Autowired
    EmailService emailService;

    @PostMapping(value = "email/send", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Integer> sendMailToCandidates(@RequestBody List<Candidate> candidateList){
        return new ResponseEntity<Integer>(emailService.sendSimpleMessage(candidateList), HttpStatus.OK);

    }
}
