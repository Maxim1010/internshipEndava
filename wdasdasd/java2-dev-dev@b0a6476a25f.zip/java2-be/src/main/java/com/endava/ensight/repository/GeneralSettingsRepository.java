package com.endava.ensight.repository;

import com.endava.ensight.Application;
import com.endava.ensight.model.GeneralSettings;
import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.List;

@Component
public class GeneralSettingsRepository implements CrudRepository<GeneralSettings> {

    @PersistenceUnit
    private EntityManagerFactory entityManagerFactory;

    public GeneralSettingsRepository() {
        entityManagerFactory = Application.getEntityManagerFactory();
    }

    @Override
    public int create(GeneralSettings generalSettings) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction entityTransaction = entityManager.getTransaction();
        try {
            entityTransaction.begin();

            entityManager.persist(generalSettings);
            entityTransaction.commit();
        } catch (Exception e) {
            if (entityTransaction != null)
                entityTransaction.rollback();
        } finally {
            entityManager.close();
        }
        return generalSettings.getId();
    }

    @Override
    public List<GeneralSettings> readAll() {
        EntityManager em = entityManagerFactory.createEntityManager();
        TypedQuery<GeneralSettings> query = em.createQuery("select t from GeneralSettings t", GeneralSettings.class);
        List<GeneralSettings> generalSettings = query.getResultList();
        em.close();
        return generalSettings;
    }

    public GeneralSettings read() {
        EntityManager em = entityManagerFactory.createEntityManager();
        TypedQuery<GeneralSettings> query = em.createQuery("select t from GeneralSettings t", GeneralSettings.class);
        GeneralSettings generalSettings = query.getSingleResult();
        em.close();
        return generalSettings;
    }

    @Override
    public int update(Integer id, GeneralSettings editedGeneralSettings) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction entityTransaction = entityManager.getTransaction();
        int status = -1;
        try {
            entityTransaction.begin();
            GeneralSettings generalSettings = entityManager.find(GeneralSettings.class, id);

            generalSettings.setDuration(editedGeneralSettings.getDuration());
            generalSettings.setInstructions(editedGeneralSettings.getInstructions());
            generalSettings.setLinkAvailability(editedGeneralSettings.getLinkAvailability());
            generalSettings.setSummary(editedGeneralSettings.getSummary());
            generalSettings.setUpdatedAt(LocalDate.now());

            entityManager.persist(generalSettings);

            entityTransaction.commit();
            status = 0;
        } catch (Exception e) {
            if (entityTransaction != null)
                entityTransaction.rollback();
        } finally {
            entityManager.close();
        }
        return status;
    }

    @Override
    public int delete(Integer id) {
        return 0;
    }

    @Override
    public GeneralSettings getById(Integer id) {
        return null;
    }
}
