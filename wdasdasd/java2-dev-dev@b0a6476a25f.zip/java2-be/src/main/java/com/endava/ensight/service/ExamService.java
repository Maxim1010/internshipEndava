package com.endava.ensight.service;

import com.endava.ensight.model.CandidateTestCompositeKey;
import com.endava.ensight.model.Exam;
import com.endava.ensight.model.Status;
import com.endava.ensight.repository.ExamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class ExamService {
    @Autowired
    private ExamRepository examRepository;

    public Integer createExam(Exam exam) {
//        Exam exam = ExamMapper.map(examDTO);
//        exam.setStartTime(LocalDateTime.now());
        return examRepository.create(exam);
    }

    public Exam getExamById(Integer candidateId, Integer testId) {
        try {
            return examRepository.getById(new CandidateTestCompositeKey(candidateId, testId));
        }
        catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }


    public void updateExam(Exam exam) {
        examRepository.update(exam.getId(), exam);
    }

    public Boolean isStarted(Integer candidateId, Integer testId) {
        Exam exam = null;
        try {
             exam = examRepository.getById(new CandidateTestCompositeKey(candidateId, testId));
            //System.out.println(exam.getStartTime() != null);
            if(exam == null || exam.getStartTime()==null){
                return false;
            }else {
                return true;
            }
        }
        catch (Exception e){

            return true;
        }

    }


    public String endExam(Integer candidateId, Integer testId) {
        Exam exam = null;
        try {
            exam = examRepository.getById(new CandidateTestCompositeKey(candidateId,testId));
        } catch (Exception e) {
            e.printStackTrace();
            return "Invalid ID";
        }
        exam.setEndTime(LocalDateTime.now());
        //tricky move.
        exam.setStatus(Status.READY_TO_GRADE);
        examRepository.update(exam.getId(),exam);
        return "{\"value\":\"Exam ID " + exam.getId().getCompositeId() + " is now over.\"}";

    }

    public String startExam(Integer candidateId, Integer testId) {
        Exam exam = null;
        try {
            exam = examRepository.getById(new CandidateTestCompositeKey(candidateId,testId));
        } catch (Exception e) {
            e.printStackTrace();
            return "Invalid ID";
        }
        exam.setStartTime(LocalDateTime.now());
        examRepository.update(exam.getId(),exam);
        return "{\"value\":\"Exam ID " + exam.getId().getCompositeId() + " is now started.\"}";
    }

    public Exam getExamByCandidateIdOnly(int id) {
        try {
            return examRepository.getByCandidateIdOnly(id);
        }
        catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
}
