package com.endava.ensight.config;

public class DatabaseConstants {

    static final String DATABASE_URL = "jdbc:postgresql:EnSight";
    static final String USERNAME = "postgres";
    static final String PASSWORD = "1234";
    static final String PERSISTENCE_UNIT = "questionUnit";
}
