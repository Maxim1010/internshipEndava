drop schema public cascade;
create schema public;

CREATE TABLE QUESTIONS(ID SERIAL PRIMARY KEY NOT NULL,
                      TITLE VARCHAR(100) NOT NULL,
                      TYPE INTEGER NOT NULL,
                      DISCIPLINE VARCHAR(30) NOT NULL,
                      DIFFICULTY INTEGER NOT NULL,
                      NO_OF_POINTS INTEGER NOT NULL,
                      CORRECT_ANSWER_TEXT VARCHAR(1500),
                      CREATED_AT DATE NOT NULL,
                      UPDATED_AT DATE NOT NULL);

CREATE TABLE ANSWERS(ANSWER_ID SERIAL UNIQUE NOT NULL,
                    QUESTION_ID INTEGER NOT NULL,
                    ANSWER_TEXT VARCHAR(1500) NOT NULL
                    );
--ALTER TABLE ANSWERS ADD FOREIGN KEY(QUESTION_ID) REFERENCES QUESTIONS(ID);

CREATE TABLE TESTS (ID SERIAL PRIMARY KEY NOT NULL,
                    NAME VARCHAR(300) NOT NULL,
                    DISCIPLINE VARCHAR(300) NOT NULL,
                    NUMBER_OF_QUESTIONS INTEGER NOT NULL,
                    CREATED_AT DATE,
                    UPDATED_AT DATE);

CREATE TABLE QUESTIONS_TEST(ID SERIAL NOT NULL PRIMARY KEY,
                            QUESTION_ID INTEGER NOT NULL REFERENCES QUESTIONS(ID),
                            TEST_ID INTEGER NOT NULL REFERENCES TESTS(ID));

CREATE TABLE GLOBAL_SETTINGS(ID SERIAL NOT NULL PRIMARY KEY,
                            DURATION INTEGER NOT NULL,
                            LINK_AVAILABILITY INTEGER NOT NULL,
                            INSTRUCTIONS VARCHAR(1500),
                            SUMMARY VARCHAR(1500),
                            CREATED_AT DATE,
                            UPDATED_AT DATE);

CREATE TABLE CANDIDATES(ID SERIAL NOT NULL PRIMARY KEY,
                        FORENAME VARCHAR(300) NOT NULL,
                        SURNAME VARCHAR(300) NOT NULL,
                        UNIVERSITY VARCHAR(300),
                        FACULTY VARCHAR(300),
                        STUDY_YEAR INTEGER,
                        DISCIPLINE VARCHAR(300) NOT NULL,
                        EMAIL VARCHAR(300) NOT NULL,
                        PHONE VARCHAR(300) NOT NULL,
                        INTERNAL_CANDIDATE BOOLEAN NOT NULL DEFAULT FALSE,
                        ALUMNI_CANDIDATE BOOLEAN NOT NULL DEFAULT FALSE,
                        PASSWORD VARCHAR(300));

CREATE TABLE ANSWERS_FROM_CANDIDATES(CANDIDATE_ID INTEGER NOT NULL,
                                    TEST_ID INTEGER NOT NULL,
                                    QUESTION_ID INTEGER NOT NULL,
                                    ANSWER_TEXT VARCHAR(300),
                                    IS_CORRECT BOOLEAN,
                                    PRIMARY KEY(CANDIDATE_ID, TEST_ID, QUESTION_ID));

CREATE TABLE EXAMS(CANDIDATE_ID INTEGER NOT NULL,
                    TEST_ID INTEGER NOT NULL,
                    GRADE FLOAT,
                    STATUS VARCHAR(100),
                    START_TIME TIMESTAMP,
                    END_TIME TIMESTAMP,
                    PRIMARY KEY(CANDIDATE_ID, TEST_ID));

CREATE TABLE CAMPAIGNS(ID SERIAL NOT NULL PRIMARY KEY,
                       NAME VARCHAR(300) NOT NULL,
                       ACCOUNTED_PERSON VARCHAR(300) NOT NULL,
                       NET_CANDIDATES INTEGER NOT NULL,
                       JAVA_CANDIDATES INTEGER NOT NULL,
                       AM_CANDIDATES INTEGER NOT NULL,
                       TESTING_CANDIDATES INTEGER NOT NULL,
                       START_CAMPAIGN DATE NOT NULL,
                       START_PROMOTING DATE NOT NULL,
                       START_TESTS DATE NOT NULL,
                       START_INTERNSHIP DATE NOT NULL,
                       END_INTERNSHIP DATE NOT NULL);

CREATE TABLE CANDIDATES_CAMPAIGN(ID SERIAL NOT NULL PRIMARY KEY,
                                 CANDIDATE_ID INTEGER NOT NULL,
                                 CAMPAIGN_ID INTEGER NOT NULL);

insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum1',1,'AM',2,3,'03-07-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum2',1,'TESTING',2,3,'03-07-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum3',1,'JAVA',1,3,'07-05-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum4',3,'NET',2,3,'07-05-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum5',2,'AM',2,3,'02-04-2018','06-03-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum6',2,'AM',2,3,'06-03-2018','06-03-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum7',2,'AM',1,3,'06-03-2018','06-03-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum8',3,'AM',2,3,'06-03-2018','06-03-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum9',2,'AM',2,3,'4-10-2018','06-03-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum10',2,'NET',2,3,'06-03-2018','06-03-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum11',2,'AM',2,3,'06-03-2018','06-03-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum12',3,'TESTING',2,3,'06-03-2018','06-03-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum13',2,'JAVA',2,3,'06-03-2018','06-03-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum14',3,'AM',2,3,'07-05-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum15',3,'NET',1,3,'07-05-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum16',2,'JAVA',2,3,'07-05-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum17',3,'AM',2,3,'07-05-2018','01-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum18',2,'AM',2,3,'01-05-2018','01-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum19',2,'AM',2,3,'01-05-2018','01-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum20',3,'AM',2,3,'01-05-2018','01-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum21',2,'JAVA',2,3,'01-05-2018','01-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum22',2,'AM',2,3,'01-05-2018','01-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum23',2,'AM',2,3,'07-05-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum24',2,'TESTING',2,3,'07-05-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum25',2,'NET',2,3,'07-05-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum26',3,'AM',2,3,'07-05-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum27',3,'AM',2,3,'07-05-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum28',2,'NET',2,3,'07-05-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum29',2,'AM',2,3,'07-05-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum30',2,'AM',2,3,'07-05-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum31',2,'AM',2,3,'07-05-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum32',2,'NET',2,3,'07-05-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum33',2,'AM',1,3,'07-05-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum34',2,'JAVA',2,3,'07-05-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum35',2,'AM',2,3,'07-05-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum36',2,'AM',2,3,'07-05-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum37',2,'JAVA',2,3,'07-05-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum38',2,'AM',1,3,'07-05-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum39',2,'TESTING',2,3,'07-05-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum40',2,'JAVA',2,3,'07-05-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum41',2,'AM',2,3,'07-05-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum42',2,'AM',2,3,'07-05-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum43',2,'JAVA',2,3,'07-05-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum44',2,'NET',2,3,'07-05-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum45',2,'AM',2,3,'07-05-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum46',2,'JAVA',2,3,'07-05-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum47',2,'AM',2,3,'07-05-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Lorem ipsum48',2,'AM',2,3,'07-05-2018','07-05-2018');

insert into answers(question_id, answer_text) values (1, 'this is the correct answer for question 1');
insert into answers(question_id, answer_text) values (1, 'this is wrong the answer for question 1');
insert into answers(question_id, answer_text) values (1, 'this is wrong the answer for question 1');
insert into answers(question_id, answer_text) values (1, 'this is wrong the answer for question 1');
insert into answers(question_id, answer_text) values (2, 'this is the correct answer for question 2');
insert into answers(question_id, answer_text) values (2, 'this is wrong the answer for question 2');
insert into answers(question_id, answer_text) values (2, 'this is wrong the answer for question 2');
insert into answers(question_id, answer_text) values (2, 'this is wrong the answer for question 2');
insert into answers(question_id, answer_text) values (3, 'this is the correct answer for question 3');
insert into answers(question_id, answer_text) values (3, 'this is wrong the answer for question 3');
insert into answers(question_id, answer_text) values (3, 'this is wrong the answer for question 3');
insert into answers(question_id, answer_text) values (3, 'this is wrong the answer for question 3');
insert into answers(question_id, answer_text) values (4, 'this is the correct answer for question 4');
insert into answers(question_id, answer_text) values (5, 'this is the correct answer for question 5');
insert into answers(question_id, answer_text) values (6, 'this is the correct answer for question 6');
insert into answers(question_id, answer_text) values (7, 'this is the correct answer for question 7');
insert into answers(question_id, answer_text) values (8, 'this is the correct answer for question 8');
insert into answers(question_id, answer_text) values (9, 'this is the correct answer for question 9');
insert into answers(question_id, answer_text) values (10, 'this is the correct answer for question 10');
insert into answers(question_id, answer_text) values (11, 'this is the correct answer for question 11');
insert into answers(question_id, answer_text) values (12, 'this is the correct answer for question 12');
insert into answers(question_id, answer_text) values (13, 'this is the correct answer for question 13');
insert into answers(question_id, answer_text) values (14, 'this is the correct answer for question 14');
insert into answers(question_id, answer_text) values (15, 'this is the correct answer for question 15');
insert into answers(question_id, answer_text) values (16, 'this is the correct answer for question 16');
insert into answers(question_id, answer_text) values (17, 'this is the correct answer for question 17');
insert into answers(question_id, answer_text) values (18, 'this is the correct answer for question 18');
insert into answers(question_id, answer_text) values (19, 'this is the correct answer for question 19');
insert into answers(question_id, answer_text) values (20, 'this is the correct answer for question 20');
insert into answers(question_id, answer_text) values (21, 'this is the correct answer for question 21');
insert into answers(question_id, answer_text) values (22, 'this is the correct answer for question 22');
insert into answers(question_id, answer_text) values (23, 'this is the correct answer for question 23');
insert into answers(question_id, answer_text) values (24, 'this is the correct answer for question 24');
insert into answers(question_id, answer_text) values (25, 'this is the correct answer for question 25');
insert into answers(question_id, answer_text) values (26, 'this is the correct answer for question 26');
insert into answers(question_id, answer_text) values (27, 'this is the correct answer for question 27');
insert into answers(question_id, answer_text) values (28, 'this is the correct answer for question 28');
insert into answers(question_id, answer_text) values (29, 'this is the correct answer for question 29');
insert into answers(question_id, answer_text) values (30, 'this is the correct answer for question 30');
insert into answers(question_id, answer_text) values (31, 'this is the correct answer for question 31');
insert into answers(question_id, answer_text) values (32, 'this is the correct answer for question 32');
insert into answers(question_id, answer_text) values (33, 'this is the correct answer for question 33');
insert into answers(question_id, answer_text) values (34, 'this is the correct answer for question 34');
insert into answers(question_id, answer_text) values (35, 'this is the correct answer for question 35');
insert into answers(question_id, answer_text) values (36, 'this is the correct answer for question 36');
insert into answers(question_id, answer_text) values (37, 'this is the correct answer for question 37');
insert into answers(question_id, answer_text) values (38, 'this is the correct answer for question 38');
insert into answers(question_id, answer_text) values (39, 'this is the correct answer for question 39');
insert into answers(question_id, answer_text) values (40, 'this is the correct answer for question 40');
insert into answers(question_id, answer_text) values (41, 'this is the correct answer for question 41');
insert into answers(question_id, answer_text) values (42, 'this is the correct answer for question 42');
insert into answers(question_id, answer_text) values (43, 'this is the correct answer for question 43');
insert into answers(question_id, answer_text) values (44, 'this is the correct answer for question 44');
insert into answers(question_id, answer_text) values (45, 'this is the correct answer for question 45');
insert into answers(question_id, answer_text) values (46, 'this is the correct answer for question 46');
insert into answers(question_id, answer_text) values (47, 'this is the correct answer for question 47');
insert into answers(question_id, answer_text) values (48, 'this is the correct answer for question 48');

update questions set correct_answer_text = 'this is the correct answer for question 1' where id = 1;
update questions set correct_answer_text = 'this is the correct answer for question 2' where id = 2;
update questions set correct_answer_text = 'this is the correct answer for question 3' where id = 3;
update questions set correct_answer_text = 'this is the correct answer for question 4' where id = 4;
update questions set correct_answer_text = 'this is the correct answer for question 5' where id = 5;
update questions set correct_answer_text = 'this is the correct answer for question 6' where id = 6;
update questions set correct_answer_text = 'this is the correct answer for question 7' where id = 7;
update questions set correct_answer_text = 'this is the correct answer for question 8' where id = 8;
update questions set correct_answer_text = 'this is the correct answer for question 9' where id = 9;
update questions set correct_answer_text = 'this is the correct answer for question 10' where id = 10;
update questions set correct_answer_text = 'this is the correct answer for question 11' where id = 11;
update questions set correct_answer_text = 'this is the correct answer for question 12' where id = 12;
update questions set correct_answer_text = 'this is the correct answer for question 13' where id = 13;
update questions set correct_answer_text = 'this is the correct answer for question 14' where id = 14;
update questions set correct_answer_text = 'this is the correct answer for question 15' where id = 15;
update questions set correct_answer_text = 'this is the correct answer for question 16' where id = 16;
update questions set correct_answer_text = 'this is the correct answer for question 17' where id = 17;
update questions set correct_answer_text = 'this is the correct answer for question 18' where id = 18;
update questions set correct_answer_text = 'this is the correct answer for question 19' where id = 19;
update questions set correct_answer_text = 'this is the correct answer for question 20' where id = 20;
update questions set correct_answer_text = 'this is the correct answer for question 21' where id = 21;
update questions set correct_answer_text = 'this is the correct answer for question 22' where id = 22;
update questions set correct_answer_text = 'this is the correct answer for question 23' where id = 23;
update questions set correct_answer_text = 'this is the correct answer for question 24' where id = 24;
update questions set correct_answer_text = 'this is the correct answer for question 25' where id = 25;
update questions set correct_answer_text = 'this is the correct answer for question 26' where id = 26;
update questions set correct_answer_text = 'this is the correct answer for question 27' where id = 27;
update questions set correct_answer_text = 'this is the correct answer for question 28' where id = 28;
update questions set correct_answer_text = 'this is the correct answer for question 29' where id = 29;
update questions set correct_answer_text = 'this is the correct answer for question 30' where id = 30;
update questions set correct_answer_text = 'this is the correct answer for question 31' where id = 31;
update questions set correct_answer_text = 'this is the correct answer for question 32' where id = 32;
update questions set correct_answer_text = 'this is the correct answer for question 33' where id = 33;
update questions set correct_answer_text = 'this is the correct answer for question 34' where id = 34;
update questions set correct_answer_text = 'this is the correct answer for question 35' where id = 35;
update questions set correct_answer_text = 'this is the correct answer for question 36' where id = 36;
update questions set correct_answer_text = 'this is the correct answer for question 37' where id = 37;
update questions set correct_answer_text = 'this is the correct answer for question 38' where id = 38;
update questions set correct_answer_text = 'this is the correct answer for question 39' where id = 39;
update questions set correct_answer_text = 'this is the correct answer for question 40' where id = 40;
update questions set correct_answer_text = 'this is the correct answer for question 41' where id = 41;
update questions set correct_answer_text = 'this is the correct answer for question 42' where id = 42;
update questions set correct_answer_text = 'this is the correct answer for question 43' where id = 43;
update questions set correct_answer_text = 'this is the correct answer for question 44' where id = 44;
update questions set correct_answer_text = 'this is the correct answer for question 45' where id = 45;
update questions set correct_answer_text = 'this is the correct answer for question 46' where id = 46;
update questions set correct_answer_text = 'this is the correct answer for question 47' where id = 47;
update questions set correct_answer_text = 'this is the correct answer for question 48' where id = 48;


--insert into tests(NAME, DISCIPLINE, NUMBER_OF_QUESTIONS, CREATED_AT, UPDATED_AT) VALUES('Test 1', 'AM', 10, '07-05-2018','07-05-2018');
--insert into tests(NAME, DISCIPLINE, NUMBER_OF_QUESTIONS, CREATED_AT, UPDATED_AT) VALUES('Test 2', 'AM', 20, '07-05-2018','07-05-2018');
--insert into tests(NAME, DISCIPLINE, NUMBER_OF_QUESTIONS, CREATED_AT, UPDATED_AT) VALUES('Test 3', 'AM', 20, '07-05-2018','07-05-2018');
--insert into tests(NAME, DISCIPLINE, NUMBER_OF_QUESTIONS, CREATED_AT, UPDATED_AT) VALUES('Test 4', 'AM', 10, '07-05-2018','07-05-2018');
--insert into tests(NAME, DISCIPLINE, NUMBER_OF_QUESTIONS, CREATED_AT, UPDATED_AT) VALUES('Test 5', 'AM', 10, '07-05-2018','07-05-2018');
--insert into tests(NAME, DISCIPLINE, NUMBER_OF_QUESTIONS, CREATED_AT, UPDATED_AT) VALUES('Test 6', 'AM', 20, '07-05-2018','07-05-2018');
--insert into tests(NAME, DISCIPLINE, NUMBER_OF_QUESTIONS, CREATED_AT, UPDATED_AT) VALUES('Test 7', 'AM', 10, '07-05-2018','07-05-2018');
--insert into tests(NAME, DISCIPLINE, NUMBER_OF_QUESTIONS, CREATED_AT, UPDATED_AT) VALUES('Test 8', 'AM', 10, '07-05-2018','07-05-2018');
--insert into tests(NAME, DISCIPLINE, NUMBER_OF_QUESTIONS, CREATED_AT, UPDATED_AT) VALUES('Test 9', 'AM', 10, '07-05-2018','07-05-2018');
--insert into tests(NAME, DISCIPLINE, NUMBER_OF_QUESTIONS, CREATED_AT, UPDATED_AT) VALUES('Test 10', 'AM', 20, '07-05-2018','07-05-2018');
--insert into tests(NAME, DISCIPLINE, NUMBER_OF_QUESTIONS, CREATED_AT, UPDATED_AT) VALUES('Test 11', 'AM', 10, '07-05-2018','07-05-2018');
--insert into tests(NAME, DISCIPLINE, NUMBER_OF_QUESTIONS, CREATED_AT, UPDATED_AT) VALUES('Test 12', 'AM', 10, '07-05-2018','07-05-2018');


insert into GLOBAL_SETTINGS(DURATION, LINK_AVAILABILITY, INSTRUCTIONS, SUMMARY, CREATED_AT, UPDATED_AT) values( 60, 24, 'These are the
instructions1', 'This is the summary1', '07-05-2018','07-05-2018');

INSERT INTO public.candidates(
	forename, surname, university, faculty, study_year, discipline, email, phone, internal_candidate, alumni_candidate, password)
	VALUES ('mitica', 'pavel1', 'universitatea', 'facultatea', '1', 'AM', 'email@mail.com', '0123456789', 'false', 'false', 'parolica');

INSERT INTO public.candidates(
	forename, surname, university, faculty, study_year, discipline, email, phone, internal_candidate, alumni_candidate, password)
	VALUES ('mitica', 'pavel2', 'universitatea', 'facultatea', '1', 'AM', 'email@mail.com', '0123456789', 'false', 'false', 'parolica');

INSERT INTO public.candidates(
	forename, surname, university, faculty, study_year, discipline, email, phone, internal_candidate, alumni_candidate, password)
	VALUES ('mitica', 'pavel3', 'universitatea', 'facultatea', '1', 'AM', 'email@mail.com', '0123456789', 'false', 'false', 'parolica');

INSERT INTO public.candidates(
	forename, surname, university, faculty, study_year, discipline, email, phone, internal_candidate, alumni_candidate, password)
	VALUES ('mitica', 'pavel4', 'universitatea', 'facultatea', '1', 'AM', 'email@mail.com', '0123456789', 'false', 'false', 'parolica');

INSERT INTO public.candidates(
	forename, surname, university, faculty, study_year, discipline, email, phone, internal_candidate, alumni_candidate, password)
	VALUES ('mitica', 'pavel5', 'universitatea', 'facultatea', '1', 'AM', 'email@mail.com', '0123456789', 'false', 'false', 'parolica');
	

INSERT INTO public.CAMPAIGNS(NAME, ACCOUNTED_PERSON, NET_CANDIDATES, JAVA_CANDIDATES, AM_CANDIDATES, TESTING_CANDIDATES, START_CAMPAIGN, START_PROMOTING, START_TESTS, START_INTERNSHIP, END_INTERNSHIP)
	VALUES ('Winter school 2016', 'Vasile Gheorghe', 10, 20, 20, 20, '03-10-2016', '03-10-2016', '03-10-2016', '03-11-2016','08-12-2016');	
INSERT INTO public.CAMPAIGNS(NAME, ACCOUNTED_PERSON, NET_CANDIDATES, JAVA_CANDIDATES, AM_CANDIDATES, TESTING_CANDIDATES, START_CAMPAIGN, START_PROMOTING, START_TESTS, START_INTERNSHIP, END_INTERNSHIP)
	VALUES ('Internship summer 2016', 'Vasile Gheorghe', 10, 20, 20, 20, '03-05-2016', '03-05-2016', '03-05-2016', '08-07-2016','08-09-2016');	
INSERT INTO public.CAMPAIGNS(NAME, ACCOUNTED_PERSON, NET_CANDIDATES, JAVA_CANDIDATES, AM_CANDIDATES, TESTING_CANDIDATES, START_CAMPAIGN, START_PROMOTING, START_TESTS, START_INTERNSHIP, END_INTERNSHIP)
	VALUES ('Winter school 2017', 'Vasile Gheorghe', 10, 20, 20, 20, '03-10-2017', '03-10-2017', '03-10-2017', '08-11-2017','08-12-2017');	
INSERT INTO public.CAMPAIGNS(NAME, ACCOUNTED_PERSON, NET_CANDIDATES, JAVA_CANDIDATES, AM_CANDIDATES, TESTING_CANDIDATES, START_CAMPAIGN, START_PROMOTING, START_TESTS, START_INTERNSHIP, END_INTERNSHIP)
	VALUES ('Internship summer 2017', 'Vasile Gheorghe', 10, 20, 20, 20, '03-05-2017', '03-05-2017', '03-05-2017', '08-07-2017','08-09-2017');	
INSERT INTO public.CAMPAIGNS(NAME, ACCOUNTED_PERSON, NET_CANDIDATES, JAVA_CANDIDATES, AM_CANDIDATES, TESTING_CANDIDATES, START_CAMPAIGN, START_PROMOTING, START_TESTS, START_INTERNSHIP, END_INTERNSHIP)
	VALUES ('Internship summer 2018', 'Vasile Gheorghe', 10, 20, 20, 20, '03-05-2018', '03-05-2018', '03-05-2018', '08-07-2018','08-09-2018');

insert into exams values( 1,1,7,'GRADED','10-10-2018','10-10-2018');
insert into exams values( 2,1,7,'GRADED','10-10-2018','10-10-2018');
insert into exams values( 3,1,0,'READY_TO_SEND',null,null);
insert into exams values( 4,1,7,'GRADED','10-10-2018','10-10-2018');
insert into exams values( 5,1,0,'READY_TO_SEND',null,null);

insert into candidates_campaign(candidate_id, campaign_id) values(1,1);
insert into candidates_campaign(candidate_id, campaign_id) values(2,2);
insert into candidates_campaign(candidate_id, campaign_id) values(3,3);
insert into candidates_campaign(candidate_id, campaign_id) values(4,4);
insert into candidates_campaign(candidate_id, campaign_id) values(5,5);



--FOR TESTING PURPOSES

insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Test1',1,'TESTING',1,3,'03-07-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Test2',2,'TESTING',1,3,'03-07-2018','07-05-2018');
insert into questions( title, type, discipline, difficulty, no_of_points, created_at, updated_at) values ('Test3',3,'TESTING',1,3,'03-07-2018','07-05-2018');

insert into answers(question_id, answer_text) values (49, 'this is the correct answer for question 49');
insert into answers(question_id, answer_text) values (49, 'this is a wrong answer for question 49');
insert into answers(question_id, answer_text) values (49, 'this is a wrong answer for question 49');
insert into answers(question_id, answer_text) values (49, 'this is a wrong answer for question 49');
insert into answers(question_id, answer_text) values (50, 'this is the correct answer for question 50');
insert into answers(question_id, answer_text) values (51, 'this is the correct answer for question 51');

update questions set correct_answer_text = 'this is the correct answer for question 49' where id = 49;
update questions set correct_answer_text = 'this is the correct answer for question 50' where id = 50;
update questions set correct_answer_text = 'this is the correct answer for question 51' where id = 51;

insert into tests(NAME, DISCIPLINE, NUMBER_OF_QUESTIONS, CREATED_AT, UPDATED_AT) VALUES('Test for Testing', 'TESTING', 3, '07-05-2018','07-05-2018');

insert into questions_test(question_id, test_id) values (49, 1);
insert into questions_test(question_id, test_id) values (50, 1);
insert into questions_test(question_id, test_id) values (51, 1);

--END TESTING PURPOSES
						   