import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-edit-candidate',
  templateUrl: './edit-candidate.component.html',
  styleUrls: ['./edit-candidate.component.css']
})
export class EditCandidateComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }

  goToCandidatesPage(){
    this.router.navigateByUrl('candidates');
  }
}
