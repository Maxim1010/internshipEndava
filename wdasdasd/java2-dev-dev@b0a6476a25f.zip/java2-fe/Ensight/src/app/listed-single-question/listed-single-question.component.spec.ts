import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListedSingleQuestionComponent } from './listed-single-question.component';

describe('ListedSingleQuestionComponent', () => {
  let component: ListedSingleQuestionComponent;
  let fixture: ComponentFixture<ListedSingleQuestionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListedSingleQuestionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListedSingleQuestionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
