import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Question } from '../models/Question';
import { QuestionsService } from '../services/questions.service'
import { Router } from '@angular/router';
import { MappingService } from '../services/mapping.service';

@Component({
  selector: 'app-listed-single-question',
  templateUrl: './listed-single-question.component.html',
  styleUrls: ['./listed-single-question.component.css']
})
export class ListedSingleQuestionComponent implements OnInit {

  @Input() question;
  @Input() index;
  @Output() isMarked = new EventEmitter<boolean>();
  @Output() mustUpdateQuestionList = new EventEmitter<boolean>();
  @Output() deleteQuestion = new EventEmitter<number>();

  @Input()
  markedForDelete:boolean = false;

  constructor(private service: QuestionsService, private router : Router, public map : MappingService) { }

  ngOnInit() {
  }

  checkIfRowIsEven(){
    return this.index % 2 === 0 
  }

  deleteRequest(){ 
    // this.mustUpdateQuestionList.emit(true);
    // this.service.deleteRequest(this.question.id);
    // this.mustUpdateQuestionList.emit(true);
    this.deleteQuestion.emit(this.question.id);
    console.log("single question selected: true");
  }

  goOnEditPage(){
    this.router.navigateByUrl("question/" + this.question.id + "/edit");
  }

  goOnOverviewPage(){
    this.router.navigateByUrl("question/"+this.question.id);
  }

  toggleCheckForDelete(){
    this.markedForDelete=!this.markedForDelete;
    this.question.markedToDelete = this.markedForDelete;
    this.isMarked.emit(this.question.markedForDelete);
  }

  markAll(marked:boolean){
    this.markedForDelete=marked;
    this.question.markedToDelete = marked;
    this.isMarked.emit(this.question.markedForDelete);
  }
  
  
}
