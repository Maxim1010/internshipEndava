import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { Question } from '../models/Question';
import { CandidateAnswersService } from '../services/candidate-answers.service';

@Component({
  selector: 'app-take-test-open-answer',
  templateUrl: './take-test-open-answer.component.html',
  styleUrls: ['./take-test-open-answer.component.css']
})
export class TakeTestOpenAnswerComponent implements OnInit {
  @Input()
  question : Question;
  
  constructor(public candidateAnswerService: CandidateAnswersService, private router:Router) { }

  ngOnInit() {
    this.candidateAnswerService.candidateAnswerText=null;
  }

  goToSingleAnswerPage(){
    this.router.navigateByUrl('take_test/single_answer');
  }

  goToSummaryPage(){
    this.router.navigateByUrl('take_test/end');
  }
}
