import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TakeTestOpenAnswerComponent } from './take-test-open-answer.component';

describe('TakeTestOpenAnswerComponent', () => {
  let component: TakeTestOpenAnswerComponent;
  let fixture: ComponentFixture<TakeTestOpenAnswerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TakeTestOpenAnswerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TakeTestOpenAnswerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
