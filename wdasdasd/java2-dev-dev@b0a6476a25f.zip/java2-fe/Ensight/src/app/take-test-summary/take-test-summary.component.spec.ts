import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TakeTestSummaryComponent } from './take-test-summary.component';

describe('TakeTestSummaryComponent', () => {
  let component: TakeTestSummaryComponent;
  let fixture: ComponentFixture<TakeTestSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TakeTestSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TakeTestSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
