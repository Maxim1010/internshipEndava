import { Component, OnInit } from '@angular/core';
import { Test } from '../models/Test';
import { TestService } from '../services/test.service';
import { Router, ActivatedRoute } from '@angular/router';
import { GeneralSettings } from '../models/GeneralSettings';
import { GeneralSettingsService } from '../services/general-settings.service';
import { MappingService } from '../services/mapping.service';
import { ExamService } from '../services/exam.service';

@Component({
  selector: 'app-take-test-summary',
  templateUrl: './take-test-summary.component.html',
  styleUrls: ['./take-test-summary.component.css']
})
export class TakeTestSummaryComponent implements OnInit {
  testId: number;
  test: Test = new Test();
  generalSettings: GeneralSettings = new GeneralSettings();
  isTimeExpired: boolean;

  constructor(public map: MappingService,
    private testService: TestService, 
    private generalSettingsService: GeneralSettingsService, 
    private router: Router, 
    private route: ActivatedRoute,
    private examService: ExamService) { }
  
  ngOnInit() {
    this.hideMyBanner();
    this.examService.currentExamTimeBanner.subscribe(timeUp => this.isTimeExpired = timeUp);
    this.testId = parseInt(this.route.snapshot.paramMap.get('id'));
    this.testService.getById(this.testId).subscribe(response => this.test = response as Test);
    this.generalSettingsService.getGeneralSettings().subscribe(response => this.generalSettings = response as GeneralSettings);
  }

  hideBannerOnClick(){
    this.examService.changeExamTimeBannerVisibility(false);
  }

  hideMyBanner(){
    setTimeout(() => {
      this.examService.changeExamTimeBannerVisibility(false)},
      3000);
  }

}
