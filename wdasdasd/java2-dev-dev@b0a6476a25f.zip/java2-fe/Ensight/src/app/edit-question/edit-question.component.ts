import { Component, OnInit, Output, Input } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormControl, FormGroup, FormBuilder} from '@angular/forms';
import { QuestionMultipleChoice } from '../models/QuestionMultipleChoice';
import { MultipleChoiceComponent } from '../multiple-choice/multiple-choice.component';
import { modelGroupProvider } from '../../../node_modules/@angular/forms/src/directives/ng_model_group';
import { Question } from '../models/Question';
import { QuestionsAttributesComponent } from '../questions-attributes/questions-attributes.component';
import { Router } from '@angular/router';
import { Answer } from '../models/Answer';
import { QuestionsService } from '../services/questions.service';
import { AnswersService } from '../services/answers.service';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-edit-question',
  templateUrl: './edit-question.component.html',
  styleUrls: ['./edit-question.component.css']
})
export class EditQuestionComponent implements OnInit {
 
  @Output() typeFromOut:any = "2";
  @Input() questionText;
  @Input() question : Question = new Question();
  @Input() answer: Answer = new Answer();
  @Input() answer1: Answer = new Answer();
  @Input() answer2: Answer = new Answer();
  @Input() answer3: Answer = new Answer();
  @Input() answer4: Answer = new Answer();
  @Input() correctAnswer = "answer1";


  questionId: any;
  outputType:any = "1";
  difficulty:any = "1";
  numberOfPoints:any = "1";
  discipline:any = "AM";
  answersList: Answer[] = [];

  constructor( private questionService : QuestionsService, private router: Router,
    private answerService: AnswersService, private route: ActivatedRoute) {
  }

    ngOnInit(){
      this.questionId = parseInt(this.route.snapshot.paramMap.get('id'));

      this.questionService.getById(this.questionId)
        .subscribe(response => { this.question = response as Question; console.log(response);
          this.outputType= String(this.question.type)
          this.typeFromOut= this.outputType;
          this.difficulty=String(this.question.difficulty);
          this.numberOfPoints=String(this.question.noOfPoints);
          this.discipline = String(this.question.discipline);
         });
  
      this.answerService.getAllByQuestionId(this.questionId)
        .subscribe(response => {this.answersList = response as Answer[];
                                this.answer=this.answersList[0];
                                this.answer1=this.answersList[0];
                                this.answer2=this.answersList[1];
                                this.answer3=this.answersList[2];
                                this.answer4=this.answersList[3];
                                });
    }

    submitQuestionSingle(){
      this.question.type=this.typeFromOut;
      if(this.outputType==1){
        this.answerService.deleteExcepting(this.answer).subscribe(res=>{
          this.questionService.updateQuestion(this.question).subscribe(res=> {
            this.answer.questionId = parseInt(res.toString());
            this.questionService.updateAnswer(this.answer).subscribe(res=>{this.goToQuestionsPage();
              this.questionService.changeEditQuestionBannerVisibility(true);
            });
          } );  
        });
      }
      else{
        this.questionService.updateQuestion(this.question).subscribe(res=> {
        this.answer.questionId = parseInt(res.toString());
        this.questionService.updateAnswer(this.answer).subscribe(res=>{this.goToQuestionsPage();
        this.questionService.changeEditQuestionBannerVisibility(true);
        });
      } );
      }
    }

    submitQuestionMultiple(){
      this.question.type=this.typeFromOut;
      if(this.outputType!="1"){
        let answers: Answer[]=[];
        this.answer2.questionId = parseInt(this.questionId);
        this.answer3.questionId = parseInt(this.questionId);
        this.answer4.questionId = parseInt(this.questionId);
        this.answer2.answerId=null;
        this.answer3.answerId=null;
        this.answer4.answerId=null;
        answers.push(this.answer2);
        answers.push(this.answer3);
        answers.push(this.answer4);
        this.questionService.createAnswerMultiple(answers).subscribe(res=>{this.answerService.getAllByQuestionId(this.questionId)
          .subscribe(response => {this.answersList = response as Answer[];
                                  this.answer=this.answersList[0];
                                  this.answer1=this.answersList[0];
                                  this.answer2=this.answersList[1];
                                  this.answer3=this.answersList[2];
                                  this.answer4=this.answersList[3];
                                  this.createAnswerList();
                                  this.updateAnswers();});});
       }
       else{
        this.createAnswerList();
        this.updateAnswers();
       }
    }

    updateAnswers(){
      this.question.correctAnswerText = this.answersList[0].answerText;
      this.questionService.updateQuestion(this.question).subscribe(res =>{
          console.log("update ok!");
          console.log("ordine: "+ this.answersList[0].answerId+" * "+ this.answersList[1].answerId+" * "+ this.answersList[2].answerId+" * "+ this.answersList[3].answerId+" * ");
          this.answer1.questionId = parseInt(this.questionId);
          this.answer2.questionId = parseInt(this.questionId);
          this.answer3.questionId = parseInt(this.questionId);
          this.answer4.questionId = parseInt(this.questionId);
          this.questionService.updateAnswerMultiple(this.answersList).subscribe(res=>{this.goToQuestionsPage();
          this.questionService.changeEditQuestionBannerVisibility(true);
          });
          });

      console.log('difficulty '  +this.question.difficulty);
      console.log('no of points ' +  this.question.noOfPoints);
      console.log('discipline ' + this.question.discipline);
      console.log('title ' + this.question.title);
      console.log('answer 1 ' + this.answersList[0].answerText);
      console.log('answer 2 ' + this.answersList[1].answerText);
      console.log('answer 3 ' + this.answersList[2].answerText);
      console.log('answer 4 ' + this.answersList[3].answerText);
    }

    getTypeOfQuestion(typeOfAnswer){
      console.log("type changed to "+ typeOfAnswer);
      this.typeFromOut = typeOfAnswer;
      this.answer1=this.answer1;
      if (typeof this.answer2 == 'undefined')
      {
        this.answer2=Object.assign({}, this.answer1);
        this.answer3=Object.assign({}, this.answer1);
        this.answer4=Object.assign({}, this.answer1);
      }
    }
  
    getDifficulty(difficulty){
      console.log("difficulty changed to "+ difficulty);
      this.question.difficulty = difficulty;
    }
  
    getNoOfPoints(noOfPoints){
      console.log("no of points changed to "+ noOfPoints);
      this.question.noOfPoints = noOfPoints;
    }
  
    getDiscipline(discipline){
      console.log("discipline changed to "+ discipline);
      this.question.discipline = discipline;
    }
    goToQuestionsPage(){
      this.router.navigateByUrl('questions');
    }

    createAnswerList(){
      if(this.correctAnswer == "answer1"){
        this.answersList[0] = this.answer1;
        this.answersList[1] = this.answer2;
        this.answersList[2] = this.answer3;
        this.answersList[3] = this.answer4;
      }
      if(this.correctAnswer == "answer2"){
        this.answersList[0] = this.answer2;
        this.answersList[1] = this.answer1;
        this.answersList[2] = this.answer3;
        this.answersList[3] = this.answer4;
      }
      if(this.correctAnswer == "answer3"){
        this.answersList[0] = this.answer3;
        this.answersList[1] = this.answer1;
        this.answersList[2] = this.answer2;
        this.answersList[3] = this.answer4;
      }
      if(this.correctAnswer == "answer4"){
        this.answersList[0] = this.answer4;
        this.answersList[1] = this.answer1;
        this.answersList[2] = this.answer2;
        this.answersList[3] = this.answer3;
      }
      console.log('correct answer is ' + this.correctAnswer);
      console.log('first answer' + this.answersList[0]);
      
    }
  
}
