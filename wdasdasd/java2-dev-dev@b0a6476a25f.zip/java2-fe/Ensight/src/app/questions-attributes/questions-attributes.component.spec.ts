import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuestionsAttributesComponent } from './questions-attributes.component';

describe('QuestionsAttributesComponent', () => {
  let component: QuestionsAttributesComponent;
  let fixture: ComponentFixture<QuestionsAttributesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuestionsAttributesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuestionsAttributesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
