import { Component, OnInit, Input, Injectable } from '@angular/core';
import { AddQuestionComponent } from '../add-question/add-question.component';
import { ControlContainer, FormGroup } from '../../../node_modules/@angular/forms';

@Component({
  selector: 'app-questions-attributes',
  templateUrl: './questions-attributes.component.html',
  styleUrls: ['./questions-attributes.component.css']
})
@Injectable({
  providedIn: 'root',
})
export class QuestionsAttributesComponent implements OnInit {

  @Input() outputType = "1";
  @Input() difficulty = "1";
  @Input() numberOfPoints = "1";
  @Input() discipline = "AM";

  constructor(private addQeustions: AddQuestionComponent) {}

  ngOnInit() {}

  
  public getAnswerType(){
    this.addQeustions.getTypeOfQuestion(this.outputType);
  }

  public getDifficulty(){
    this.addQeustions.getDifficulty(this.difficulty);
  }

  public getNoOfPoints(){
    this.addQeustions.getNoOfPoints(this.numberOfPoints);
  }

  public getDiscipline(){
    this.addQeustions.getDiscipline(this.discipline);
  }
}
