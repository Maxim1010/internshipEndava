import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuestionAttributesEditComponent } from './question-attributes-edit.component';

describe('QuestionAttributesEditComponent', () => {
  let component: QuestionAttributesEditComponent;
  let fixture: ComponentFixture<QuestionAttributesEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuestionAttributesEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuestionAttributesEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
