import { Component, OnInit, Input, Injectable } from '@angular/core';
import { ControlContainer, FormGroup } from '../../../node_modules/@angular/forms';
import { EditQuestionComponent } from '../edit-question/edit-question.component';

@Component({
  selector: 'app-question-attributes-edit',
  templateUrl: './question-attributes-edit.component.html',
  styleUrls: ['./question-attributes-edit.component.css']
})
@Injectable({
  providedIn: 'root',
})
export class QuestionAttributesEditComponent implements OnInit {

 
  @Input() outputType:any = "1";
  @Input() difficulty:any = "1";
  @Input() numberOfPoints:any = "1";
  @Input() discipline:any = "AM";

  constructor(private editQuestions: EditQuestionComponent) {}

  ngOnInit() {}

  
  public getAnswerType(){
    this.editQuestions.getTypeOfQuestion(this.outputType);
  }

  public getDifficulty(){
    this.editQuestions.getDifficulty(this.difficulty);
  }

  public getNoOfPoints(){
    this.editQuestions.getNoOfPoints(this.numberOfPoints);
  }

  public getDiscipline(){
    this.editQuestions.getDiscipline(this.discipline);
  }
}
