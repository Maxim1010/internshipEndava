import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TakeTestSingleAnswerComponent } from './take-test-single-answer.component';

describe('TakeTestSingleAnswerComponent', () => {
  let component: TakeTestSingleAnswerComponent;
  let fixture: ComponentFixture<TakeTestSingleAnswerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TakeTestSingleAnswerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TakeTestSingleAnswerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
