import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { Question } from '../models/Question';
import { Answer } from '../models/Answer';
import { AnswersService } from '../services/answers.service';
import { CandidateAnswersService } from '../services/candidate-answers.service';

@Component({
  selector: 'app-take-test-single-answer',
  templateUrl: './take-test-single-answer.component.html',
  styleUrls: ['./take-test-single-answer.component.css']
})
export class TakeTestSingleAnswerComponent implements OnInit {

  @Input()
  question : Question;
  answerList: Answer[]= [];
  correctAnswer: string;
  loaded: boolean = false;

  constructor(private candidateAnswerService: CandidateAnswersService,private router: Router, private answerService: AnswersService) { }

  ngOnInit() {
    this.candidateAnswerService.candidateAnswerText=null;
    this.answerService.getAllByQuestionId(this.question.id)
    .subscribe(res=>{this.answerList= res as Answer[]; 
      this.correctAnswer= this.answerList[0].answerText;
      console.log("corect: "+this.correctAnswer);
      this.answerList =this.shuffle(this.answerList);
      this.loaded=true;
    })
  }

   shuffle(array) {
    var currentIndex = array.length, temporaryValue, randomIndex;
  
    while (0 !== currentIndex) {
      randomIndex = Math.floor(Math.random() * currentIndex);
      currentIndex -= 1;
      temporaryValue = array[currentIndex];
      array[currentIndex] = array[randomIndex];
      array[randomIndex] = temporaryValue;
    }
    return array;
  }

  setCorrectAnswerText(){
    if(this.correctAnswer=="answer1"){
      this.candidateAnswerService.candidateAnswerText=this.answerList[0].answerText;
    }
    if(this.correctAnswer=="answer2"){
      this.candidateAnswerService.candidateAnswerText=this.answerList[1].answerText;
    }
    if(this.correctAnswer=="answer3"){
      this.candidateAnswerService.candidateAnswerText=this.answerList[2].answerText;
    }
    if(this.correctAnswer=="answer4"){
      this.candidateAnswerService.candidateAnswerText=this.answerList[3].answerText;
    }
  }
  
  goToSummaryPage(){
    this.router.navigateByUrl('take_test/end');
  }

}
