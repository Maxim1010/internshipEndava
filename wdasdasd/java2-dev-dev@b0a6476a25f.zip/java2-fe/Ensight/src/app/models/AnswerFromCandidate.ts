import { CandidateTestQuestionsCompositeKey } from './CandidateTestQuestionCompositeKey';

export class AnswerFromCandidate{
    id: CandidateTestQuestionsCompositeKey;
    answerText: string;
    isCorrect: boolean;
}