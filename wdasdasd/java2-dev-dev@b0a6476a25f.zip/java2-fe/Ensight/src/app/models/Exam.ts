import { CandidateTestCompositeKey } from "./CandidateTestCompositeKey";
import { DatePipe } from "@angular/common";

export class Exam{
    id: CandidateTestCompositeKey;
    grade: number;
    status: string;
    startTime: DatePipe;
    endTime: DatePipe;
}
