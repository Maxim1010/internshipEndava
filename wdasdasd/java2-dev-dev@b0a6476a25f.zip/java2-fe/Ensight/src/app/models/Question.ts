import { Answer } from "./Answer";

export class Question{
    id:number;
    title: string;
    type: number;
    discipline: string;
    difficulty: number;
    noOfPoints: number;
    correctAnswerText: string;
    createdAt: Date;
    updatedAt: Date;
    answer:Answer;
}