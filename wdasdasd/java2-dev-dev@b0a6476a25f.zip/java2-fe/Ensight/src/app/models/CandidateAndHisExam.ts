import { Candidate } from "./Candidate";

import { Exam } from "./Exam";

export class CandidateAndHisExam{
    candidate: Candidate;
    exam : Exam;
}