 
export class GenerateParams{
    numberOfQuestions: number;
    discipline: string;
    easyPercent: number;
    mediumPercent: number;
    hardPercent: number;
    numberOfTests: number;
}