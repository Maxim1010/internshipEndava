export class Campaign{
    id: number;
    name: string;
    accountedPerson: string;
    netCandidates: number;
    javaCandidates: number;
    amCandidates: number;
    testingCandidates: number;
    startCampaign: Date;
    startPromoting: Date;
    startTests: Date;
    startInternship: Date;
    endInternship: Date;
}