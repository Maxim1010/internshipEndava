export class Test{
    id:number;
    name: string;
    discipline: string;
    numberOfQuestions: number;
    createdAt: Date;
    updatedAt: Date;
}