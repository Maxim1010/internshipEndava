import { Question } from "./Question";

export class Answer {
    answerId:number;
    questionId:number;
    answerText:string;
    //question: Question;
}
