export class ErrorsLogXSL{
    errorList: string[];
    constructor(){
        this.errorList = [];
    }
}