import { Candidate } from "./Candidate";

export class WrapperCandidateListImport{
    candidates: Array<Candidate>;
    constructor(){
        this.candidates = [];
    }
}