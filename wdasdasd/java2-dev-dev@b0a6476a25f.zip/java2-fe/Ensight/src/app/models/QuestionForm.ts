export class QuestionForm{
    question:string;
    answer:any;
    answer1:any;
    answer2:any;
    answer3:any;
    answer4:any;
}