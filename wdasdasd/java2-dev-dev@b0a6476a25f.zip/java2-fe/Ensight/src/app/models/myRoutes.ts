
import { Routes } from '@angular/router';
import { TakeTestPageComponent } from '../take-test-page/take-test-page.component';
import { PendingChangesGuard } from './NavigationDezactivate';

export const MY_ROUTES: Routes = [
  { path: '', component: TakeTestPageComponent, canDeactivate: [PendingChangesGuard] },
];