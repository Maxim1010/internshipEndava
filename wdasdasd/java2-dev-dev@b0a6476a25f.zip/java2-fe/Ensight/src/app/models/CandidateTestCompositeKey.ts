export class CandidateTestCompositeKey{
    candidateId: number;
    testId: number;
}
