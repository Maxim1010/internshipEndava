export class CandidateTestQuestionsCompositeKey{
    candidateId: number;
    testId: number;
    questionId: number;
}