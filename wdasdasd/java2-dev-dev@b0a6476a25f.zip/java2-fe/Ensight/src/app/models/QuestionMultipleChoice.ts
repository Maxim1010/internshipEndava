export class QuestionMultipleChoice{
    
}