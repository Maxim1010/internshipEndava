import { CandidateAndHisExam } from "./CandidateAndHisExam";

export class CandidateChecked{
    candidateAndExam: CandidateAndHisExam;
    isChecked: boolean;
}