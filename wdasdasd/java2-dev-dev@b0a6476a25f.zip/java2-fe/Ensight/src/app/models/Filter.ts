import { NgForm } from '@angular/forms';

export class Difficulty { 
    easy: boolean = false;
    moderate: boolean = false;
    hard: boolean = false;
    constructor(){}
  
    setDifficulty(form: NgForm){
    this.easy=form.controls['easy'].value;
    this.moderate=form.controls['moderate'].value;
    this.hard=form.controls['hard'].value;
    }
  } 
  
  export class Type { 
    single: boolean = false;
    open: boolean = false;
    code: boolean = false;
    constructor(){}
    
    setType(form: NgForm){
     this.single=form.controls['single'].value;
     this.open=form.controls['open'].value;
     this.code=form.controls['code'].value;
    }
  } 
  
  export class Discipline { 
    am: boolean = false;
    net: boolean = false;
    java: boolean = false;
    testing: boolean = false;
  
    setDiscipline(form: NgForm){
     this.am=form.controls['am'].value;
     this.net=form.controls['net'].value;
     this.java=form.controls['java'].value;
     this.testing=form.controls['testing'].value;
    }
    constructor(){}
  } 