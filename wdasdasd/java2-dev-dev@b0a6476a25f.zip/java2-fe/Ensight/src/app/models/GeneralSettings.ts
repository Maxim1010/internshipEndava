export class GeneralSettings{
    duration: number;
    linkAvailability: number;
    instructions: string;
    summary: string;
}