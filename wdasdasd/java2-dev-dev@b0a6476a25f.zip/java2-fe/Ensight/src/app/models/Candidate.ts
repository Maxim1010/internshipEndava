export class Candidate{
    id: number;
    forename: string;
    surname: string;
    university: string;
    faculty: string;
    studyYear: number;
    discipline: string;
    email: string;
    phone: string;
    internalCandidate: boolean;
    alumniCandidate: boolean;
    password: string;
}
