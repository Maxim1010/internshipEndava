import { Injectable } from '@angular/core';
import { Candidate } from '../models/Candidate';
import { Observable } from 'rxjs';
import { AppComponent } from '../app.component';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmailService {

  constructor(private http: HttpClient) { }

  sendEmail<T>(listOfCandidates: Candidate[] ): Observable<T> {
    const requestUrl = AppComponent.serverUrl + "/email/send";
    return this.http.post<T>(requestUrl, listOfCandidates);
  }
}
