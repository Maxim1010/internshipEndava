import { Injectable } from '@angular/core';

import { Exam } from '../models/Exam';
import { Observable, BehaviorSubject } from 'rxjs';
import { AppComponent } from '../app.component';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ExamService {

  private examTimeExpiredBanner = new BehaviorSubject(false);
  currentExamTimeBanner = this.examTimeExpiredBanner.asObservable();
  
  executeOnce: boolean = false;

  constructor(private http: HttpClient) { }

  changeExamTimeBannerVisibility(isVisibile: boolean){
    
    this.examTimeExpiredBanner.next(isVisibile);
    
  }

  createExam<T>(exam: Exam): Observable<T> {
    const requestUrl = AppComponent.serverUrl + "/exam";
    return this.http.post<T>(requestUrl, exam);
  }

  checkIfCandidateStartedExam(testId, candidateId) {
    const requestUrl = AppComponent.serverUrl + "/exams/is-started/" + candidateId + "-" + testId;
    console.log('the url for request of candidate exam ' + requestUrl);
    return this.http.get(requestUrl);
  }

  endTest(testId, candidateId) {
    const requestUrl = AppComponent.serverUrl + "/exam/end/" + candidateId + "-" + testId;
    console.log(requestUrl + " called");
    return this.http.get(requestUrl);
  }

  startExam(testId,candidateId){
    const requestUrl = AppComponent.serverUrl + "/exam/start/" + candidateId + "-" + testId;
    return this.http.get(requestUrl);
  }
}
