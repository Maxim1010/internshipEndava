import { Injectable } from '@angular/core';
import { AppComponent } from '../app.component';
import { HttpClient } from '@angular/common/http';
import { AnswerFromCandidate } from '../models/AnswerFromCandidate';

@Injectable({
  providedIn: 'root'
})
export class CandidateAnswersService {

  candidateAnswerText: string;

  constructor(private http: HttpClient) { }

  public submitAnswerFromCandidate(answerFromCandidate: AnswerFromCandidate){
    const requestUrl = AppComponent.serverUrl + '/answer-from-candidate/create';
    return this.http.post(requestUrl, answerFromCandidate);
  }
}
