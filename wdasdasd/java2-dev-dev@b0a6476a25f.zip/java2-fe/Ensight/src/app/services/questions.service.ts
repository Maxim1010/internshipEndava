import { Injectable } from '@angular/core';
import { HttpClient, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { Question } from '../models/Question';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { Difficulty, Type, Discipline } from '../models/Filter';
import { Answer } from '../models/Answer';
import { AppComponent } from '../app.component';
import {} from 'rxjs/add/operator/toPromise';

@Injectable({
  providedIn: 'root'
})
export class QuestionsService {

  filter = {
    difficulty: new Difficulty(),
    type: new Type(),
    discipline: new Discipline()
  }
  pageNumber: number = 1;
  sortField: number = 2;
  order: String="asc";
  isCreated = false;

  private afterDeleteCheckSource = new BehaviorSubject(false);
  currentAfterDeleteCheck = this.afterDeleteCheckSource.asObservable();

  private addQuestionBannerSource = new BehaviorSubject(false);
  currentBanner = this.addQuestionBannerSource.asObservable();

  private editQuestionBannerSource = new BehaviorSubject(false);
  currentEditBanner = this.editQuestionBannerSource.asObservable();
  
  totalQuestions: number = 0;

  constructor(private http: HttpClient, private router :Router) { 
  }

  changeAfterDeleteCheckValue(isChecked: boolean){
      this.afterDeleteCheckSource.next(isChecked);
  }

  changeAddQuestionBannerVisibility(isBannerVisible: boolean){
    this.addQuestionBannerSource.next(isBannerVisible);
  }

  changeEditQuestionBannerVisibility(isBannerVisible: boolean){
    this.editQuestionBannerSource.next(isBannerVisible);
  }

  public getAll<T>(): Observable<T> {
    const requestUrl = AppComponent.serverUrl + '/questions/all';

    return this.http.get<T>(requestUrl);
  }

  public getById<T>(questionId: number): Observable<T> {
    const requestUrl = AppComponent.serverUrl + "/questions/" + questionId;
    return this.http.get<T>(requestUrl);
  }

  public deleteRequest<T>(id): Observable<T> {
    const requestUrl = AppComponent.serverUrl + '/question/delete/';
    return this.http.delete<T>(requestUrl + id);

  }

  public multipleDeleteRequest<T>(ids: Array<number>): Observable<T> {
    const requestUrl = AppComponent.serverUrl + '/question/delete/multiple';
    const body = ids;
    return this.http.post<T>(requestUrl, body);

  }

  public getFilteredAndSortedQuestions<T>(): Observable<T> {
    let requestUrl = AppComponent.serverUrl + '/questions/filter/sort?';

    if (!this.filter.difficulty.easy &&
      !this.filter.difficulty.moderate
      && !this.filter.difficulty.hard) {
      requestUrl = requestUrl + "difficulty=1,2,3&"
    }
    else {
      if (this.filter.difficulty.easy == true)
        requestUrl = requestUrl + "difficulty=1&"

      if (this.filter.difficulty.moderate == true)
        requestUrl = requestUrl + "difficulty=2&"

      if (this.filter.difficulty.hard == true)
        requestUrl = requestUrl + "difficulty=3&"
    }

    if (!this.filter.type.single &&
      !this.filter.type.open
      && !this.filter.type.code) {
      requestUrl = requestUrl + "type=1,2,3&"
    }
    else {
      if (this.filter.type.single == true)
        requestUrl = requestUrl + "type=1&"

      if (this.filter.type.open == true)
        requestUrl = requestUrl + "type=2&"

      if (this.filter.type.code == true)
        requestUrl = requestUrl + "type=3&"
    }

    if (!this.filter.discipline.am &&
      !this.filter.discipline.java
      && !this.filter.discipline.net && !this.filter.discipline.testing) {
      requestUrl = requestUrl + "discipline=1,2,3,4&"
    }
    else {
      if (this.filter.discipline.am == true)
        requestUrl = requestUrl + "discipline=1&"

      if (this.filter.discipline.net == true)
        requestUrl = requestUrl + "discipline=2&"

      if (this.filter.discipline.java == true)
        requestUrl = requestUrl + "discipline=3&"

      if (this.filter.discipline.testing == true)
        requestUrl = requestUrl + "discipline=4&"
    }

    requestUrl = requestUrl + "&sortField=" + this.sortField + "&order=" + this.order;

    requestUrl = requestUrl + "&page=" + this.pageNumber;

    this.count();

    return this.http.get<T>(requestUrl);
  }

  public count() {
    let requestUrl = AppComponent.serverUrl + '/questions/count?';

    if (!this.filter.difficulty.easy &&
      !this.filter.difficulty.moderate
      && !this.filter.difficulty.hard) {
      requestUrl = requestUrl + "difficulty=1,2,3&"
    }
    else {
      if (this.filter.difficulty.easy == true)
        requestUrl = requestUrl + "difficulty=1&"

      if (this.filter.difficulty.moderate == true)
        requestUrl = requestUrl + "difficulty=2&"

      if (this.filter.difficulty.hard == true)
        requestUrl = requestUrl + "difficulty=3&"
    }

    if (!this.filter.type.single &&
      !this.filter.type.open
      && !this.filter.type.code) {
      requestUrl = requestUrl + "type=1,2,3&"
    }
    else {
      if (this.filter.type.single == true)
        requestUrl = requestUrl + "type=1&"

      if (this.filter.type.open == true)
        requestUrl = requestUrl + "type=2&"

      if (this.filter.type.code == true)
        requestUrl = requestUrl + "type=3&"
    }

    if (!this.filter.discipline.am &&
      !this.filter.discipline.java
      && !this.filter.discipline.net && !this.filter.discipline.testing) {
      requestUrl = requestUrl + "discipline=1,2,3,4&"
    }
    else {
      if (this.filter.discipline.am == true)
        requestUrl = requestUrl + "discipline=1&"

      if (this.filter.discipline.net == true)
        requestUrl = requestUrl + "discipline=2&"

      if (this.filter.discipline.java == true)
        requestUrl = requestUrl + "discipline=3&"

      if (this.filter.discipline.testing == true)
        requestUrl = requestUrl + "discipline=4&"
    }

    requestUrl = requestUrl + "&sortField=" + this.sortField + "&order=" + this.order;

    this.http.get(requestUrl, { responseType: 'text' })
      .subscribe(response => this.totalQuestions = +response);
  }

  public createQusetion(question: Question){
    const requestUrl = AppComponent.serverUrl + '/question/create';
    return this.http.post(requestUrl, question);
  }

  public createAnswer(answer: Answer) {
    const requestUrl = AppComponent.serverUrl + '/answer/create';
    this.http.post(requestUrl, answer).subscribe(res => console.log('anser ' + res));

  }

  public createAnswerMultiple(answer: Answer[]) {
    const requestUrl = 'http://localhost:8085/answer/create/multiple';
     return this.http.post(requestUrl , answer);
    
  }

  public updateQuestion(question: Question){
    const requestUrl = AppComponent.serverUrl + '/question/edit';
    return this.http.put(requestUrl , question);
  }

  public updateAnswerMultiple(answer: Answer[]){
    const requestUrl = AppComponent.serverUrl + '/answer/edit/multiple';
    return this.http.put(requestUrl , answer);
  }

  public updateAnswer( answer: Answer){
    const requestUrl = AppComponent.serverUrl + '/answer/edit';
    return this.http.put(requestUrl , answer);
  }

  public isQuestionCreated(){
    return this.isCreated;
  }
}