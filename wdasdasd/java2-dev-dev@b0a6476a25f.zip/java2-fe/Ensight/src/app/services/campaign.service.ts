import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AppComponent } from '../app.component';

@Injectable({
  providedIn: 'root'
})
export class CampaignService {

  constructor(private http: HttpClient) { }

  getLastId<T>(): Observable<T> {
    const requestUrl = AppComponent.serverUrl + '/campaigns/last';
    return this.http.get<T>(requestUrl);
  }

  public getAll<T>(): Observable<T> {
    const requestUrl = AppComponent.serverUrl + '/campaigns';
    return this.http.get<T>(requestUrl);
  }

  getById<T>(id : number): Observable<T> {
    const requestUrl = AppComponent.serverUrl + '/campaign/'+id;
    return this.http.get<T>(requestUrl);
  }
}
