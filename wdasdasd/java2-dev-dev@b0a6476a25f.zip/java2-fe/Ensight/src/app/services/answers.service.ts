import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { AppComponent } from '../app.component';
import { Answer } from '../models/Answer';


@Injectable({
  providedIn: 'root'
})
export class AnswersService {

  constructor(private http: HttpClient) { }

  public getAllByQuestionId<T>(questionId:number): Observable<T> {
    const requestUrl = AppComponent.serverUrl + "/answers?questionId="+questionId;
    return this.http.get<T>(requestUrl);
  }

  public deleteExcepting<T>(answer: Answer): Observable<T> {
    const requestUrl = AppComponent.serverUrl + "/answers/delete/excepting/";
    return this.http.delete<T>(requestUrl + answer.answerId);
  }
}
