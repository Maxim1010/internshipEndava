import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { AppComponent } from '../app.component';
import { GeneralSettings } from '../models/GeneralSettings';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GeneralSettingsService {

  private generalSettingsUpdatedSource = new BehaviorSubject(false);
  currentGeneralSettingsUpdated = this.generalSettingsUpdatedSource.asObservable();

  constructor(private http: HttpClient) { }

  changeGeneralSettingsBannerVisibility(isUpdated: boolean){
    this.generalSettingsUpdatedSource.next(isUpdated);
  }

  updateGeneralSettings<T>(generalSettings: GeneralSettings): Observable<T> {
    const requestUrl = AppComponent.serverUrl + "/general-settings/update";
    return this.http.put<T>(requestUrl,generalSettings);
  }



  public getGeneralSettings<T>(): Observable<T>{
    const requestUrl = AppComponent.serverUrl + "/general-settings";
    return this.http.get<T>(requestUrl);
  }
}
