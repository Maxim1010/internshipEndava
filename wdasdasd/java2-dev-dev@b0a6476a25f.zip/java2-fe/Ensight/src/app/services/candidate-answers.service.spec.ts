import { TestBed, inject } from '@angular/core/testing';

import { CandidateAnswersService } from './candidate-answers.service';

describe('CandidateAnswersService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CandidateAnswersService]
    });
  });

  it('should be created', inject([CandidateAnswersService], (service: CandidateAnswersService) => {
    expect(service).toBeTruthy();
  }));
});
