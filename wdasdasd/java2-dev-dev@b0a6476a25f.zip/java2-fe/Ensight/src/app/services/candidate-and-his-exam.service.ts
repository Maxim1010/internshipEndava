import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { AppComponent } from '../app.component';
import { HttpClient } from '@angular/common/http';
import { CampaignService } from './campaign.service';

@Injectable({
  providedIn: 'root'
})
export class CandidateAndHisExamService {


  constructor(private http: HttpClient, private campaignService: CampaignService) {
  }

  public getAllByCampaignId<T>(id: number): Observable<T> {
    console.log(" id get: "+ id);
    const requestUrl = AppComponent.serverUrl + '/candidates-and-their-exams?campaignId=' + id;
    return this.http.get<T>(requestUrl);
  }


}
