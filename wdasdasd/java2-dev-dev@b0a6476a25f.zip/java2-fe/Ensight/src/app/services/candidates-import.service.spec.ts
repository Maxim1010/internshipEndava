import { TestBed, inject } from '@angular/core/testing';

import { CandidatesImportService } from './candidates-import.service';

describe('CandidatesImportService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CandidatesImportService]
    });
  });

  it('should be created', inject([CandidatesImportService], (service: CandidatesImportService) => {
    expect(service).toBeTruthy();
  }));
});
