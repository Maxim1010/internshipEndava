import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AppComponent } from '../app.component';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CandidateService {

  
  constructor(private http: HttpClient) { }

  public getAll<T>(): Observable<T> {
    const requestUrl = AppComponent.serverUrl + '/candidates';
    return this.http.get<T>(requestUrl);
  }

  public getById<T>(id: number): Observable<T> {
    const requestUrl = AppComponent.serverUrl + '/candidates/' + id;
    return this.http.get<T>(requestUrl);
  }
}
