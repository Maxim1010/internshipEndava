import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Discipline } from '../models/Filter';
import { Observable, BehaviorSubject } from 'rxjs';
import { GenerateParams } from '../models/GenerateParams';
import { AppComponent } from '../app.component';
import { Test } from '../models/Test';

@Injectable({
  providedIn: 'root'
})
export class TestService {

  maxPageNumber: number;
  pageNumber = 1;
  testId: number;
  test : Test = new Test();
  tests: Test[] = [];
  noOfQuestions: number;
  duration: number;
  backPageActioned= false;
  
  private isTestGeneratedSource = new BehaviorSubject(false);
  currentTest = this.isTestGeneratedSource.asObservable();

  private isAllCheckedSource = new BehaviorSubject(false);
  currentAllChecked = this.isAllCheckedSource.asObservable();


  constructor(private http: HttpClient, private router: Router) {
   }

   changeAllChekedStatus(isChecked: boolean){
     this.isAllCheckedSource.next(isChecked);
   }

   changeGenerateTestBannerVisibility(isGenerated: boolean){
    this.isTestGeneratedSource.next(isGenerated);
   }

  update<T>(test: Test): Observable<T> {
    const requestUrl = AppComponent.serverUrl + "/tests/update";
    return this.http.put<T>(requestUrl,test);
  }
  getQuestionsByTestId<T>(testId: number): Observable<T> {
    const requestUrl = AppComponent.serverUrl + "/tests/"+testId+"/questions";
    return this.http.get<T>(requestUrl);
  }

  filter = {
    discipline: new Discipline()
  }
  sortField: number = 2;
  order: String = "asc";



  public getAll<T>(): Observable<T> {
    const requestUrl = AppComponent.serverUrl + '/tests/all';

    return this.http.get<T>(requestUrl);
  }

  public getById<T>(testId: number): Observable<T> {
    const requestUrl = AppComponent.serverUrl + "/tests/" + testId;
    return this.http.get<T>(requestUrl);
  }

  public deleteRequest<T>(id): Observable<T> {
    const requestUrl = AppComponent.serverUrl + '/test/delete/';
    return this.http.delete<T>(requestUrl + id);
    
  }

  public multipleDeleteRequest<T>(ids:Array<number>): Observable<T>{
    const requestUrl = AppComponent.serverUrl + '/test/delete/multiple';
    const body = ids;
    return this.http.post<T>(requestUrl, body);
  }

  public getFilteredQuestions<T>(): Observable<T> {
    let requestUrl = AppComponent.serverUrl + '/tests/filter?';

    if (!this.filter.discipline.am &&
      !this.filter.discipline.java
      && !this.filter.discipline.net && !this.filter.discipline.testing) {
      requestUrl = requestUrl + "discipline=1,2,3,4&"
    }
    else {
      if (this.filter.discipline.am == true)
        requestUrl = requestUrl + "discipline=1&"

      if (this.filter.discipline.net == true)
        requestUrl = requestUrl + "discipline=2&"

      if (this.filter.discipline.java == true)
        requestUrl = requestUrl + "discipline=3&"

      if (this.filter.discipline.testing == true)
        requestUrl = requestUrl + "discipline=4&"
    }

    return this.http.get<T>(requestUrl);
  }


  public getFilteredAndSortedTests<T>(): Observable<T> {
    let requestUrl = AppComponent.serverUrl + '/tests/filter/sort?';

    if (!this.filter.discipline.am &&
      !this.filter.discipline.java
      && !this.filter.discipline.net && !this.filter.discipline.testing) {
      requestUrl = requestUrl + "discipline=1,2,3,4"
    }
    else {
      if (this.filter.discipline.am == true)
        requestUrl = requestUrl + "discipline=1&"

      if (this.filter.discipline.net == true)
        requestUrl = requestUrl + "discipline=2&"

      if (this.filter.discipline.java == true)
        requestUrl = requestUrl + "discipline=3&"

      if (this.filter.discipline.testing == true)
        requestUrl = requestUrl + "discipline=4&"
    }

    requestUrl = requestUrl + "&sortField=" + this.sortField + "&order=" + this.order;

    requestUrl = requestUrl + "&page=" + this.pageNumber;

    return this.http.get<T>(requestUrl);
  }

  public postGenerateTests<T>(testData: GenerateParams): Observable<T>{
    const requestUrl = AppComponent.serverUrl + "/tests/generate";
    return this.http.post<T>(requestUrl, testData);
  }

  public getNumberOfTestByFilter(){
    var requestUrl = AppComponent.serverUrl + '/count/tests?';

    if (!this.filter.discipline.am &&
      !this.filter.discipline.java
      && !this.filter.discipline.net && !this.filter.discipline.testing) {
      requestUrl = requestUrl + "discipline=1,2,3,4"
    }
    else {
      if (this.filter.discipline.am == true)
        requestUrl = requestUrl + "discipline=1&"

      if (this.filter.discipline.net == true)
        requestUrl = requestUrl + "discipline=2&"

      if (this.filter.discipline.java == true)
        requestUrl = requestUrl + "discipline=3&"

      if (this.filter.discipline.testing == true)
        requestUrl = requestUrl + "discipline=4"
    }

    return this.http.get(requestUrl, { responseType: 'text'});
  }
}
