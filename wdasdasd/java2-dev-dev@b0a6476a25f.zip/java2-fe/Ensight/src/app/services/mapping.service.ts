import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MappingService {

  difficulty : Map<number, String> = new Map<number, String>();
  type : Map<number, String> = new Map<number, String>();
  discipline: Map< String, String> = new Map<String, String>();

  constructor() { 
    this.difficulty.set(1,"easy");
    this.difficulty.set(2,"medium");
    this.difficulty.set(3,"hard");

    this.type.set(1,"multiple choice");
    this.type.set(2,"logic answer");
    this.type.set(3,"code snippet");

    this.discipline.set('AM', 'Application Management');
    this.discipline.set('NET', '.NET');
    this.discipline.set('JAVA', 'Java');
    this.discipline.set('TESTING', 'Testing');
  }
}
