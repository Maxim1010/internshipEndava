import { TestBed, inject } from '@angular/core/testing';

import { CandidateAndHisExamService } from './candidate-and-his-exam.service';

describe('CandidateAndHisExamService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CandidateAndHisExamService]
    });
  });

  it('should be created', inject([CandidateAndHisExamService], (service: CandidateAndHisExamService) => {
    expect(service).toBeTruthy();
  }));
});
