import { ReadExcelDirective } from './read-excel.directive';

describe('ReadExcelDirective', () => {
  it('should create an instance', (ElementRef) => {
    const directive = new ReadExcelDirective(ElementRef);
    expect(directive).toBeTruthy();
  });
});
