import { Directive, HostListener, ElementRef, Input } from '@angular/core';
import * as XLSX from 'xlsx';
import { Candidate } from '../models/Candidate';
import { WrapperCandidateListImport } from '../models/WrapperCandidateListImport';
import { CandidatesImportService } from '../services/candidates-import.service';
import { ErrorsLogXSL } from '../models/ErrorsLogXSL';

@Directive({
  selector: '[appReadExcel]'
})
export class ReadExcelDirective {

  public candidateImportService: CandidatesImportService;
  candidates: WrapperCandidateListImport;
  errorLog: ErrorsLogXSL;
  currentCandidate: Candidate;
  readed : boolean = false;

  constructor(public input: ElementRef) {
  }

  fileContent: any;
  name: any;

  @HostListener('change', ['$event'])
  private changeListener(event: Event): void {
    this.read(event.target);
  }

  private read(input: any) {
    this.readed = true;
    var file: File = input.files[0];
    var fileTypes = ['xls', 'xlsx'];
    if (input.files && input.files[0]) {
      var extension = input.files[0].name.split('.').pop().toLowerCase(),
        isSuccess = fileTypes.indexOf(extension) > -1;
      if (isSuccess) {
        var myReader: FileReader = new FileReader();
        myReader.onloadend = () => {
          this.fileContent = myReader.result;
          this.parseExcel();
        }
        myReader.readAsBinaryString(file);
      }
      else {
        this.fileContent = null;
        alert("Bad extension");
      }
    }
  }

  public parseExcel() {

    const wb: XLSX.WorkBook = XLSX.read(this.fileContent, { type: 'binary' });

    this.errorLog = new ErrorsLogXSL();
    const wsname: string = wb.SheetNames[0];
    const ws: XLSX.WorkSheet = wb.Sheets[wsname];

    var data = <any>(XLSX.utils.sheet_to_json(ws, { header: 1 }));

    for (let i = 1; i < data.length; i++) {
      for (let j = 0; j < data[i].length + 1; j++) {
        if ((data[i][j] == null) && (j<10)) {
          console.log(data[i].length);
          this.errorLog.errorList.push("Null value at line " + (i + 1) + ", column " + (j + 1) + ";");
        }
      }
    }

    if (this.errorLog.errorList.length == 0) {
      this.candidates = new WrapperCandidateListImport();
      for (let i = 1; i < data.length; i++) {
        this.currentCandidate = new Candidate();

        this.currentCandidate.forename = data[i][0];
        this.currentCandidate.surname = data[i][1];
        this.currentCandidate.university = data[i][2];
        this.currentCandidate.faculty = data[i][3];
        this.currentCandidate.studyYear = data[i][4];
        this.currentCandidate.discipline = data[i][5];
        this.currentCandidate.email = data[i][6];
        this.currentCandidate.phone = '0' + data[i][7];
        this.currentCandidate.internalCandidate = data[i][8];
        this.currentCandidate.alumniCandidate = data[i][9];
        this.currentCandidate.password = "default password";
        this.candidates.candidates[i - 1] = this.currentCandidate;
      }
      // console.log(this.candidates);
    }
    return this.errorLog;
  }

  public getAllCandidatesFromXSL() {
    return this.candidates;
  }
}
