import { Component, OnInit, Output, HostListener, Injectable } from '@angular/core';
import { TestService } from '../services/test.service';
import { AppComponent } from '../app.component';
import { ActivatedRoute, Route, Router, CanDeactivate, CanActivate } from '../../../node_modules/@angular/router';
import { Question } from '../models/Question';
import { TakeTestProgressTimeHeaderComponent } from '../take-test-progress-time-header/take-test-progress-time-header.component';
import { Observable } from 'rxjs';

import { AnswerFromCandidate } from '../models/AnswerFromCandidate';
import { CandidateTestQuestionsCompositeKey } from '../models/CandidateTestQuestionCompositeKey';
import { CandidateAnswersService } from '../services/candidate-answers.service';
import { ExamService } from '../services/exam.service';
import { PlatformLocation } from '@angular/common';
@Component({
  selector: 'app-take-test-page',
  templateUrl: './take-test-page.component.html',
  styleUrls: ['./take-test-page.component.css']
})
@Injectable({ providedIn: 'root' })
export class TakeTestPageComponent implements OnInit, CanActivate {

  questions_done; button; hideElement_next = false; hideElement_submit = true;
  @Output() public numberOfQuestions: number;

  testId: number;
  candidateId: number;
  questionList: Question[] = [];
  currentQuestion: Question = new Question();
  isStartedTest: boolean = false;

  answerFromCandidate: AnswerFromCandidate = new AnswerFromCandidate();
  ctqCompositeKey: CandidateTestQuestionsCompositeKey = new CandidateTestQuestionsCompositeKey();

  constructor(private candidateAnswersService: CandidateAnswersService,
    private testService: TestService,
    private examService: ExamService,
    private route: ActivatedRoute,
    private router: Router,
    private header: TakeTestProgressTimeHeaderComponent,
    private location: PlatformLocation) {
    this.testService.backPageActioned = false;

    location.onPopState(
      () => {
        this.testService.backPageActioned = true;
      }
    );
  }

  // @HostListener allows us to also guard against browser refresh, close, etc.
  @HostListener('window:beforeunload')
  canDeactivate(): Observable<boolean> | boolean {
    console.log('trying to close');
    this.examService.endTest(this.testId, this.candidateId).subscribe();
    return false;
  }

  canActivate() {
    if (this.testService.backPageActioned == true) {
      this.testService.backPageActioned = false;
      return false;
    } else {
      this.testService.backPageActioned = false;
      return true;
    }
  }

  ngOnInit() {
    this.testService.backPageActioned = false;
    this.header.initial_setup_progress_bar();
    this.testId = parseInt(this.route.snapshot.paramMap.get('id'));
    this.candidateId = parseInt(this.route.snapshot.paramMap.get('candidateId'));
    this.testService.getQuestionsByTestId(this.testId)
      .subscribe(res => {
        this.questionList = res as Question[];
        console.log(res);
        this.currentQuestion = this.questionList[0];

        this.ctqCompositeKey.testId = this.testId;
        this.ctqCompositeKey.candidateId = this.candidateId;
        this.ctqCompositeKey.questionId = this.currentQuestion.id;

      });
  }


  increment_progress() {
    this.submitCurrentAnswer();
    this.header.increment();
    this.questions_done = document.getElementById('progress-text');
    this.questions_done.innerHTML = this.header.textToShow;

    this.currentQuestion = this.questionList[this.header.questNo - 1];

    if (this.header.questNo == this.header.noQuestions)
      this.submit_button_appears();
  }

  submitCurrentAnswer() {
    this.ctqCompositeKey.questionId = this.currentQuestion.id;
    this.answerFromCandidate.id = this.ctqCompositeKey;
    this.answerFromCandidate.answerText = this.candidateAnswersService.candidateAnswerText;
    console.log(" answer to submit: " + this.answerFromCandidate.answerText + "*" +
      this.answerFromCandidate.id.testId + "*" + this.answerFromCandidate.isCorrect);
    this.candidateAnswersService.submitAnswerFromCandidate(this.answerFromCandidate)
      .subscribe(res => { console.log(res); });

  }

  submit_button_appears() {
    this.button = document.getElementById("button_next");
    this.hideElement_next = true;
    this.hideElement_submit = false;
  }

  submit_test() {
    this.increment_progress();
    this.examService.endTest(this.testId,this.candidateId).subscribe(res=>
      {
        this.router.navigateByUrl('take_test/end/' + this.testId);
      }
    );
    
  }

}
