import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TakeTestPageComponent } from './take-test-page.component';

describe('TakeTestPageComponent', () => {
  let component: TakeTestPageComponent;
  let fixture: ComponentFixture<TakeTestPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TakeTestPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TakeTestPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
