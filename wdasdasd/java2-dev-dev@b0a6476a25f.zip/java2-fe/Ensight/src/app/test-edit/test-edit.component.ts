import { Component, OnInit, Input, Injectable } from '@angular/core';
import { TestService } from '../services/test.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Test } from '../models/Test';
import { GeneralSettingsService } from '../services/general-settings.service';

@Component({
  selector: 'app-test-edit',
  templateUrl: './test-edit.component.html',
  styleUrls: ['./test-edit.component.css']
})
export class TestEditComponent implements OnInit {
  questionList: any;
  test: Test = new Test();
  testId: number;
  isTestEdited: boolean = false;

  constructor(
     private testService:TestService,
     private route: ActivatedRoute, 
     private router: Router) { }

  ngOnInit() {
    this.hideMyBanner();

    this.testId = parseInt(this.route.snapshot.paramMap.get('id'));
    this.testService.getById(this.testId).subscribe(response => this.test = response as Test);
    this.testService.getQuestionsByTestId(this.testId).subscribe(response =>{ this.questionList = response; console.log(response)});
  }

  hideMyBanner(){
    setTimeout(() => {
      this.isTestEdited = false;
    }, 3000);
}
  hideBannerOnClick(){
    this.isTestEdited = false;
  }

  patchTestTitle(){
    this.testService.update(this.test).subscribe(response=> {
      console.log(response);
      this.isTestEdited = true;
      this.hideMyBanner();
    });
  }

  delete(){
    this.openDeleteModal();
  }

  openDeleteModal() {
    document.getElementById('deleteModal').style.display = "block";
  }

  closeDeleteModal() {
    document.getElementById('deleteModal').style.display = "none";
  }

  deleteRequest(){
    this.testService.deleteRequest(this.testId).subscribe(response=>{console.log(response);
      this.goOnTestsPage();
    });
    
  }

  goOnTestsPage() {
    this.router.navigateByUrl("/tests");
  }
}
