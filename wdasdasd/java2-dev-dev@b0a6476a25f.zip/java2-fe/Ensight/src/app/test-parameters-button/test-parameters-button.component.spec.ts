import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestParametersButtonComponent } from './test-parameters-button.component';

describe('TestParametersButtonComponent', () => {
  let component: TestParametersButtonComponent;
  let fixture: ComponentFixture<TestParametersButtonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestParametersButtonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestParametersButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
