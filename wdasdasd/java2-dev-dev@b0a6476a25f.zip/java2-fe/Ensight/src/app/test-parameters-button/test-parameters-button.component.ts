import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-test-parameters-button',
  templateUrl: './test-parameters-button.component.html',
  styleUrls: ['./test-parameters-button.component.css']
})
export class TestParametersButtonComponent implements OnInit {

  constructor(private router : Router) { }


  ngOnInit() {
  }

  goOnTestParamsPage(){
    this.router.navigateByUrl("test/parameters");
  }

}
