import { Component, OnInit, Injectable } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-multiple-choice',
  templateUrl: './multiple-choice.component.html',
  styleUrls: ['./multiple-choice.component.css']
})
@Injectable({
  providedIn: 'root'
})
export class MultipleChoiceComponent implements OnInit {

  questionFormMultipleChoice: FormGroup;

  constructor() { 
  }



  ngOnInit() {
  }

}
