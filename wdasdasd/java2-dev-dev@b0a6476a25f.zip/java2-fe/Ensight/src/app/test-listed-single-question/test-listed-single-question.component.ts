import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { MappingService } from '../services/mapping.service';

@Component({
  selector: 'app-test-listed-single-question',
  templateUrl: './test-listed-single-question.component.html',
  styleUrls: ['./test-listed-single-question.component.css']
})
export class TestListedSingleQuestionComponent implements OnInit {

  @Input() question;
  @Input() index;

  constructor(private router: Router, public map: MappingService) { }

  ngOnInit() {
  }

  checkIfRowIsEven(){
    return this.index % 2 === 0 
  }

  goToQuestionOverviewPage(){
    this.router.navigateByUrl("question/"+ this.question.id);
  }

}
