import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestListedSingleQuestionComponent } from './test-listed-single-question.component';

describe('TestListedSingleQuestionComponent', () => {
  let component: TestListedSingleQuestionComponent;
  let fixture: ComponentFixture<TestListedSingleQuestionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestListedSingleQuestionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestListedSingleQuestionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
