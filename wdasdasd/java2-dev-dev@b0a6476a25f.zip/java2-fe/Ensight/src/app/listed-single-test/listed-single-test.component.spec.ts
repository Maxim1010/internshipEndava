import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListedSingleTestComponent } from './listed-single-test.component';

describe('ListedSingleTestComponent', () => {
  let component: ListedSingleTestComponent;
  let fixture: ComponentFixture<ListedSingleTestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListedSingleTestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListedSingleTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
