import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { TestService } from '../services/test.service';
import { AppComponent } from '../app.component';
import { Test } from '../models/Test';

@Component({
  selector: 'app-listed-single-test',
  templateUrl: './listed-single-test.component.html',
  styleUrls: ['./listed-single-test.component.css']
})
export class ListedSingleTestComponent implements OnInit {

  constructor(private service: TestService, private router: Router) { }

  @Input() test;
  @Input() index;
  @Input() markedForDelete: boolean = false;
  copyLinkValue: string = 'copy link';
  isLinkCopied = false;

  @Output() testId = new EventEmitter<any>();

  @Output() isMarked = new EventEmitter<boolean>();
  @Output() mustUpdateTestList = new EventEmitter<boolean>();
  @Output() deleteTest = new EventEmitter<number>();

  ngOnInit() {
  }

  checkIfRowIsEven() {
    return this.index % 2 === 0
  }

  deleteRequest() {
    this.deleteTest.emit(this.test.id);
    console.log("single test selected: true")
  }

  goOnOverviewPage() {
    this.router.navigateByUrl("tests/" + this.test.id + "/edit");
  }

  goOnEditPage() {
    this.router.navigateByUrl("tests/" + this.test.id + "/edit");
  }

  toggleCheckForDelete() {
    this.markedForDelete = !this.markedForDelete;
    this.test.markedToDelete = this.markedForDelete;
    this.isMarked.emit(this.test.markedForDelete);
  }

  markAll(marked: boolean) {
    this.markedForDelete = marked;
    this.test.markedToDelete = marked;
    this.isMarked.emit(this.test.markedForDelete);
  }



  copyLink() {
    this.copyTestLink(AppComponent.testUrl + '/take_test/start/' + this.test.id);
    this.isLinkCopied = true;
    this.copyLinkValue = 'link copied';
    this.service.testId = this.test.id;
    this.service.tests.push(this.test);

    setTimeout(() => {
    this.copyLinkValue = 'copy link';
      this.isLinkCopied = false;

    }, 3000);

    console.log(this.isLinkCopied + ' is copied');
    console.log('number of Questions ' + this.service.test.numberOfQuestions);
    console.log('this test id ' + this.test.id + ' and serice test id : ' + this.service.test.id);
  }

  copyTestLink(val: string) {
    let selBox = document.createElement('textarea');
    selBox.style.position = 'fixed';
    selBox.style.left = '0';
    selBox.style.top = '0';
    selBox.style.opacity = '0';
    selBox.value = val;
    document.body.appendChild(selBox);
    selBox.focus();
    selBox.select();
    document.execCommand('copy');
    document.body.removeChild(selBox);
  }

}