import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SideFiltersTestsComponent } from './side-filters-tests.component';

describe('SideFiltersTestsComponent', () => {
  let component: SideFiltersTestsComponent;
  let fixture: ComponentFixture<SideFiltersTestsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SideFiltersTestsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SideFiltersTestsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
