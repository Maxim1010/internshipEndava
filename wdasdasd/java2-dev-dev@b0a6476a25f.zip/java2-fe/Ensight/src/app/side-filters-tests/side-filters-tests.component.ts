import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { TestService } from '../services/test.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-side-filters-tests',
  templateUrl: './side-filters-tests.component.html',
  styleUrls: ['./side-filters-tests.component.css']
})
export class SideFiltersTestsComponent implements OnInit {


  constructor(private testService: TestService) { }
    filter= this.testService.filter;

    @Output() mustUpdateTestList = new EventEmitter<boolean>();
    @Output() totalTests = new EventEmitter<number>();

    totalTestFromApi: number;


  	onFormSubmit(form: NgForm) {
      this.testService.filter=this.filter;
      this.filter.discipline.setDiscipline(form);
      this.testService.getNumberOfTestByFilter().subscribe(res => {
          this.totalTestFromApi = parseInt(res);
          this.totalTests.emit(parseInt(res));
          this.mustUpdateTestList.emit(true);
          this.testService.maxPageNumber = Math.floor( (this.totalTestFromApi / 15) + 1);
          console.log('max page number ' + this.testService.maxPageNumber);
      });

  }
  

  ngOnInit() {
    
    this.testService.filter=this.filter;
    this.testService.getNumberOfTestByFilter().subscribe(res => {
      this.totalTestFromApi = parseInt(res);
      this.totalTests.emit(this.totalTestFromApi);
      this.testService.maxPageNumber = Math.floor( (this.totalTestFromApi / 15) + 1);
      console.log('max page number ' + this.testService.maxPageNumber);
   });

    

  }



}
