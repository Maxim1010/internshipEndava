import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-side-filters-candidates',
  templateUrl: './side-filters-candidates.component.html',
  styleUrls: ['./side-filters-candidates.component.css']
})
export class SideFiltersCandidatesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
