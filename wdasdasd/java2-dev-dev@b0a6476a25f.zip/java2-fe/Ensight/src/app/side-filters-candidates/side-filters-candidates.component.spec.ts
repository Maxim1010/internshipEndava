import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SideFiltersCandidatesComponent } from './side-filters-candidates.component';

describe('SideFiltersCandidatesComponent', () => {
  let component: SideFiltersCandidatesComponent;
  let fixture: ComponentFixture<SideFiltersCandidatesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SideFiltersCandidatesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SideFiltersCandidatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
