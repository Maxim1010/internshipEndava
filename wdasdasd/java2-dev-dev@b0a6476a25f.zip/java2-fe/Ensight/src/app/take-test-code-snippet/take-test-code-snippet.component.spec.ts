import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TakeTestCodeSnippetComponent } from './take-test-code-snippet.component';

describe('TakeTestCodeSnippetComponent', () => {
  let component: TakeTestCodeSnippetComponent;
  let fixture: ComponentFixture<TakeTestCodeSnippetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TakeTestCodeSnippetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TakeTestCodeSnippetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
