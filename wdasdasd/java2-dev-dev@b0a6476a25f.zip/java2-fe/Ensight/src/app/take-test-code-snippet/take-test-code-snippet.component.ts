import { Component, OnInit, Input } from '@angular/core';
import { TakeTestProgressTimeHeaderComponent } from '../take-test-progress-time-header/take-test-progress-time-header.component'; 
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Question } from '../models/Question';
import { CandidateAnswersService } from '../services/candidate-answers.service';


@Component({
  selector: 'app-take-test-code-snippet',
  templateUrl: './take-test-code-snippet.component.html',
  styleUrls: ['./take-test-code-snippet.component.css']
})

export class TakeTestCodeSnippetComponent implements OnInit{

  @Input()
  question : Question;

  constructor(public candidateAnswerService: CandidateAnswersService, private router: Router) { }

  ngOnInit() {
    this.candidateAnswerService.candidateAnswerText=null;
  }

  goToOpenAnswerPage(){
    this.router.navigateByUrl('take_test/open_answer');
  }

  goToSummaryPage(){
    this.router.navigateByUrl('take_test/end');
  }

}
