import { Component, OnInit, Input, ViewChild, AfterViewInit, AfterContentInit } from '@angular/core';
import { Router } from '@angular/router';
import { CandidateAndHisExamService } from '../services/candidate-and-his-exam.service';
import { HeaderComponent } from '../general/header/header.component';
import { Campaign } from '../models/Campaign';
import { Candidate } from '../models/Candidate';
import { CandidateAndHisExam } from '../models/CandidateAndHisExam';
import { CampaignService } from '../services/campaign.service';
import { ListedCandidatesComponent } from '../listed-candidates/listed-candidates.component';
import { EmailService } from '../services/email.service';
import { CandidateChecked } from '../models/CandidateChecked';
import { WrapperCandidateListImport } from '../models/WrapperCandidateListImport';
import { CandidatesImportService } from '../services/candidates-import.service';
import { ReadExcelDirective } from '../directives/read-excel.directive';

@Component({
  selector: 'app-candidates-list-page',
  templateUrl: './candidates-list-page.component.html',
  styleUrls: ['./candidates-list-page.component.css'],
})
export class CandidatesListPageComponent implements OnInit {
  candidatesAndTheirExams: any;
  currentCampaign: number;
  thereAreCandidates: boolean = false;
  candidateFromChildChecked = new CandidateAndHisExam();
  @ViewChild(HeaderComponent) headerChild: HeaderComponent;
  @ViewChild(ListedCandidatesComponent) listedCandidates: ListedCandidatesComponent;

  listOfCheckedCandidates = [];
  isChildInitialized;
  candidateChecked: CandidateChecked = new CandidateChecked();
  candidates: WrapperCandidateListImport;
 
  title_errors: string;
  text_errors: string;
  hideElement_importCandidates: boolean;
  hideElement_errors: boolean;

  sendEmailAttempts: number = 0;
  isEmailSent: boolean = false;

  constructor(private campaignService: CampaignService,
    private router: Router,
    private candidateAndHisExamService: CandidateAndHisExamService,
    private emailService: EmailService,

    private candidateImportService: CandidatesImportService) {}


  @ViewChild(ReadExcelDirective) readExcelDirective: ReadExcelDirective;


  ngOnInit() {
    this.hideElement_importCandidates = true;
    this.hideElement_errors = false;
    this.campaignService.getLastId().subscribe(
      res => {
        let lastCampaignId: number = res as number;
        this.currentCampaign = lastCampaignId;
        this.candidateAndHisExamService.getAllByCampaignId(lastCampaignId).subscribe(response => {
          this.candidatesAndTheirExams = response;
          this.candidatesAndTheirExams.forEach(element => {
            element.isChecked = false;
          });
          if (this.candidatesAndTheirExams.length > 0) {
            this.thereAreCandidates = true;
          }
          else {
            this.thereAreCandidates = false;
          }
        });
      }
    )

  }


  setIsAllCheckedToFalse() {
    this.listedCandidates.isAllChecked = false;
  }

  receiveFromMiddleChild($event) {
    console.log('parent: from middle child ' + $event);

    //this.candidateFromChildChecked = $event;
    this.candidateChecked = $event;
    console.log('is checked ' + this.candidateChecked.isChecked);

    if (this.candidateChecked.isChecked == true) {

      if (!this.listOfCheckedCandidates.includes(this.candidateChecked.candidateAndExam.candidate)) {
        console.log('nu exista numele in lista')
        this.listOfCheckedCandidates.push(this.candidateChecked.candidateAndExam.candidate);
      } else {
        console.log(' exista numele in lista')
      }
    } else {
      if (this.listOfCheckedCandidates.includes(this.candidateChecked.candidateAndExam.candidate)) {
        let index = this.listOfCheckedCandidates.findIndex(candidate => 
          candidate == this.candidateChecked.candidateAndExam.candidate
        );
        console.log('index of the name is: ' + index)
         this.listOfCheckedCandidates.splice(index, 1);
      }
    }

  }


  goOnEditPage() {
    this.router.navigateByUrl("/candidates/edit");
  }

  openErrorsModal() {
    document.getElementById('deleteModal').style.display = "block";
  }

  closeErrorsModal() {
    document.getElementById('deleteModal').style.display = "none";
    this.readExcelDirective.readed = false;
  }

  hideBannerAfterSeconds(timeout) {
    var banner = document.getElementById('candidate-banner');
    if (banner) {
      setTimeout(() => {
        banner.style.display = "none";
      }, timeout);
    }
  }

  hideBanner() {
    document.getElementById('candidate-banner').style.display = "none";
  }

  showBanner() {
    document.getElementById('candidate-banner').style.display = "block";
    this.hideBannerAfterSeconds(3000);
  }

  updateCandidatesList(campaignId: number) {
    this.currentCampaign = campaignId;
    this.candidateAndHisExamService.getAllByCampaignId(campaignId).subscribe(response => {
      this.candidatesAndTheirExams = response as CandidateAndHisExam[];
      if (this.candidatesAndTheirExams.length > 0) {
        this.thereAreCandidates = true;

        let candidate: Candidate = this.candidatesAndTheirExams[0].candidate as Candidate;
      }
      else {
        this.thereAreCandidates = false;
        this.listedCandidates.isAllChecked = false;
      }
      //this.listedCandidates.isAllChecked = false;
      setTimeout(() => {
        this.setIsAllCheckedToFalse();
      }, 100);
      this.listOfCheckedCandidates = [];

    });
  }

  sendEmailToCandidates() {
    this.sendEmailAttempts++;

    if (this.sendEmailAttempts > 0 && this.sendEmailAttempts < 2) {
      this.emailService.sendEmail(this.listOfCheckedCandidates).subscribe(res => {
        console.log('attempts of send: ' + res);
        console.log('response from email service called in candidates page: ' + res);
        this.sendEmailAttempts = 0;
        this.updateCandidatesList(this.currentCampaign);
        this.isEmailSent = true;
        this.hideEmailBannerAfter(3000);
      });
    }
  }
  hideEmailBannerAfter(seconds){
    setTimeout(() => {
      this.isEmailSent = false;
    }, seconds);
  }

  hideEmailBanner(){
    this.isEmailSent = false;
      }


  showErrors() {
    if (this.readExcelDirective.readed == true) {
      this.title_errors = "You have the following errors in the Excel you've just uploaded:";
      if (this.readExcelDirective.errorLog.errorList.length === 0) {
        this.text_errors = "There are no errors in the Excel file. Refresh the page and you'll see the imported candidates";
        console.log(this.readExcelDirective.getAllCandidatesFromXSL());
        this.candidateImportService.submitImportedCandidates(this.readExcelDirective.getAllCandidatesFromXSL(),
          this.currentCampaign).subscribe(response => console.log(response));
      }
      else {
        this.text_errors = this.readExcelDirective.errorLog.errorList[0] +  "\n";
        if(this.readExcelDirective.errorLog.errorList.length>1)
          this.text_errors = this.text_errors + this.readExcelDirective.errorLog.errorList[1] +  "\n";
        this.text_errors = this.text_errors +  "\n" + "Solve the errors and RE-UPLOAD the file.";
      }
      this.openErrorsModal();
    }
  }
}
