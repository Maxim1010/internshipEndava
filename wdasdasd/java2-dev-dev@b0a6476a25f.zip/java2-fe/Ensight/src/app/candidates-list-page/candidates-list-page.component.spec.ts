import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CandidatesListPageComponent } from './candidates-list-page.component';

describe('CandidatesListPageComponent', () => {
  let component: CandidatesListPageComponent;
  let fixture: ComponentFixture<CandidatesListPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CandidatesListPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CandidatesListPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
