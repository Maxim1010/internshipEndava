import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { Router } from '@angular/router';
import { CampaignService } from '../../services/campaign.service';
import { CandidateAndHisExamService } from '../../services/candidate-and-his-exam.service';
import { Campaign } from '../../models/Campaign';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  campaigns;
  currentCampaign: Campaign = new Campaign();
  @Output() updateCandidatesByCampaign = new EventEmitter<number>(); ;

  constructor(private router: Router, private campaignService: CampaignService,private candidateService: CandidateAndHisExamService) {
  }

  ngOnInit() {
    this.campaignService.getLastId().subscribe(
      res=>{
        let lastCampaignId:number = res as number;
        this.campaignService.getAll().subscribe(response => {
        this.campaigns = response;
        this.campaignService.getById(lastCampaignId).subscribe(res=>{this.currentCampaign = res as Campaign});
    });
  });
  }

  goToQuestionsPage() {
    this.router.navigateByUrl('questions');
  }

  goToTestsPage() {
    this.router.navigateByUrl('tests');
  }

  goToAddCampaignPage() {
    this.router.navigateByUrl('campaign/add');
  }

  goToCandidatesPage() {
    this.router.navigateByUrl('candidates');
  }

  changeCampaign(id){
    this.updateCandidatesByCampaign.emit(id);
    this.campaignService.getById(id).subscribe(res=>{this.currentCampaign = res as Campaign});
  }

}
