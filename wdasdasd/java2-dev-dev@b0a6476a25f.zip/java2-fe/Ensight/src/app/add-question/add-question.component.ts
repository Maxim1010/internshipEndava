import { Component, OnInit, Output, Input, Injectable } from '@angular/core';
import { Question } from '../models/Question';
import { Router } from '@angular/router';
import { Answer } from '../models/Answer';
import { QuestionListPageComponent } from '../question-list-page/question-list-page.component';
import { QuestionsService } from '../services/questions.service';

@Component({
  selector: 'app-add-question',
  templateUrl: './add-question.component.html',
  styleUrls: ['./add-question.component.css']
})
export class AddQuestionComponent implements OnInit {
  
  @Output() typeFromOut:any = "1";
  @Input() questionText;
  @Input() question : Question = new Question();
  @Input() answer: Answer = new Answer();
  @Input() answer1: Answer = new Answer();
  @Input() answer2: Answer = new Answer();
  @Input() answer3: Answer = new Answer();
  @Input() answer4: Answer = new Answer();
  @Input() correctAnswer = "answer1";

  isBannerVisible: boolean;

  questionId: any;

  answersList: Answer[] = [];

  constructor( 
     private questionService : QuestionsService,
     private router: Router,
     private questionListService: QuestionListPageComponent,
    ) {

    this.question.type = 1;
    this.question.difficulty = 1;
    this.question.noOfPoints = 1;
    this.question.discipline = "AM";
  }

    ngOnInit(){
      this.questionService.currentBanner.subscribe(banner => this.isBannerVisible = banner)
    }

    submitQuestionSingle(){
      this.question.type=this.typeFromOut;
      this.questionService.createQusetion(this.question).subscribe(res=> {
        this.answer.questionId = parseInt(res.toString());
        this.questionService.createAnswer(this.answer);
        this.questionService.changeAddQuestionBannerVisibility(true);
      } );

      this.goToQuestionsPage();
    }

    submitQuestionMultiple(){
      this.question.type=this.typeFromOut;
      this.createAnswerList();
      this.question.correctAnswerText = this.answersList[0].answerText;

      this.questionService.createQusetion(this.question).subscribe(res =>{

          this.answer1.questionId = parseInt(res.toString());
          this.answer2.questionId = parseInt(res.toString());
          this.answer3.questionId = parseInt(res.toString());
          this.answer4.questionId = parseInt(res.toString());
          this.questionService.createAnswerMultiple(this.answersList).subscribe();
          this.questionService.changeAddQuestionBannerVisibility(true);

        })
        
        this.goToQuestionsPage();

    }
  
    getTypeOfQuestion(typeOfAnswer){
      this.typeFromOut = typeOfAnswer;
    }
  
    getDifficulty(difficulty){
      this.question.difficulty = difficulty;
    }
  
    getNoOfPoints(noOfPoints){
      this.question.noOfPoints = noOfPoints;
    }
  
    getDiscipline(discipline){
      this.question.discipline = discipline;
    }
    goToQuestionsPage(){
      this.router.navigateByUrl("questions");
    }

    createAnswerList(){
      if(this.correctAnswer == "answer1"){
        this.answersList[0] = this.answer1;
        this.answersList[1] = this.answer2;
        this.answersList[2] = this.answer3;
        this.answersList[3] = this.answer4;
      }
      if(this.correctAnswer == "answer2"){
        this.answersList[0] = this.answer2;
        this.answersList[1] = this.answer1;
        this.answersList[2] = this.answer3;
        this.answersList[3] = this.answer4;
      }
      if(this.correctAnswer == "answer3"){
        this.answersList[0] = this.answer3;
        this.answersList[1] = this.answer1;
        this.answersList[2] = this.answer2;
        this.answersList[3] = this.answer4;
      }
      if(this.correctAnswer == "answer4"){
        this.answersList[0] = this.answer4;
        this.answersList[1] = this.answer1;
        this.answersList[2] = this.answer2;
        this.answersList[3] = this.answer3;
      }  
    }

    cancelAddQuestion(){
      this.goToQuestionsPage();
    }
}

