import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestListedQuestionsComponent } from './test-listed-questions.component';

describe('TestListedQuestionsComponent', () => {
  let component: TestListedQuestionsComponent;
  let fixture: ComponentFixture<TestListedQuestionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestListedQuestionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestListedQuestionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
