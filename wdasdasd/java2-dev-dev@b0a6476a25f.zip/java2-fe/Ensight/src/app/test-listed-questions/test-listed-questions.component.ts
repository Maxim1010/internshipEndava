import { Component, OnInit, Input} from '@angular/core';

@Component({
  selector: 'app-test-listed-questions',
  templateUrl: './test-listed-questions.component.html',
  styleUrls: ['./test-listed-questions.component.css']
})
export class TestListedQuestionsComponent implements OnInit {

  @Input() questionList: any;

  constructor() { }

  ngOnInit() {
  }

}
