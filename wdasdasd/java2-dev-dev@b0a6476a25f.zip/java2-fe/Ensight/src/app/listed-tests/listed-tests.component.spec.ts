import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListedTestsComponent } from './listed-tests.component';

describe('ListedTestsComponent', () => {
  let component: ListedTestsComponent;
  let fixture: ComponentFixture<ListedTestsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListedTestsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListedTestsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
