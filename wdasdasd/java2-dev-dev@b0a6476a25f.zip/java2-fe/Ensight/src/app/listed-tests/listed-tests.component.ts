import { Component, OnInit, ViewChildren, QueryList, Input, EventEmitter, Output } from '@angular/core';
import { ListedSingleTestComponent } from '../listed-single-test/listed-single-test.component';
import { TestService } from '../services/test.service';
import { TestsListPageComponent } from '../tests-list-page/tests-list-page.component';

@Component({
  selector: 'app-listed-tests',
  templateUrl: './listed-tests.component.html',
  styleUrls: ['./listed-tests.component.css']
})
export class ListedTestsComponent implements OnInit {

  constructor(private testService: TestService, private testPage: TestsListPageComponent) { }

  @ViewChildren(ListedSingleTestComponent) children: QueryList<ListedSingleTestComponent>;

  @Input() testList: any;
  @Input() eventTotalTests: number;
  pageNumber: number = 1;
  maxPageNumber: number = 1;

  allMarked: boolean = false;

  @Output() mustUpdateTestList = new EventEmitter<boolean>();
  @Output() deleteTest = new EventEmitter<number>();

  ngOnInit() {
      this.testService.currentAllChecked.subscribe(isChecked => {
        this.allMarked = isChecked;
      });

    if(!(this.maxPageNumber / 15 == Math.floor(this.maxPageNumber / 15)))
      this.maxPageNumber = Math.floor(this.eventTotalTests / 15) + 1;
    else
      this.maxPageNumber = Math.floor(this.eventTotalTests / 15);

      
  }

  toggleAllForDelete() {

    this.allMarked = !this.allMarked;
    this.testList.forEach(element => {
      element.markedToDelete = this.allMarked;
    });
    this.children.forEach(child => {
      child.markAll(this.allMarked);
    });
  }

  deleteRequest(id: number){ 
    this.deleteTest.emit(id);
    console.log("single q: ok");
  }

  update(status:boolean){
    if(status==true)
    {this.mustUpdateTestList.emit(true);
    }
    
  }

  onDeselect(event: boolean) {
    if (!event)
      this.allMarked = false;
  }


  nameDesc() {

    if (document.getElementById("nameDesc").className == "far fa-caret-square-down") {

    }
    else {
      this.disableAllSortButtons();
      document.getElementById("nameDesc").className = "far fa-caret-square-down";
      this.testService.sortField = 1;
      this.testService.order = "desc";
      this.testService.getFilteredAndSortedTests().subscribe(res => {
        this.testList = res;
        this.testList.forEach(element => {
          element.markedToDelete = false;
        });
      });
    }
  }

  nameAsc() {

    if (document.getElementById("nameAsc").className == "far fa-caret-square-up") {
    }
    else {
      this.disableAllSortButtons();
      document.getElementById("nameAsc").className = "far fa-caret-square-up";
      this.testService.sortField = 1;
      this.testService.order = "asc";
      this.testService.getFilteredAndSortedTests().subscribe(res => {
        this.testList = res;
        this.testList.forEach(element => {
          element.markedToDelete = false;
        });
      });
    }
  }

  uDateDesc() {

    if (document.getElementById("uDateDesc").className == "far fa-caret-square-down") {
    }
    else {
      this.disableAllSortButtons();
      document.getElementById("uDateDesc").className = "far fa-caret-square-down";
      this.testService.sortField = 3;
      this.testService.order = "desc";
      this.testService.getFilteredAndSortedTests().subscribe(res => {
      this.testList = res;
        this.testList.forEach(element => {
          element.markedToDelete = false;
        });
      });
    }
  }

  uDateAsc() {

    if (document.getElementById("uDateAsc").className == "far fa-caret-square-up") {

    }
    else {
      this.disableAllSortButtons();
      document.getElementById("uDateAsc").className = "far fa-caret-square-up";
      this.testService.sortField = 3;
      this.testService.order = "asc";
      this.testService.getFilteredAndSortedTests().subscribe(res => {
      this.testList = res;
        this.testList.forEach(element => {
          element.markedToDelete = false;
        });
      });
    }
  }

  disableAllSortButtons() {
    document.getElementById("nameAsc").className = "fas fa-caret-square-up";
    document.getElementById("nameDesc").className = "fas fa-caret-square-down";
    document.getElementById("uDateAsc").className = "fas fa-caret-square-up";
    document.getElementById("uDateDesc").className = "fas fa-caret-square-down";

  }

  firstPage(){
    if(this.eventTotalTests / 15 != Math.floor(this.eventTotalTests/15)){
    this.maxPageNumber = Math.floor((this.eventTotalTests/15)+1);
    if(this.pageNumber > 1){
      this.pageNumber = 1;
      this.testService.pageNumber = this.pageNumber;
      this.testPage.update(true);
    }
    console.log('firstPage() -> pgNumber' + this.pageNumber +  ' max page number: ' + this.maxPageNumber);
  }else{
    this.maxPageNumber = Math.floor((this.eventTotalTests/15));
    if(this.pageNumber < this.maxPageNumber){
      this.pageNumber = this.maxPageNumber;
      this.testService.pageNumber = this.pageNumber;
      this.testPage.update(true);
    }
    this.testPage.update(true);
    console.log('lastPage() -> pgNumber' + this.pageNumber +  ' max page number: ' + this.maxPageNumber);
  }
}

  previousPage(){
    if(this.eventTotalTests / 15 != Math.floor(this.eventTotalTests/15)){
    this.maxPageNumber = Math.floor((this.eventTotalTests/15)+1);
    if(this.pageNumber > 1){
      this.pageNumber--;
      this.testService.pageNumber = this.pageNumber;
      this.testPage.update(true);
    }
    console.log('firstPage() -> pgNumber' + this.pageNumber +  ' max page number: ' + this.maxPageNumber);
  }else{
    this.maxPageNumber = Math.floor((this.eventTotalTests/15));
    if(this.pageNumber < this.maxPageNumber){
      this.pageNumber = this.maxPageNumber;
      this.testService.pageNumber = this.pageNumber;
      this.testPage.update(true);
    }
    this.testPage.update(true);
    console.log('lastPage() -> pgNumber' + this.pageNumber +  ' max page number: ' + this.maxPageNumber);
  }
  }

  updatePageByPageNumber($event) {
    if(this.eventTotalTests / 15 != Math.floor(this.eventTotalTests/15)){
    this.maxPageNumber = Math.floor(this.eventTotalTests / 15) + 1;

    if ($event.keyCode == 13) {
      if (this.pageNumber >= 1) {
        if (this.pageNumber <= Math.floor(this.eventTotalTests / 15) + 1) {
          this.testService.pageNumber = this.pageNumber;
          this.testPage.update(true);
        }else{
          this.pageNumber = this.maxPageNumber;
        }
      }else{
        this.pageNumber = this.testService.pageNumber;
      }
    }
    console.log('firstPage() -> pgNumber' + this.pageNumber +  ' max page number: ' + this.maxPageNumber);
  }else{
    this.maxPageNumber = Math.floor((this.eventTotalTests/15));
    if(this.pageNumber < this.maxPageNumber){
      this.pageNumber = this.maxPageNumber;
      this.testService.pageNumber = this.pageNumber;
      this.testPage.update(true);
    }
    this.testPage.update(true);
    console.log('lastPage() -> pgNumber' + this.pageNumber +  ' max page number: ' + this.maxPageNumber);
  }
}

  nextPage(){
    if(this.eventTotalTests / 15 != Math.floor(this.eventTotalTests/15)){
    this.maxPageNumber = Math.floor((this.eventTotalTests/15)+1);
    if(this.pageNumber < this.maxPageNumber){
      this.pageNumber++;
      this.testService.pageNumber = this.pageNumber;
      this.testPage.update(true);
    }
    console.log('firstPage() -> pgNumber' + this.pageNumber +  ' max page number: ' + this.maxPageNumber);
  }else{
    this.maxPageNumber = Math.floor((this.eventTotalTests/15));
    if(this.pageNumber < this.maxPageNumber){
      this.pageNumber = this.maxPageNumber;
      this.testService.pageNumber = this.pageNumber;
      this.testPage.update(true);
    }
    this.testPage.update(true);
    console.log('lastPage() -> pgNumber' + this.pageNumber +  ' max page number: ' + this.maxPageNumber);
  }
  }

  lastPage(){
    if(this.eventTotalTests / 15 != Math.floor(this.eventTotalTests/15)){
    this.maxPageNumber = Math.floor((this.eventTotalTests/15)+1);
    if(this.pageNumber < this.maxPageNumber){
      this.pageNumber = this.maxPageNumber;
      this.testService.pageNumber = this.pageNumber;
      this.testPage.update(true);
    }
    this.testPage.update(true);
    console.log('lastPage() -> pgNumber' + this.pageNumber +  ' max page number: ' + this.maxPageNumber);
  }else{
    this.maxPageNumber = Math.floor((this.eventTotalTests/15));
    if(this.pageNumber < this.maxPageNumber){
      this.pageNumber = this.maxPageNumber;
      this.testService.pageNumber = this.pageNumber;
      this.testPage.update(true);
    }
    this.testPage.update(true);
    console.log('lastPage() -> pgNumber' + this.pageNumber +  ' max page number: ' + this.maxPageNumber);
  }
  }

  showEvent(){
    console.log(this.eventTotalTests);
  }
}
