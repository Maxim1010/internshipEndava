import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-take-test-header',
  templateUrl: './take-test-header.component.html',
  styleUrls: ['./take-test-header.component.css']
})
export class TakeTestHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
