import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TakeTestHeaderComponent } from './take-test-header.component';

describe('TakeTestHeaderComponent', () => {
  let component: TakeTestHeaderComponent;
  let fixture: ComponentFixture<TakeTestHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TakeTestHeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TakeTestHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
