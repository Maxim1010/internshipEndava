import { Component, OnInit, Input, Injectable, AfterViewInit, ViewChild } from '@angular/core';
import { Question } from '../models/Question';
import { Router } from '@angular/router';
import { AddQuestionComponent } from '../add-question/add-question.component';
import { QuestionsService } from '../services/questions.service';
import { ListedQuestionsComponent } from '../listed-questions/listed-questions.component';

@Component({
  selector: 'app-question-list-page',
  templateUrl: './question-list-page.component.html',
  styleUrls: ['./question-list-page.component.css']
})
@Injectable({
  providedIn:'root'
})
export class QuestionListPageComponent implements OnInit{

  @Input() questionList: any;
  @Input() pageNumber: number;

  @ViewChild(ListedQuestionsComponent) listedQuestionsChild: ListedQuestionsComponent;

  maxPageNumber: number;
  questionToBeDeleted: number = -1;
  multipleDeleteStatus: boolean = false;
  isQuestionCreated;
  isBannerVisible: boolean;
  isEditBannerVisible: boolean;
  isQuestionDeleted: boolean;
  allMarked:boolean;

  constructor(private router: Router, private questionService: QuestionsService) {
    
  }

  ngOnInit() {
    this.hideMyBanner();
    this.questionService.currentAfterDeleteCheck.subscribe(checked =>{ this.allMarked = checked;})
    this.questionService.currentBanner.subscribe(banner => this.isBannerVisible = banner);
    this.questionService.currentEditBanner.subscribe(banner => this.isEditBannerVisible = banner);

    this.questionService.getFilteredAndSortedQuestions().subscribe(res => {
      this.questionList = res;
      this.questionList.forEach(element => {
        element.markedToDelete = false;
      });
    });
    this.pageNumber = this.questionService.pageNumber;
    this.isQuestionCreated = this.questionService.isQuestionCreated();
    console.log(this.questionService.isCreated + ' is created');
  }

  hideMyBanner(){
      setTimeout(() => {
        this.isQuestionDeleted = false;
        console.log('seconds before invisible');
      }, 3000);
  }

  delete(id: number) {
    this.multipleDeleteStatus = false;
    this.questionToBeDeleted = id;
    this.openDeleteModal();
  }

  deleteRequest() {
    if (this.multipleDeleteStatus == false) {
      if (this.questionToBeDeleted != -1) {
        this.update(true);
        this.questionService.deleteRequest(this.questionToBeDeleted).subscribe(res => {
          console.log("deleted question with id:" + this.questionToBeDeleted);
          //this.listedQuestionsChild.allMarked = false;
          this.update(true);
          
          //to dooooooooooooooooooooooooooooo
          this.questionService.changeAfterDeleteCheckValue(false);
          this.questionService.currentAfterDeleteCheck.subscribe(isChecked => {
            this.allMarked = isChecked;
          });
          this.isQuestionDeleted = true;
          this.hideMyBanner();
        });
      }
      this.questionToBeDeleted = -1;
      this.closeDeleteModal();
    }
    else {
      
        this.questionService.changeAfterDeleteCheckValue(false);
          this.questionService.currentAfterDeleteCheck.subscribe(isChecked => {
            this.allMarked = isChecked;
          });
      
      this.multipleDeleteRequest();
      this.multipleDeleteStatus = false;
      this.closeDeleteModal();
    }
    this.update(true);
  }

  multipleDelete() {
    this.multipleDeleteStatus = true;
    this.openDeleteModal();
  }

  multipleDeleteRequest() {
    let ids: Array<number> = [];
    for (let question of this.questionList) {
      if (question.markedToDelete == true) {
        ids.push(question.id);
        console.log(question.id);
      }
    }
    if (ids.length > 0) {
      this.questionService.multipleDeleteRequest(ids).subscribe(res => {
        console.log(res);
        this.update(true);
        if(res == 0)
        this.isQuestionDeleted = true;
        this.hideMyBanner();
      });
    }

  }

  update(status: boolean) {
    if (status == true)
      this.questionService.getFilteredAndSortedQuestions().subscribe(res => {
      this.questionList = res;
        this.questionList.forEach(element => {
          element.markedToDelete = false;
        });
      });
  this.isQuestionCreated = this.questionService.isQuestionCreated();
}

  goOnEditPage() {
    this.router.navigateByUrl("/question/create");
    this.isQuestionCreated = this.questionService.isQuestionCreated();
    console.log(this.isQuestionCreated + ' <------ is created ? ');
  }

  openDeleteModal() {
    document.getElementById('deleteModal').style.display = "block";
  }

  closeDeleteModal() {
    document.getElementById('deleteModal').style.display = "none";
  }

  previousPage() {
    if (this.questionService.pageNumber > 1) {
      this.questionService.pageNumber--;

      this.pageNumber = this.questionService.pageNumber;

      this.maxPageNumber = Math.floor(this.questionService.totalQuestions / 15) + 1;
      this.update(true);
      console.log(this.questionService.pageNumber);
    }
    this.isQuestionCreated = this.questionService.isQuestionCreated();
    console.log(this.questionService.isCreated + ' is created');
  }

  nextPage() {
    if (this.questionService.pageNumber < (this.questionService.totalQuestions / 15) + 1) {
      this.questionService.pageNumber++;
      this.pageNumber = this.questionService.pageNumber;
      this.maxPageNumber = Math.floor(this.questionService.totalQuestions / 15) + 1;

      this.update(true);
      console.log(this.questionService.pageNumber);
    }
    this.isQuestionCreated = this.questionService.isQuestionCreated();
    console.log(this.questionService.isCreated + ' is created');
  }

  firstPage() {
    this.questionService.pageNumber = 1;
    this.pageNumber = this.questionService.pageNumber;
    this.maxPageNumber = Math.floor(this.questionService.totalQuestions / 15) + 1;

    this.update(true);
    console.log(this.questionService.pageNumber);
    this.isQuestionCreated = this.questionService.isQuestionCreated();
    console.log(this.questionService.isCreated + ' is created');
  }

  lastPage() {
    if(this.questionService.totalQuestions / 15 != Math.floor(this.questionService.totalQuestions / 15)){
    this.questionService.pageNumber = (Math.floor(this.questionService.totalQuestions / 15) + 1);
    this.pageNumber = this.questionService.pageNumber;
    this.maxPageNumber = Math.floor(this.questionService.totalQuestions / 15) + 1;

    this.update(true);
    console.log(this.questionService.pageNumber);
    this.isQuestionCreated = this.questionService.isQuestionCreated();
    console.log(this.questionService.isCreated + ' is created');
    }else{
      this.questionService.pageNumber = (Math.floor(this.questionService.totalQuestions / 15));
      this.pageNumber = this.questionService.pageNumber;
      this.maxPageNumber = Math.floor(this.questionService.totalQuestions / 15);
  
      this.update(true);
      console.log(this.questionService.pageNumber);
      this.isQuestionCreated = this.questionService.isQuestionCreated();
      console.log(this.questionService.isCreated + ' is created');
    }
  }

  updatePageByPageNumber($event) {
    if ($event.keyCode == 13) {
      if (this.pageNumber >= 1) {
        if (this.pageNumber <= Math.floor(this.questionService.totalQuestions / 15) + 1) {
          this.questionService.pageNumber = this.pageNumber;
          this.maxPageNumber = Math.floor(this.questionService.totalQuestions / 15) + 1;

          console.log(this.pageNumber);
          this.update(true);
        }
      }
    }
    this.isQuestionCreated = this.questionService.isQuestionCreated();
    console.log(this.questionService.isCreated + ' is created');
  }
  
  hideBanner(){
    this.isQuestionDeleted = false;
  }

}