import { Component, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-logic-answer',
  templateUrl: './logic-answer.component.html',
  styleUrls: ['./logic-answer.component.css']
})
export class LogicAnswerComponent implements OnInit {

  @Output() answerText;
  constructor() { }

  ngOnInit() {
  }

}
