import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LogicAnswerComponent } from './logic-answer.component';

describe('LogicAnswerComponent', () => {
  let component: LogicAnswerComponent;
  let fixture: ComponentFixture<LogicAnswerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LogicAnswerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LogicAnswerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
