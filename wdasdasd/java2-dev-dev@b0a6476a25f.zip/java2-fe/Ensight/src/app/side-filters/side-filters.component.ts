import { Component, OnInit,  EventEmitter, Output } from '@angular/core';
import { NgForm } from '@angular/forms';
import { QuestionsService } from '../services/questions.service';

@Component({
  selector: 'app-side-filters',
  templateUrl: './side-filters.component.html',
  styleUrls: ['./side-filters.component.css']
})
export class SideFiltersComponent implements OnInit {

  constructor(private questionService: QuestionsService) { }
    filter= this.questionService.filter;

    @Output() mustUpdateQuestionList = new EventEmitter<boolean>();

  	onFormSubmit(form: NgForm) {
     this.filter.difficulty.setDifficulty(form);
     this.filter.type.setType(form);
     this.filter.discipline.setDiscipline(form);

     this.questionService.filter=this.filter;
     this.mustUpdateQuestionList.emit(true);

	}

  ngOnInit() {
  }
}