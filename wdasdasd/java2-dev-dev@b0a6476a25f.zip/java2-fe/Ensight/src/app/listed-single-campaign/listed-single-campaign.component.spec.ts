import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListedSingleCampaignComponent } from './listed-single-campaign.component';

describe('ListedSingleCampaignComponent', () => {
  let component: ListedSingleCampaignComponent;
  let fixture: ComponentFixture<ListedSingleCampaignComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListedSingleCampaignComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListedSingleCampaignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
