import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-listed-single-campaign',
  templateUrl: './listed-single-campaign.component.html',
  styleUrls: ['./listed-single-campaign.component.css']
})
export class ListedSingleCampaignComponent implements OnInit {
  
  @Input() campaign;

  constructor(private router: Router) { }

  ngOnInit() {
  }

  goToCandidatesPage() {
    this.router.navigateByUrl('candidates');
  }
}
