import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { TestService } from '../services/test.service';
import { Test } from '../models/Test';
import { GeneralSettingsService } from '../services/general-settings.service';
import { GeneralSettings } from '../models/GeneralSettings';
import { MappingService } from '../services/mapping.service';
import { AppComponent } from '../app.component';
import { ExamService } from '../services/exam.service';
import { Exam } from '../models/Exam';
import { CandidateTestCompositeKey } from '../models/CandidateTestCompositeKey';
import { stringify } from 'querystring';

@Component({
  selector: 'app-take-test-instructions',
  templateUrl: './take-test-instructions.component.html',
  styleUrls: ['./take-test-instructions.component.css']
})
export class TakeTestInstructionsComponent implements OnInit {

  testId: number;
  test: Test = new Test();
  candidateId;
  generalSettings: GeneralSettings = new GeneralSettings();
  isStartedTest: boolean = false;
  compositeIdCandidateTest: string;


  constructor(public map: MappingService, private settingsService: GeneralSettingsService, private testService: TestService, private router: Router,private route: ActivatedRoute,private examService : ExamService ) { }

  ngOnInit() {
    this.testService.backPageActioned = false;
    this.testId = parseInt(this.route.snapshot.paramMap.get('id').valueOf());
    
    this.testService.getById(this.testId)
    .subscribe(response => { this.test = response as Test; console.log(response);
      this.testService.test = this.test;
      
      console.log('testId : ' + this.testId);
      console.log('test.id : ' + this.test.id);
      console.log('testService.test.id : ' + this.testService.test.id); 
    });

    this.settingsService.getGeneralSettings().subscribe(response => { this.generalSettings = response as GeneralSettings; console.log(response);
    this.testService.duration = this.generalSettings.duration; });

  }

  goToCodeSnippetPage(){
    this.router.navigateByUrl('take_test/code_snippet');
    
  }

  goToEffectiveTestPageAndCreateExam(){
    this.examService.checkIfCandidateStartedExam(this.testId, this.candidateId).subscribe(res => {
      this.isStartedTest = res as boolean;
      console.log("is test started------ " + this.isStartedTest);

      if(!this.isStartedTest){

        let exam: Exam = new Exam();
        let compositeKey: CandidateTestCompositeKey = new CandidateTestCompositeKey();

        compositeKey.testId = this.testId;
        compositeKey.candidateId = this.candidateId;

        exam.id = compositeKey;

        // this.examService.createCandidateExam(exam)
        //   .subscribe(
        //     res => {console.log('response from posting exam ----- ' + stringify(res));
            
        //     this.router.navigateByUrl('take-test-page/'+this.testId+'/'+ this.candidateId);
        //   });

        this.examService.startExam(this.testId,this.candidateId)
          .subscribe(
            res => {
            //console.log('response from starting exam ----- ' + res);
            this.router.navigateByUrl('take-test-page/'+this.testId+'/'+ this.candidateId);
          });

      }else{
        this.router.navigateByUrl('take_test/end/'+this.testId);
      }
    });

    //this.router.navigateByUrl('take-test-page/'+this.testId+'/'+ this.candidateId);
  }

}
