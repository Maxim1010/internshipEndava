import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TakeTestInstructionsComponent } from './take-test-instructions.component';

describe('TakeTestInstructionsComponent', () => {
  let component: TakeTestInstructionsComponent;
  let fixture: ComponentFixture<TakeTestInstructionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TakeTestInstructionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TakeTestInstructionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
