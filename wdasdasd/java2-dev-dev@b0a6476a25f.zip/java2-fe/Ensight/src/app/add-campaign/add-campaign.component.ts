import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Campaign } from '../models/Campaign';
import { HttpClient } from '../../../node_modules/@angular/common/http';
import { AppComponent } from '../app.component';

@Component({
  selector: 'app-add-campaign',
  templateUrl: './add-campaign.component.html',
  styleUrls: ['./add-campaign.component.css']
})
export class AddCampaignComponent implements OnInit {

  campaign: Campaign = new Campaign();
  datesAreChronological: boolean = true;
  constructor(private router: Router,private http: HttpClient) { }

  ngOnInit() {
  }

  submitCampaign(){
    //TO DO : move to campaign service
    const requestUrl = AppComponent.serverUrl + '/campaign';
    this.http.post(requestUrl, this.campaign).subscribe(res=>console.log("rezultat de la BE: " + res));
    this.goToQuestionsPage();
  }

  goToQuestionsPage(){
    this.router.navigateByUrl('questions');
  }

  updateFormMessage(){
    this.datesAreChronological=(this.campaign.startCampaign<this.campaign.startPromoting)&&
    (this.campaign.startPromoting<this.campaign.startTests)&&
    (this.campaign.startTests<this.campaign.startInternship)&&
    (this.campaign.startInternship<this.campaign.endInternship);
    console.log("update result:" + this.datesAreChronological);
  }
}
