import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes} from '@angular/router'

import { AppComponent } from './app.component';
import { HeaderComponent } from './general/header/header.component';
import { TestParametersComponent } from './test-parameters/test-parameters.component';
import { QuestionListPageComponent } from './question-list-page/question-list-page.component';

import { SideFiltersComponent } from './side-filters/side-filters.component';
import { ListedQuestionsComponent } from './listed-questions/listed-questions.component';

import { AddQuestionComponent } from './add-question/add-question.component';
import { QuestionsAttributesComponent } from './questions-attributes/questions-attributes.component';

import { LogicAnswerComponent } from './logic-answer/logic-answer.component';
import { MultipleChoiceComponent } from './multiple-choice/multiple-choice.component';
import { ListedSingleQuestionComponent } from './listed-single-question/listed-single-question.component';
import { CodeSnippetComponent } from './code-snippet/code-snippet.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { QuestionOverviewComponent } from './question-overview/question-overview.component';
import { QuestionOverviewParametersComponent } from './question-overview-parameters/question-overview-parameters.component';

import { HttpClientModule } from '@angular/common/http';

import { ListedSingleTestComponent } from './listed-single-test/listed-single-test.component';
import { ListedTestsComponent } from './listed-tests/listed-tests.component';
import { TestsListPageComponent } from './tests-list-page/tests-list-page.component';
import { SideFiltersTestsComponent } from './side-filters-tests/side-filters-tests.component';
import { TestParametersButtonComponent } from './test-parameters-button/test-parameters-button.component';
import { EditQuestionComponent } from './edit-question/edit-question.component';
import { GenerateTestComponent } from './generate-test/generate-test.component';
import { QuestionAttributesEditComponent } from './question-attributes-edit/question-attributes-edit.component';
import { TestEditComponent } from './test-edit/test-edit.component';
import { TestListedQuestionsComponent } from './test-listed-questions/test-listed-questions.component';
import { TestListedSingleQuestionComponent } from './test-listed-single-question/test-listed-single-question.component';
import { TakeTestInstructionsComponent } from './take-test-instructions/take-test-instructions.component';
import { TakeTestSummaryComponent } from './take-test-summary/take-test-summary.component';
import { TakeTestHeaderComponent } from './take-test-header/take-test-header.component';
import { TakeTestSingleAnswerComponent } from './take-test-single-answer/take-test-single-answer.component';
import { TakeTestOpenAnswerComponent } from './take-test-open-answer/take-test-open-answer.component';
import { TakeTestCodeSnippetComponent } from './take-test-code-snippet/take-test-code-snippet.component';
import { TakeTestProgressTimeHeaderComponent } from './take-test-progress-time-header/take-test-progress-time-header.component';
import { TakeTestPageComponent } from './take-test-page/take-test-page.component';
import { AddCampaignComponent } from './add-campaign/add-campaign.component'; 
import { Observable } from 'rxjs';
import { PendingChangesGuard } from './models/NavigationDezactivate';
import { CandidatesListPageComponent } from './candidates-list-page/candidates-list-page.component';
import { ListedCandidatesComponent } from './listed-candidates/listed-candidates.component';
import { ListedSingleCandidateComponent } from './listed-single-candidate/listed-single-candidate.component';
import { EditCandidateComponent } from './edit-candidate/edit-candidate.component';
import { SideFiltersCandidatesComponent } from './side-filters-candidates/side-filters-candidates.component';
import { ReadExcelDirective } from './directives/read-excel.directive';
import { ListedSingleCampaignComponent } from './listed-single-campaign/listed-single-campaign.component';

const routes: Routes = [
  { path: 'questions', component: QuestionListPageComponent},
  { path: 'question/create', component: AddQuestionComponent},
  { path: 'question/:id', component: QuestionOverviewComponent},
  { path: 'question/:id/edit', component: EditQuestionComponent},
  { path: 'test/parameters', component: TestParametersComponent},
  { path: 'tests', component: TestsListPageComponent },
  { path: 'tests/:id/edit', component: TestEditComponent},
  { path: 'tests/generate', component: GenerateTestComponent},
  { path: 'take_test/start/:id', component: TakeTestInstructionsComponent},
  { path: 'take_test/single_answer', component: TakeTestSingleAnswerComponent },
  { path: 'take_test/open_answer', component: TakeTestOpenAnswerComponent },
  { path: 'take_test/code_snippet', component: TakeTestCodeSnippetComponent },
  { path: 'take_test/end/:id', component: TakeTestSummaryComponent},
  { path: 'take-test-page/:id/:candidateId', component: TakeTestPageComponent, canActivate: [TakeTestPageComponent]},
  { path: 'campaign/add', component: AddCampaignComponent},
  { path: 'candidates', component: CandidatesListPageComponent},
  { path: 'candidates/:id/edit', component: EditCandidateComponent},
  { path: '', redirectTo: 'questions', pathMatch:'full'},
  { path: '**', redirectTo: 'questions'},
]
@NgModule({
  declarations: [
    AppComponent,
    QuestionListPageComponent,
    HeaderComponent,
    SideFiltersComponent,
    ListedQuestionsComponent,
    TestParametersComponent,
    AddQuestionComponent,
    LogicAnswerComponent,
    MultipleChoiceComponent,
    CodeSnippetComponent,
    QuestionsAttributesComponent,
    ListedSingleQuestionComponent,
    CodeSnippetComponent,
    QuestionOverviewComponent,
    QuestionOverviewParametersComponent,
    ListedSingleTestComponent,
    ListedTestsComponent,
    TestsListPageComponent,
    SideFiltersTestsComponent,
    TestParametersButtonComponent,
    EditQuestionComponent,
    GenerateTestComponent,
    QuestionAttributesEditComponent,
    TestEditComponent,
    TestListedQuestionsComponent,
    TestListedSingleQuestionComponent,
    TakeTestInstructionsComponent,
    TakeTestSummaryComponent,
    TakeTestHeaderComponent,
    TakeTestSingleAnswerComponent,
    TakeTestOpenAnswerComponent,
    TakeTestCodeSnippetComponent,
    TakeTestProgressTimeHeaderComponent,
    TakeTestPageComponent,
    AddCampaignComponent,
    CandidatesListPageComponent,
    ListedCandidatesComponent,
    ListedSingleCandidateComponent,
    EditCandidateComponent,
    SideFiltersCandidatesComponent,
    ReadExcelDirective,
    ListedSingleCampaignComponent,
  ],
  imports: [
    BrowserModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(routes),
    HttpClientModule
  ],
  exports: [
    RouterModule
  ],
  providers: [PendingChangesGuard],
  bootstrap: [AppComponent]
})
export class AppModule { 
  
}
