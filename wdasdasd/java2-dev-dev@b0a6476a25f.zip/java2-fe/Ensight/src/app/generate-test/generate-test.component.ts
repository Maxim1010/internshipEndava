import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { TestService } from '../services/test.service';
import { GenerateParams } from '../models/GenerateParams';
import { isNull } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-generate-test',
  templateUrl: './generate-test.component.html',
  styleUrls: ['./generate-test.component.css']
})
export class GenerateTestComponent implements OnInit {

  testData: GenerateParams = new GenerateParams();
  fillConstruct; aux; loader; percent; strokeStartingPoint; ascending; currentcolor; colors; 
  isTestGenerated;

  constructor(private router: Router, private service: TestService) { }

  @Input() AM: number;
  @Input() NET: number;
  @Input() JAVA: number;
  @Input() TESTING: number;

  @Input() currentDiscipline: number;

  @Input() easy: string;
  @Input() medium: string;
  @Input() hard: string;
  @Input() questions: string;
  @Input() tests: string;

  badPercentage: boolean;
  badQuestions: boolean;
  badTests: boolean;
  generated: boolean;
  
  ngOnInit() {
    this.service.currentTest.subscribe(test => this.isTestGenerated = test);
    this.AM = 1;
    this.NET = 2;
    this.JAVA = 3;
    this.TESTING = 4;
    this.testData.discipline = "AM";
    this.currentDiscipline = 1;

    this.aux = document.getElementById('circle');
    this.loader = this.aux.getContext("2d");
    this.percent = 0;
    this.strokeStartingPoint = 3 / 2 * Math.PI;
    this.loader.lineWidth = 8;
    this.loader.fillstyle = '#48545B';
    this.loader.strokeStyle = '#de411b';
    this.ascending = 1;
    this.currentcolor = 0;
    this.colors = [
      "#a0c1b9",
      "#70a0af",
      "#706993",
      "#beee62",
      "#70ae6e",
      "#6369d1"
    ]; 
  }

  createCircle() {
    this.loader.clearRect(0, 0, this.loader.canvas.width, this.loader.canvas.height);
    if (this.ascending == 1) {
      this.percent++;
      this.loader.beginPath();
      this.loader.arc(30, 30, 20, this.strokeStartingPoint, (this.percent / 100) * (2 * Math.PI) + this.strokeStartingPoint, false);
      this.loader.stroke();
      if (this.percent == 100)
        this.ascending = 0;
    }
    else {
      this.percent--;
      this.loader.beginPath();
      this.loader.arc(30, 30, 20, ((100 - this.percent) / 100) * (2 * Math.PI) + this.strokeStartingPoint, this.strokeStartingPoint, false);
      this.loader.stroke();
      if (this.percent == 0) {
        this.ascending = 1;
        this.loader.strokeStyle = this.colors[this.currentcolor];
        this.currentcolor++;
        if (this.currentcolor == this.colors.length - 1)
          this.currentcolor = 0;

      }
    }
    if (this.percent == 102)
      clearTimeout(this.fillConstruct);
  }


  loading() {
    let fillConstruct = setInterval(()=>{this.createCircle()}, 10);
  }

  onSubmit(event: Event) {
    this.loading();
    this.generated = true;
    let testPostData: any;
    testPostData = this.testData;
    testPostData.easyPercent = parseInt(testPostData.easyPercent);
    testPostData.mediumPercent = parseInt(testPostData.mediumPercent);
    testPostData.hardPercent = parseInt(testPostData.hardPercent);
    console.log(this.testData);
    this.service.postGenerateTests(this.testData).subscribe(res => {
      this.service.changeGenerateTestBannerVisibility(true);
      console.log(res);
      this.router.navigateByUrl("/tests");
    });
    console.log(this.testData);
  }

  makeActiveDiscipline(discipline: number) {
    if (discipline == 1) {
      this.testData.discipline = "AM";
      this.currentDiscipline = 1;
    }
    if (discipline == 2) {
      this.testData.discipline = "NET";
      this.currentDiscipline = 2;
    }
    if (discipline == 3) {
      this.testData.discipline = "JAVA";
      this.currentDiscipline = 3;
    }
    if (discipline == 4) {
      this.testData.discipline = "TESTING";
      this.currentDiscipline = 4;
    }
    console.log(this.testData.discipline);
  }

  checkPercentage() {
    if (this.testData.easyPercent + this.testData.mediumPercent + this.testData.hardPercent != 100)
      this.badPercentage = true;
    else
      if (this.testData.easyPercent % 10 != 0 ||
        this.testData.mediumPercent % 10 != 0 ||
        this.testData.hardPercent % 10 != 0)
        this.badPercentage = true;
      else
        this.badPercentage = false;

  }

  isInvalid(option: number){
    if (option == 0) {
      this.testData.numberOfQuestions = parseInt(this.questions, 10);
      console.log(this.testData.numberOfQuestions);
      if (this.testData.numberOfQuestions < 0) {
        this.testData.numberOfQuestions = -this.testData.numberOfQuestions;
      } else if (isNaN(this.questions as any)
        || !isFinite(this.testData.numberOfQuestions) || !Number.isInteger(this.testData.numberOfQuestions)) {
          this.questions = '';
          this.testData.numberOfQuestions = null;
      } else if (this.testData.numberOfQuestions % 10 != 0 || this.testData.numberOfQuestions == 0) {
        this.badQuestions = true;
      } else {
        this.badQuestions = false;
      }
      this.questions = this.testData.numberOfQuestions.toString().replace(/[^0-9]+/g, "");
    }
    if (option == 1) {
      this.testData.easyPercent = parseInt(this.easy, 10);
      if (this.testData.easyPercent < 0) {
        this.testData.easyPercent = -this.testData.easyPercent;
      } else if (isNaN(this.easy as any) ||
          !isFinite(this.testData.easyPercent) ||
          !(typeof (this.testData.easyPercent) == 'number')) {
          this.easy = '';
          this.testData.easyPercent = null;
      } else if (!Number.isInteger(this.testData.easyPercent)) {
        this.testData.easyPercent = Math.floor(this.testData.easyPercent);
        console.log(this.testData.easyPercent);
      }
      this.checkPercentage();
      this.easy = this.testData.easyPercent.toString().replace(/[^0-9]+/g, "");
    }
    if (option == 2) {
      this.testData.mediumPercent = parseInt(this.medium, 10);
      if (this.testData.mediumPercent < 0) {
        this.testData.mediumPercent = -this.testData.mediumPercent;
      } else if (isNaN(this.medium as any) ||
      !isFinite(this.testData.mediumPercent) ||
      !(typeof (this.testData.mediumPercent) == 'number')) {
        this.medium = '';
        this.testData.mediumPercent = null;
      } else if (Number.isInteger(this.testData.mediumPercent) == false) {
        this.testData.mediumPercent = Math.floor(this.testData.mediumPercent);
        console.log(this.testData.mediumPercent);
      } 
      this.checkPercentage();
      this.medium = this.testData.mediumPercent.toString().replace(/[^0-9]+/g, "");
    }
    if (option == 3) {
      this.testData.hardPercent = parseInt(this.hard, 10);
      if (this.testData.hardPercent < 0) {
        this.testData.hardPercent = -this.testData.hardPercent;
      } else if (isNaN(this.hard as any) ||
      !isFinite(this.testData.hardPercent) ||
      !(typeof (this.testData.hardPercent) == 'number')) {
        this.hard = '';
        this.testData.hardPercent = null;
      } else if (Number.isInteger(this.testData.hardPercent) == false) {
        this.testData.hardPercent = Math.floor(this.testData.hardPercent);
        console.log(this.testData.hardPercent);
      }
      this.checkPercentage();
      this.hard = this.testData.hardPercent.toString().replace(/[^0-9]+/g, "");
    }
    if (option == 4) {
      this.testData.numberOfTests = parseInt(this.tests, 10);
      if (this.testData.numberOfTests < 0) {
        this.testData.numberOfTests = -this.testData.numberOfTests;
      } else if (this.testData.numberOfTests == 0 || isNaN(this.tests as any)) {
        this.tests = '';
        this.testData.numberOfTests = null;
        this.badTests = true;
      } else {
        this.badTests = false;
      }
      this.tests = this.testData.numberOfTests.toString().replace(/[^0-9]+/g, "");
    }
  }

  isAnyNaN() {
    if (isNaN(this.testData.numberOfQuestions) || isNaN(this.testData.easyPercent)
      || isNaN(this.testData.mediumPercent) || isNaN(this.testData.hardPercent)
      || isNaN(this.testData.numberOfTests))
      return true;
    return false;
  }

  badParams() {
    if (this.isAnyNaN() == true || this.badPercentage == true || this.testData.numberOfQuestions < 1
      || this.testData.numberOfTests < 1 || this.badQuestions == true)
      return true;
    return false;
  }

  goToTestsPage() {
    this.router.navigateByUrl('tests');
  }
}
