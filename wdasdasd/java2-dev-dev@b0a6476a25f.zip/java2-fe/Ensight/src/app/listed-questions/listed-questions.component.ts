import { Component, OnInit, Input, ViewChild, SimpleChanges, ViewChildren, QueryList,Output, EventEmitter } from '@angular/core';
import { Question } from '../models/Question';
import { QuestionsService } from '../services/questions.service';
import { ListedSingleQuestionComponent } from '../listed-single-question/listed-single-question.component';
import { forEach } from '@angular/router/src/utils/collection';

@Component({
  selector: 'app-listed-questions',
  templateUrl: './listed-questions.component.html',
  styleUrls: ['./listed-questions.component.css']
})
export class ListedQuestionsComponent implements OnInit {


  @Input() questionList: any; 
  @Output() mustUpdateQuestionList = new EventEmitter<boolean>();
  @Output() deleteQuestion = new EventEmitter<number>();
  allMarked: boolean = false;

  constructor(public questionService: QuestionsService) { }
  
  
  @ViewChildren(ListedSingleQuestionComponent) children: QueryList<ListedSingleQuestionComponent>;
  

  ngOnInit() {
    this.questionService.currentAfterDeleteCheck.subscribe(isChecked => this.allMarked = isChecked);
    this.allMarked = false;
  }

  toggleAllForDelete() {
    
    this.allMarked=!this.allMarked;
    this.questionService.changeAfterDeleteCheckValue(this.allMarked);
    this.questionList.forEach(element => {
      this.questionService.currentAfterDeleteCheck.subscribe(isChecked => {this.allMarked = isChecked;
        element.markedToDelete = this.allMarked; })
        
    });
    this.children.forEach(child=>{
      child.markAll(this.allMarked);
    });
  }

  deleteRequest(id: number){ 
    this.deleteQuestion.emit(id);
    console.log("single q: ok");
  }

  update(status:boolean){
    if(status==true)
    {this.mustUpdateQuestionList.emit(true);
    }
    
  }

  onDeselect(event :boolean){
    if(!event)
      this.allMarked=false; 
  }

  titleDesc(){

    if(document.getElementById("titleDesc").className=="far fa-caret-square-down")
      {
        
      }
    else
      {
      this.disableAllSortButtons();
      document.getElementById("titleDesc").className="far fa-caret-square-down";
      this.questionService.sortField=1;
      this.questionService.order="desc";
      this.questionService.getFilteredAndSortedQuestions().subscribe(res =>{ this.questionList = res;
        this.questionList.forEach(element => {
          element.markedToDelete = false;
        });
      });
      }
  }

  titleAsc(){

    if(document.getElementById("titleAsc").className=="far fa-caret-square-up")
      {
      }
    else
      {
        this.disableAllSortButtons();
        document.getElementById("titleAsc").className="far fa-caret-square-up";
        this.questionService.sortField=1;
        this.questionService.order="asc";
        this.questionService.getFilteredAndSortedQuestions().subscribe(res =>{ this.questionList = res;
          this.questionList.forEach(element => {
            element.markedToDelete = false;
          });
        }); 
      }
  }

  cDateDesc(){

    if(document.getElementById("cDateDesc").className=="far fa-caret-square-down")
      {
       }
    else
      {
        this.disableAllSortButtons();
       document.getElementById("cDateDesc").className="far fa-caret-square-down";
       this.questionService.sortField=2;
       this.questionService.order="desc";
       this.questionService.getFilteredAndSortedQuestions().subscribe(res =>{ this.questionList = res;
        this.questionList.forEach(element => {
          element.markedToDelete = false;
        });
      });
      }
  }

  cDateAsc(){

    if(document.getElementById("cDateAsc").className=="far fa-caret-square-up")
      {
      }
    else
      {
        this.disableAllSortButtons();
        document.getElementById("cDateAsc").className="far fa-caret-square-up";
        this.questionService.sortField=2;
        this.questionService.order="asc";
        this.questionService.getFilteredAndSortedQuestions().subscribe(res =>{ this.questionList = res;
          this.questionList.forEach(element => {
            element.markedToDelete = false;
          });
        });
      }
  }

  uDateDesc(){

    if(document.getElementById("uDateDesc").className=="far fa-caret-square-down")
      {
      }
    else
      {
        this.disableAllSortButtons();
        document.getElementById("uDateDesc").className="far fa-caret-square-down";
        this.questionService.sortField=3;
        this.questionService.order="desc";
        this.questionService.getFilteredAndSortedQuestions().subscribe(res =>{ this.questionList = res;
          this.questionList.forEach(element => {
            element.markedToDelete = false;
          });
        });
       }
  }

  uDateAsc(){

    if(document.getElementById("uDateAsc").className=="far fa-caret-square-up")
      {

       }
    else
      {
        this.disableAllSortButtons();
        document.getElementById("uDateAsc").className="far fa-caret-square-up";
        this.questionService.sortField=3;
        this.questionService.order="asc";
        this.questionService.getFilteredAndSortedQuestions().subscribe(res =>{ this.questionList = res;
          this.questionList.forEach(element => {
            element.markedToDelete = false;
          });
        });
    }
  }

  disableAllSortButtons(){
      document.getElementById("titleAsc").className="fas fa-caret-square-up"; 
      document.getElementById("titleDesc").className="fas fa-caret-square-down";
      document.getElementById("cDateAsc").className="fas fa-caret-square-up";
      document.getElementById("cDateDesc").className="fas fa-caret-square-down";
      document.getElementById("uDateAsc").className="fas fa-caret-square-up";
      document.getElementById("uDateDesc").className="fas fa-caret-square-down";
      
  }
}
