import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListedQuestionsComponent } from './listed-questions.component';

describe('ListedQuestionsComponent', () => {
  let component: ListedQuestionsComponent;
  let fixture: ComponentFixture<ListedQuestionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListedQuestionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListedQuestionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
