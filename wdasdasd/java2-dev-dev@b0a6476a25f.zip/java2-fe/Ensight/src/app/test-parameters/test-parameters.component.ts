import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { GeneralSettingsService } from '../services/general-settings.service';
import { GeneralSettings } from '../models/GeneralSettings';

@Component({
  selector: 'app-test-parameters',
  templateUrl: './test-parameters.component.html',
  styleUrls: ['./test-parameters.component.css']
})
export class TestParametersComponent implements OnInit {

  generalSettings: GeneralSettings = new GeneralSettings();
  isGeneralSettingsUpdated:boolean;

  constructor(private router : Router, private generalSettingsService: GeneralSettingsService) { }


  ngOnInit() {
    this.generalSettingsService.currentGeneralSettingsUpdated.subscribe(settings => {
      this.isGeneralSettingsUpdated = settings;
    });
    this.generalSettingsService.getGeneralSettings().subscribe(res=> this.generalSettings=res as GeneralSettings);
  }

  goToTestsPage(){
    this.router.navigateByUrl('tests');
  }

  updateGeneralSettings(){
    this.generalSettingsService.updateGeneralSettings(this.generalSettings).subscribe(res=>{
      console.log('am facut update la settings ' + res);
      this.generalSettingsService.changeGeneralSettingsBannerVisibility(true);
    });
    this.router.navigateByUrl('tests');
  }
}
