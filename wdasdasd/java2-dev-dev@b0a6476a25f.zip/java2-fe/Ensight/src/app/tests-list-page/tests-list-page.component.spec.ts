import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestsListPageComponent } from './tests-list-page.component';

describe('TestsListPageComponent', () => {
  let component: TestsListPageComponent;
  let fixture: ComponentFixture<TestsListPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestsListPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestsListPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
