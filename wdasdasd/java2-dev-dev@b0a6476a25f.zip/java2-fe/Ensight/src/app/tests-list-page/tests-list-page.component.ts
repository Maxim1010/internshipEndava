import { Component, OnInit, Input, Injectable, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { TestService } from '../services/test.service';
import { GeneralSettingsService } from '../services/general-settings.service';
import { ListedTestsComponent } from '../listed-tests/listed-tests.component';

@Component({
  selector: 'app-tests-list-page',
  templateUrl: './tests-list-page.component.html',
  styleUrls: ['./tests-list-page.component.css']
})
@Injectable({
  providedIn: 'root'
})
export class TestsListPageComponent implements OnInit {

  @Input() testList: any;
  testToBeDeleted: number = -1;
  multipleDeleteStatus: boolean = false;
  public updateTotalTestsEvent: Event;
  isTestBannerVisible: boolean;
  isGeneralSettingsUpdated: boolean;
  isDeleteComplete: boolean = false;
  allMarked: boolean;


  constructor(
    private service: TestService,
    private router: Router,
    private generalSettingsService: GeneralSettingsService,
  ) { }

  ngOnInit() {
    this.service.currentAllChecked.subscribe(isChecked => {
      this.allMarked = isChecked;
    });
    this.service.currentTest.subscribe(test => this.isTestBannerVisible = test);
    this.generalSettingsService.currentGeneralSettingsUpdated.subscribe(settings => {
      this.isGeneralSettingsUpdated = settings;
    })
    this.hideMyBanner();

    this.service.getFilteredAndSortedTests().subscribe(res => {
      this.testList = res;
      this.testList.forEach(element => {
        element.markedToDelete = false;
      });
    });
  }

  hideMyBanner() {
    setTimeout(() => {
      this.isDeleteComplete = false;
      this.service.changeGenerateTestBannerVisibility(false);
      console.log('seconds before invisible');
    }, 3000);
  }

  hideBannerOnClick() {
    this.isDeleteComplete = false;
    this.service.changeGenerateTestBannerVisibility(false);
  }

  delete(id: number) {
    this.multipleDeleteStatus = false;
    this.testToBeDeleted = id;
    this.openDeleteModal();
  }


  deleteRequest() {
    if (this.multipleDeleteStatus == false) {
      if (this.testToBeDeleted != -1) {
        this.update(true);
        this.service.deleteRequest(this.testToBeDeleted).subscribe(res => {
          console.log("deleted test with id:" + this.testToBeDeleted);
          this.isDeleteComplete = true;
          this.update(true);
          this.hideMyBanner();
        });
      }
      this.testToBeDeleted = -1;
      this.closeDeleteModal();
    }
    else {
      this.multipleDeleteRequest();

      this.service.changeAllChekedStatus(false);
      this.service.currentAllChecked.subscribe(isChecked => {
        this.allMarked = isChecked;
      });
      this.multipleDeleteStatus = false;
      this.closeDeleteModal();
    }
    this.update(true);
  }

  update(status: boolean) {
    if (status == true)
      this.service.getFilteredAndSortedTests().subscribe(res => {
        this.testList = res;
        this.testList.forEach(element => {
          element.markedToDelete = false;
        });
      });
  }

  multipleDelete() {
    this.multipleDeleteStatus = true;
    this.openDeleteModal();
  }

  multipleDeleteRequest() {
    let ids: Array<number> = [];
    for (let test of this.testList) {
      if (test.markedToDelete == true) {
        ids.push(test.id);
        console.log(test.id);
      }
    }
    if (ids.length > 0) {
      this.service.multipleDeleteRequest(ids).subscribe(res => {

        console.log(res);
        this.isDeleteComplete = true;
        this.hideMyBanner();
        this.update(true);

      });
    }

  }


  goOnGeneratePage() {
    this.router.navigateByUrl("tests/generate");
  }

  sideFilterUpdateTotalTests(event: Event) {
    this.updateTotalTestsEvent = event;
    console.log('event from child arrived ' + event);
  }

  openDeleteModal() {
    document.getElementById('deleteModal').style.display = "block";
  }

  closeDeleteModal() {
    document.getElementById('deleteModal').style.display = "none";
  }


}
