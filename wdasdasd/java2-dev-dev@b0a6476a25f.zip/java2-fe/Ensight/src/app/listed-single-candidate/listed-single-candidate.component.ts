import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { CandidateAndHisExam } from '../models/CandidateAndHisExam';
import { Candidate } from '../models/Candidate';
import { Exam } from '../models/Exam';
import { CandidateChecked } from '../models/CandidateChecked';

@Component({
  selector: 'app-listed-single-candidate',
  templateUrl: './listed-single-candidate.component.html',
  styleUrls: ['./listed-single-candidate.component.css']
})
export class ListedSingleCandidateComponent implements OnInit {

  @Input() candidateAndHisExam: any;

  @Input() index;
  isChecked: boolean = false;
  @Output() isMarked = new EventEmitter();
  @Output() isChildChecked = new EventEmitter<CandidateChecked>();
  candidateChecked = new CandidateChecked();
  isStatusSent: boolean = false;

  constructor() { }

  ngOnInit() {
    let tempCandidateAndHisExam: CandidateAndHisExam = new CandidateAndHisExam();
    tempCandidateAndHisExam = this.candidateAndHisExam as CandidateAndHisExam;
    if (tempCandidateAndHisExam.exam.status.match("READY_TO_SEND") === null) {
      this.isStatusSent = true;
    } else {
      this.isStatusSent = false;
    }
    console.log('status of candidate : ' + (this.isStatusSent));
  }

  checkIfRowIsEven() {
    return this.index % 2 === 0;
  }

  submitSingleCandidate() {
    this.isChecked = !this.isChecked;
    this.candidateChecked.candidateAndExam = this.candidateAndHisExam;
    this.candidateChecked.isChecked = this.isChecked;
    this.isChildChecked.emit(this.candidateChecked);
  }

  markAll(marked: boolean) {
    if(!this.isStatusSent){
    this.isChecked = marked;
    }
    this.candidateChecked.candidateAndExam = this.candidateAndHisExam;
    this.candidateChecked.isChecked = this.isChecked;

    this.candidateAndHisExam.markedToDelete = marked;

    this.isMarked.emit(this.candidateAndHisExam.markedForDelete);
    this.isChildChecked.emit(this.candidateChecked);
  }
}

