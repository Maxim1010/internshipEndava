import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListedSingleCandidateComponent } from './listed-single-candidate.component';

describe('ListedSingleCandidateComponent', () => {
  let component: ListedSingleCandidateComponent;
  let fixture: ComponentFixture<ListedSingleCandidateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListedSingleCandidateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListedSingleCandidateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
