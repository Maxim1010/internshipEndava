import { Component, OnInit, Input, Output } from '@angular/core';
import { Question } from '../models/Question';
import { Answer } from '../models/Answer';
import { QuestionsService } from '../services/questions.service';
import { AnswersService } from '../services/answers.service';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';

@Component({
  selector: 'app-question-overview',
  templateUrl: './question-overview.component.html',
  styleUrls: ['./question-overview.component.css']
})
export class QuestionOverviewComponent implements OnInit {
  questionId: number;
  question: Question = new Question();
  answers: Answer[];
  isBannerVisible: boolean;
  

  constructor(private questionService: QuestionsService,
    private answerService: AnswersService,
    private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    this.questionService.currentEditBanner.subscribe(banner => this.isBannerVisible = banner);

    this.questionId = parseInt(this.route.snapshot.paramMap.get('id'));

    this.questionService.getById(this.questionId)
      .subscribe(response => { this.question = response as Question; console.log(response) });

    this.answerService.getAllByQuestionId(this.questionId)
      .subscribe(response => this.answers = response as Answer[]);

  }

  goToEditPage(){
    this.router.navigateByUrl('question/'+ this.questionId + '/edit');
  }

  

}
