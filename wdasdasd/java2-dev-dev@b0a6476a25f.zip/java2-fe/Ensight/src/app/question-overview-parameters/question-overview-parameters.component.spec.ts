import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuestionOverviewParametersComponent } from './question-overview-parameters.component';

describe('QuestionOverviewParametersComponent', () => {
  let component: QuestionOverviewParametersComponent;
  let fixture: ComponentFixture<QuestionOverviewParametersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuestionOverviewParametersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuestionOverviewParametersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
