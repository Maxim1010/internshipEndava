import { Component, OnInit, Input } from '@angular/core';
import { Question } from '../models/Question';
import { MappingService } from '../services/mapping.service';

@Component({
  selector: 'app-question-overview-parameters',
  templateUrl: './question-overview-parameters.component.html',
  styleUrls: ['./question-overview-parameters.component.css']
})
export class QuestionOverviewParametersComponent implements OnInit {
  @Input() question:Question;
  constructor( public map: MappingService) { }

  ngOnInit() {
  }

  getQuestionsFromPage(pageNumber:number){
  }

}
