import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListedCandidatesComponent } from './listed-candidates.component';

describe('ListedCandidatesComponent', () => {
  let component: ListedCandidatesComponent;
  let fixture: ComponentFixture<ListedCandidatesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListedCandidatesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListedCandidatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
