import { Component, OnInit, Input, ViewChildren, QueryList, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { ListedSingleCandidateComponent } from '../listed-single-candidate/listed-single-candidate.component';
import { CandidateChecked } from '../models/CandidateChecked';

@Component({
  selector: 'app-listed-candidates',
  templateUrl: './listed-candidates.component.html',
  styleUrls: ['./listed-candidates.component.css']
})
export class ListedCandidatesComponent implements OnInit {

  @Input() candidatesAndTheirExams: any;
  @ViewChildren(ListedSingleCandidateComponent) candidatesChildren: QueryList<ListedSingleCandidateComponent>;

  isAllChecked: boolean = false;
  @Output() isChildChecked = new EventEmitter();
  candidateAndHisExam;

  candidateChecked: CandidateChecked = new CandidateChecked();

  constructor(private router: Router){}
   

  ngOnInit() {
    
  }

  checkFromChild($event){
    //this.candidateAndHisExam = $event;
    this.candidateChecked = $event;
    this.isChildChecked.emit(this.candidateChecked);
    console.log('is Child checked ' + this.isChildChecked);
    
  }

  goOnEditPage() {
    this.router.navigateByUrl("/candidates/edit");
  }


  checkAllCandidates(){
    this.isAllChecked = !this.isAllChecked;
    this.candidatesAndTheirExams.forEach(candidate => {
      candidate.isChecked = this.isAllChecked;
    });

    this.candidatesChildren.forEach(child=>{
      child.markAll(this.isAllChecked);
      console.log(this.isAllChecked);
    });
   
  }

}
