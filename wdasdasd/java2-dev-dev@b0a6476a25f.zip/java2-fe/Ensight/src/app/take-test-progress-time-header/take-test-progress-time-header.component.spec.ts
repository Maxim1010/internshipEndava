import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TakeTestProgressTimeHeaderComponent } from './take-test-progress-time-header.component';

describe('TakeTestProgressTimeHeaderComponent', () => {
  let component: TakeTestProgressTimeHeaderComponent;
  let fixture: ComponentFixture<TakeTestProgressTimeHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TakeTestProgressTimeHeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TakeTestProgressTimeHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
