import { Component, OnInit, Input, Injectable, HostListener } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, ActivatedRoute } from '@angular/router';
import { TestService } from '../services/test.service';
import { Test } from '../models/Test';
import { ExamService } from '../services/exam.service';

@Component({
  selector: 'app-take-test-progress-time-header',
  templateUrl: './take-test-progress-time-header.component.html',
  styleUrls: ['./take-test-progress-time-header.component.css'],
})
@Injectable({
  providedIn: 'root'
})
export class TakeTestProgressTimeHeaderComponent implements OnInit{

  noQuestions;
  activeBar;
  textToShow;
  questNo = 1;
  activeRatio;
  activeWidth;
  no; cw; ch; diff; y;
  minutes; seconds; totalSeconds; totalMinutes; percent = 0; counter; strokeStartingPoint; 
  fill = 1;
  duration;

  currentQuestionIndex: number = 1;
  test: Test = new Test();
  testId: number;
  isTimeExpired: boolean;
  bannerWasVisibleOnce = false;

  constructor(private router: Router, 
    private testService: TestService, 
    private route: ActivatedRoute,
    private examService: ExamService) {

    this.noQuestions = testService.test.numberOfQuestions;
   }

   ngOnInit() {
    this.examService.currentExamTimeBanner.subscribe(timeUp => this.isTimeExpired = timeUp);
    this.duration = this.testService.duration;
    console.log('numar de intrebari : ' + this.noQuestions)
    this.activeRatio = 1 / this.noQuestions;
    this.activeWidth = this.activeRatio * 800;
    this.activeBar = document.getElementById('active-bar');
    document.getElementById('active-bar').style.width = this.activeWidth.toString() + "px";
    this.initial_setup_progress_bar();

    this.y = document.getElementById('counter');
    this.counter = this.y.getContext("2d");
    this.cw = this.counter.canvas.width;
    this.ch = this.counter.canvas.height;
    this.counter.lineWidth = 11;
    this.counter.fillStyle = '#48545B';
    this.counter.strokeStyle = "#de411b";
    this.counter.textAlign = 'center';
    this.counter.font = "25px roboto";
    this.counter.lineCap = "round";

    // TO DO: bring from global_settings the duration of the test and give it as an argument for the function down below
    this.countdownTimer(this.duration); //modify here
  }
  

  goToSummaryPage(){
    this.testId =parseInt( this.route.snapshot.paramMap.get('id'));
    this.router.navigateByUrl('take_test/end/'+this.testId);
  }

  createCounter() {
    this.percent = (this.totalSeconds / (this.totalMinutes * 60)) * 100;
    this.diff = (((100 - this.percent) / 100) * Math.PI * 2 * 10);
    this.counter.clearRect(0, 0, this.cw, this.ch);

    if (this.seconds > 9) {
      this.counter.fillText(this.minutes + ":" + this.seconds, 70, 80);
    }
    else {
      this.counter.fillText(this.minutes + ":0" + this.seconds, 70, 80);
    }

    this.counter.beginPath();
    this.counter.arc(70, 70, 60, this.strokeStartingPoint, this.diff / 10 + this.strokeStartingPoint, true);
    this.counter.stroke();

    if (this.totalSeconds < 0) {
      //this.examService.changeExamTimeBannerVisibility(true);
      this.goToSummaryPage();
      
      return 0;
    }

    this.totalSeconds--;
    this.seconds--;
    
    if (this.seconds < 0) {
      this.seconds = 59;
      this.minutes--;
    }
  }

  countdownTimer(initialMinutes) {
    this.totalMinutes = initialMinutes;
    this.minutes = initialMinutes;
    this.seconds = 0;
    this.totalSeconds = this.minutes * 60;
    this.strokeStartingPoint = 3 / 2 * Math.PI;
    this.percent = 100;
     // DONE : the candidate should be redirected to go '/take_test/end' page
    setInterval(() => { 
      if(this.totalSeconds >= 0){
          this.createCounter();
          console.log('seconds got to -> ' + this.totalSeconds);
          if(this.totalSeconds == 0){
              //console.log('seconds hit 0 now');
              this.examService.changeExamTimeBannerVisibility(true);
          }
        }
      else {
        
        this.goToSummaryPage();
        
      } 
    }
     , 1000);
          
  }


  
  // TO DO: bring from BE, from DB the total number of questions for the current text and update the hardcoded value from the 
  // function down below;

  initialise_noQuestions(){
    this.noQuestions = 3; //modify here
  }

 
  initial_setup_progress_bar(){
      this.activeRatio = 1 / this.noQuestions;
      this.activeWidth = this.activeRatio * 800;
      this.textToShow= "Question 1 of " + this.noQuestions;
      this.activeBar = document.getElementById('active-bar');
      document.getElementById('active-bar').style.width = this.activeWidth.toString() + "px";

  }



  increment_progress_bar_view() {
    document.getElementById('active-bar').style.width = this.activeWidth.toString() + "px";
  }

  display_questNo_done_so_far() {
    console.log(this.questNo);
    this.questNo = this.questNo + 1;
    this.textToShow = "Question " + this.questNo + " of " + this.noQuestions;
    if(this.questNo === this.noQuestions)
      this.activeRatio = 2;
  }

  increment() {
    if (this.activeRatio < 1) {
      console.log('numar de intrebari : ' + this.noQuestions)
      this.activeRatio = this.activeRatio + (1 / this.noQuestions);
      console.log("active Ratio: "+ this.activeRatio);
      console.log("no Q: "+ this.noQuestions);
      this.activeWidth = this.activeRatio * 670;
      this.increment_progress_bar_view();
      this.display_questNo_done_so_far();
    }
    else{
      //DONE: when the progress bar is completed the candidate should be redirected to summary page
    this.goToSummaryPage();
    }
  }

  getNumberOfQuestionsTest(){
    this.testId = parseInt(this.route.snapshot.paramMap.get('id').valueOf());

    this.testService.getById(this.testId).subscribe(res =>
       {
         this.test = res as Test; console.log('number of questions from header' + this.test.numberOfQuestions);
         this.noQuestions = this.test.numberOfQuestions;
         this.testService.noOfQuestions = this.test.numberOfQuestions;
  });
    
}
}



